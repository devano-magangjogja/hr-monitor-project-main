<?php

namespace App\Http\Controllers\PM;

use App\Http\Controllers\Controller;
use App\Http\Traits\LogsActivity;
use App\Models\PmSosmedOversight;
use App\Models\SosmedAccount;
use App\Models\SosmedApprovalLog;
use App\Models\SosmedTask;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;

class SosmedController extends Controller
{
    use LogsActivity;
    public function index(Request $request)
    {
        $tab = $request->query('tab', 'accounts');
        $currentUserId = Auth::id();

        $approvalDateFrom = $request->query('approval_date_from');
        $approvalDateTo   = $request->query('approval_date_to');

        // ── Kapasitas 1: Akun Mandiri yang Dikelola Sendiri oleh PM (Eksekutor) ────
        $myAccounts = SosmedAccount::with(['creator'])
            ->whereHas('staffUsers', fn($q) => $q->where('users.id', $currentUserId))
            ->orderBy('platform')
            ->paginate(5);

        $myAccountIds = $myAccounts->pluck('id');

        $todayTasks = SosmedTask::with(['verifiedBy', 'hrVerifiedBy'])
            ->whereIn('sosmed_account_id', $myAccountIds)
            ->whereDate('task_date', now()->toDateString())
            ->get()
            ->keyBy('sosmed_account_id');

        $accounts = $myAccounts; // Tab 1: Akun yang dikerjakan sendiri

        // ── Kapasitas 2: Akun & Staff yang Disupervisi oleh PM (Supervisor/Approver) ─
        // 1. Akun langsung di mana pm_id = me tapi dikerjakan staff lain
        $directSupervisedAccounts = SosmedAccount::with(['staffUsers', 'creator'])
            ->where('pm_id', $currentUserId)
            ->whereHas('staffUsers', fn($q) => $q->where('users.id', '!=', $currentUserId))
            ->get();

        // 2. Akun via pivot oversight (PM -> Sosmed staff)
        $oversightLinks = PmSosmedOversight::with(['sosmedUser'])
            ->where('pm_id', $currentUserId)
            ->get();

        $oversightStaffIds = $oversightLinks->pluck('sosmed_id')->filter();

        // Semua akun staff yang berada di bawah pengawasan PM ini
        $allSupervisedAccounts = SosmedAccount::with(['staffUsers', 'creator'])
            ->where(function ($q) use ($currentUserId, $oversightStaffIds) {
                $q->where(function ($q2) use ($currentUserId) {
                    $q2->where('pm_id', $currentUserId)
                       ->whereHas('staffUsers', fn($sub) => $sub->where('users.id', '!=', $currentUserId));
                })->orWhere(function ($q2) use ($oversightStaffIds, $currentUserId) {
                    $q2->whereHas('staffUsers', fn($sub) => $sub->whereIn('users.id', $oversightStaffIds)->where('users.id', '!=', $currentUserId));
                });
            })
            ->orderBy('platform')
            ->paginate(5);

        $supervisedAccountIds = $allSupervisedAccounts->pluck('id')->unique();

        $supervisedTodayTasks = SosmedTask::whereIn('sosmed_account_id', $supervisedAccountIds)
            ->where(function ($q) {
                $q->whereDate('task_date', now()->toDateString())
                  ->orWhere('status', 'done_by_staff');
            })
            ->orderBy('task_date', 'desc')
            ->get()
            ->keyBy('sosmed_account_id');

        // Oversight data grouping per staff user
        $oversightStaffUsers = $allSupervisedAccounts->pluck('staffUsers')->flatten()->filter()->unique('id');
        $oversightData = $oversightStaffUsers->map(function ($staffUser) use ($supervisedTodayTasks) {
            $userAccounts = SosmedAccount::whereHas('staffUsers', fn($q) => $q->where('users.id', $staffUser->id))
                ->orderBy('platform')
                ->get();
            $userAccountIds = $userAccounts->pluck('id');

            $userTodayTasks = $supervisedTodayTasks->whereIn('sosmed_account_id', $userAccountIds);

            return [
                'sosmed_user'   => $staffUser,
                'accounts'      => $userAccounts,
                'today_tasks'   => $userTodayTasks->keyBy('sosmed_account_id'),
                'total'         => $userAccounts->count(),
                'done'          => $userTodayTasks->whereIn('status', ['done_by_staff', 'verified_by_pm', 'approved_hr'])->count(),
                'pending'       => $userAccounts->filter(function ($acc) use ($userTodayTasks) {
                    $t = $userTodayTasks->firstWhere('sosmed_account_id', $acc->id);
                    return !$t || in_array($t->status, ['pending', 'rejected']);
                })->count(),
            ];
        })->values();

        // ── Verifikasi Tugas Tim (Approval Level 1) ────────────────────────
        // Tugas dari akun yang diawasi yang berstatus 'done_by_staff' dan bukan milik PM sendiri
        $pendingVerification = SosmedTask::with(['account.staffUser', 'assignedUser'])
            ->whereIn('sosmed_account_id', $supervisedAccountIds)
            ->where('assigned_to', '!=', $currentUserId)
            ->where('status', 'done_by_staff');

        $verifySearch = trim((string) $request->query('verify_search', ''));
        if ($verifySearch !== '') {
            $pendingVerification->where(function ($q) use ($verifySearch) {
                $q->where('title', 'like', '%' . $verifySearch . '%')
                  ->orWhereHas('account', fn($a) => $a->where('name', 'like', '%' . $verifySearch . '%')
                      ->orWhere('platform', 'like', '%' . $verifySearch . '%')
                      ->orWhere('brand', 'like', '%' . $verifySearch . '%'))
                  ->orWhereHas('assignedUser', fn($u) => $u->where('name', 'like', '%' . $verifySearch . '%'));
            });
        }

        $pendingVerification = $pendingVerification
            ->orderBy('updated_at', 'desc')
            ->get();

        $approvalHistory = SosmedTask::with(['account.staffUser', 'assignedUser', 'verifiedBy', 'hrVerifiedBy'])
            ->whereIn('sosmed_account_id', $supervisedAccountIds)
            ->where('assigned_to', '!=', $currentUserId)
            ->whereIn('status', ['verified_by_pm', 'approved_hr', 'rejected'])
            ->orderBy('updated_at', 'desc')
            ->get();

        // ── Stats ─────────────────────────────────────────────────────────
        $allSupervisedTasks = SosmedTask::whereIn('sosmed_account_id', $supervisedAccountIds)->get();

        $stats = [
            'total_accounts'    => $accounts->total(), // Akun mandiri yang dipegang sendiri
            'need_pm_verify'    => $pendingVerification->count(),
            'waiting_hr'        => $allSupervisedTasks->where('status', 'verified_by_pm')->count(),
            'approved_final'    => $allSupervisedTasks->where('status', 'approved_hr')->count(),
            'rejected'          => $allSupervisedTasks->where('status', 'rejected')->count(),
            'pending_today'     => $accounts->filter(function ($acc) use ($todayTasks) {
                if (!isset($todayTasks[$acc->id])) return true;
                return in_array($todayTasks[$acc->id]->status, ['pending', 'rejected']);
            })->count(),
            'oversight_count'   => $allSupervisedAccounts->count(),
        ];

        $approvalHistoryQuery = SosmedTask::with(['account.staffUser', 'assignedUser', 'verifiedBy', 'hrVerifiedBy'])
            ->whereIn('sosmed_account_id', $supervisedAccountIds)
            ->where('assigned_to', '!=', $currentUserId)
            ->whereIn('status', ['verified_by_pm', 'approved_hr', 'rejected'])
            ->orderByDesc('updated_at');

        if ($approvalDateFrom) {
            $approvalHistoryQuery->whereDate('updated_at', '>=', $approvalDateFrom);
        }
        if ($approvalDateTo) {
            $approvalHistoryQuery->whereDate('updated_at', '<=', $approvalDateTo);
        }

        $approvalHistoryPaginated = $approvalHistoryQuery->paginate(10)->appends($request->query());

        return view('pm.sosmed.index', compact(
            'tab', 'accounts', 'todayTasks',
            'oversightData', 'oversightLinks', 'allSupervisedAccounts',
            'pendingVerification', 'approvalHistory',
            'approvalHistoryPaginated', 'approvalDateFrom', 'approvalDateTo',
            'stats'
        ));
    }

    /**
     * PM submits proof for an account they manage directly as Executor.
     * Goes straight to verified_by_pm (level-1 passed) and awaits final HR approval.
     */
    public function submitAccountTask(Request $request, SosmedAccount $account)
    {
        if ($account->staff_id !== Auth::id() && $account->pm_id !== Auth::id()) {
            abort(403, 'Akses ditolak. Anda bukan eksekutor akun ini.');
        }

        $validated = $request->validate([
            'links'       => ['required', 'array', 'min:1'],
            'links.*'     => ['required', 'string', 'max:500'],
            'description' => ['nullable', 'string', 'max:1000'],
        ]);

        $links = array_values(array_filter($validated['links'], fn($l) => !empty(trim($l))));
        if (empty($links)) {
            return back()->withErrors(['links' => 'Minimal satu link bukti harus diisi.'])->withInput();
        }

        $task = SosmedTask::firstOrNew([
            'sosmed_account_id' => $account->id,
            'task_date'         => now()->toDateString(),
        ]);

        $task->fill([
            'assigned_to' => Auth::id(),
            'assigned_by' => Auth::id(),
            'type'        => 'daily',
            'title'       => 'Laporan Konten - ' . $account->name,
            'link_upload' => $links,
            'description' => $validated['description'] ?? null,
            'status'      => 'verified_by_pm',
            'verified_by' => Auth::id(),
            'verified_at' => now(),
        ]);
        $task->save();

        SosmedApprovalLog::create([
            'sosmed_task_id' => $task->id,
            'user_id'        => Auth::id(),
            'user_name'      => Auth::user()->name,
            'role_name'      => 'PM (Project Manager)',
            'action'         => 'submitted',
            'notes'          => 'PM submit bukti langsung (' . count($links) . ' link). Langsung menunggu approval final HR Staff.',
        ]);

        $this->logActivity('sosmed.submitted', 'Sosmed', "Submit bukti laporan sosmed untuk akun '{$account->name}'", $task);

        return redirect()->route('pm.sosmed.index', ['tab' => 'accounts'])
            ->with('success', 'Bukti konten untuk ' . $account->name . ' berhasil dikirim. Menunggu approval final HR Staff.');
    }

    /**
     * PM verifies a task submitted by a Sosmed user.
     * Allowed if PM is the direct account owner (pm_id) OR
     * the oversight PM for the Sosmed user who submitted.
     */
    public function verifyTask(Request $request, SosmedTask $task)
    {
        $currentUserId = Auth::id();

        // Direct account owner check
        $isDirect = $task->account->pm_id === $currentUserId;

        // Oversight PM check: is this PM assigned to oversee the sosmed user?
        $isOversight = false;
        if ($task->assigned_to) {
            $isOversight = PmSosmedOversight::where('pm_id', $currentUserId)
                ->where('sosmed_id', $task->assigned_to)
                ->exists();
        }

        if (!$isDirect && !$isOversight) {
            abort(403, 'Akses ditolak. Anda tidak memiliki wewenang untuk memverifikasi tugas ini.');
        }

        $validated = $request->validate([
            'action'         => ['required', 'in:verify,reject'],
            'rejection_note' => ['nullable', 'string', 'max:500'],
        ]);

        if ($validated['action'] === 'verify') {
            $task->update([
                'status'      => 'verified_by_pm',
                'verified_by' => $currentUserId,
                'verified_at' => now(),
            ]);

            SosmedApprovalLog::create([
                'sosmed_task_id' => $task->id,
                'user_id'        => $currentUserId,
                'user_name'      => Auth::user()->name,
                'role_name'      => 'PM (Project Manager)',
                'action'         => 'approved_pm',
                'notes'          => 'Diverifikasi oleh PM. Menunggu persetujuan final HR Staff.',
            ]);

            $this->logActivity('sosmed.verified', 'Sosmed', "Memverifikasi tugas sosmed '{$task->title}' dari tim", $task);

            return redirect()->route('pm.sosmed.index', ['tab' => 'oversight'])
                ->with('success', 'Tugas berhasil diverifikasi dan diteruskan ke HR Staff.');
        } else {
            $task->update([
                'status'         => 'rejected',
                'verified_by'    => $currentUserId,
                'verified_at'    => now(),
                'rejection_note' => $validated['rejection_note'],
            ]);

            SosmedApprovalLog::create([
                'sosmed_task_id' => $task->id,
                'user_id'        => $currentUserId,
                'user_name'      => Auth::user()->name,
                'role_name'      => 'PM (Project Manager)',
                'action'         => 'rejected',
                'notes'          => $validated['rejection_note'] ?? 'Ditolak oleh PM',
            ]);

            $this->logActivity('sosmed.verified', 'Sosmed', "Menolak tugas sosmed '{$task->title}' dari tim", $task);

            return redirect()->route('pm.sosmed.index', ['tab' => 'oversight'])
                ->with('success', 'Tugas ditolak dan dikembalikan ke staff.');
        }
    }

    public function destroyApprovalHistory(Request $request)
    {
        $validated = $request->validate([
            'period' => ['required', 'in:week,month,year'],
        ]);

        $currentUserId = Auth::id();
        $supervisedAccountIds = SosmedAccount::where(function ($q) use ($currentUserId) {
                $q->where('pm_id', $currentUserId)
                   ->whereHas('staffUsers', fn($sub) => $sub->where('users.id', '!=', $currentUserId));
            })
            ->orWhere(function ($q) use ($currentUserId) {
                $q->whereHas('staffUsers', function ($q2) use ($currentUserId) {
                    $q2->whereIn('users.id', function ($q3) use ($currentUserId) {
                        $q3->select('sosmed_id')->from('pm_sosmed_oversights')->where('pm_id', $currentUserId);
                    })->where('users.id', '!=', $currentUserId);
                });
            })
            ->pluck('id')
            ->unique();

        $query = SosmedTask::whereIn('sosmed_account_id', $supervisedAccountIds)
            ->where('assigned_to', '!=', $currentUserId)
            ->whereIn('status', ['verified_by_pm', 'approved_hr', 'rejected']);

        if ($validated['period'] === 'week') {
            $query->where('updated_at', '<', Carbon::now()->subWeek());
        } elseif ($validated['period'] === 'month') {
            $query->where('updated_at', '<', Carbon::now()->subMonth());
        } elseif ($validated['period'] === 'year') {
            $query->where('updated_at', '<', Carbon::now()->subYear());
        }

        $deleted = $query->count();
        $query->delete();
        $this->logActivity('sosmed.deleted', 'Sosmed', "Menghapus {$deleted} riwayat persetujuan sosmed (filter: {$validated['period']})");

        return redirect()->route('pm.sosmed.index', ['tab' => 'approvals'])
            ->with('success', "Berhasil menghapus {$deleted} riwayat approval.");
    }
}
