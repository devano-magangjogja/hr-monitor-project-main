<?php

namespace App\Http\Controllers\PM;

use App\Http\Controllers\Controller;
use App\Http\Traits\LogsActivity;
use App\Models\Task;
use App\Services\TaskService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class TaskController extends Controller
{
    use LogsActivity;

    public function __construct(protected TaskService $taskService) {}

    // ── Tugas Mandiri ────────────────────────────────────

    public function index()
    {
        $tasks = $this->taskService->getSelfTasksToday(Auth::id());
        $tasks = $this->taskService->sortTasksByStatus($tasks, Auth::id());
        return view('pm.tasks.index', compact('tasks'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title'       => ['required', 'string', 'max:200'],
            'description' => ['nullable', 'string'],
        ]);
        try {
            $this->taskService->createSelfTask($validated);
            $this->logActivity('task.created', 'Tugas', "Membuat tugas mandiri '{$validated['title']}'");
            return redirect()->route('pm.tasks.index')
                ->with('success', 'Tugas mandiri berhasil ditambahkan.');
        } catch (ValidationException $e) {
            return back()->withErrors($e->errors())->withInput();
        }
    }

    public function update(Request $request, Task $task)
    {
        $validated = $request->validate([
            'title'       => ['required', 'string', 'max:200'],
            'description' => ['nullable', 'string'],
        ]);
        try {
            $this->taskService->updateSelfTask($task, $validated);
            $this->logActivity('task.updated', 'Tugas', "Memperbarui tugas '{$task->title}'", $task);
            return redirect()->route('pm.tasks.index')
                ->with('success', 'Tugas mandiri berhasil diperbarui.');
        } catch (ValidationException $e) {
            return back()->with('error', $e->errors()['task'][0] ?? 'Gagal memperbarui tugas.');
        }
    }

    public function destroy(Task $task)
    {
        try {
            $title = $task->title;
            $this->taskService->deleteSelfTask($task);
            $this->logActivity('task.deleted', 'Tugas', "Menghapus tugas '{$title}'");
            return redirect()->route('pm.tasks.index')
                ->with('success', 'Tugas mandiri berhasil dihapus.');
        } catch (ValidationException $e) {
            return back()->with('error', $e->errors()['task'][0] ?? 'Gagal menghapus tugas.');
        }
    }

    public function complete(Request $request, Task $task)
    {
        $request->validate([
            'note'       => ['nullable', 'string', 'max:500'],
            'attachment' => ['nullable', 'file', 'image', 'mimes:jpeg,png,jpg,webp', 'max:5120'],
        ]);
        try {
            $this->taskService->completeTask($task, $request->note, $request->file('attachment'));
            $this->logActivity('task.completed', 'Tugas', "Menyelesaikan tugas '{$task->title}'", $task);
            return redirect()->route('pm.tasks.index')
                ->with('task_completed', 'Terima kasih sudah menyelesaikan tugas ini dengan baik. Tetap semangat!');
        } catch (ValidationException $e) {
            $errorMsg = $e->errors()['task'][0] ?? ($e->errors()['attachment'][0] ?? 'Gagal menyelesaikan tugas.');
            return back()->with('error', $errorMsg);
        }
    }

    // ── Tugas Harian (Default) ───────────────────────────

    public function dailyIndex()
    {
        $tasks = $this->taskService->getDefaultTasksForUser(Auth::id());
        $tasks = $this->taskService->sortTasksByStatus($tasks, Auth::id());
        return view('pm.tasks.daily', compact('tasks'));
    }

    public function dailyComplete(Request $request, Task $task)
    {
        $request->validate([
            'note'       => ['nullable', 'string', 'max:500'],
            'attachment' => ['nullable', 'file', 'image', 'mimes:jpeg,png,jpg,webp', 'max:5120'],
        ]);
        try {
            $this->taskService->completeTask($task, $request->note, $request->file('attachment'));
            $this->logActivity('task.completed', 'Tugas', "Menyelesaikan tugas '{$task->title}'", $task);
            return redirect()->route('pm.tasks.daily')
                ->with('task_completed', 'Terima kasih sudah menyelesaikan tugas ini dengan baik. Tetap semangat!');
        } catch (ValidationException $e) {
            $errorMsg = $e->errors()['task'][0] ?? ($e->errors()['attachment'][0] ?? 'Gagal menyelesaikan tugas.');
            return back()->with('error', $errorMsg);
        }
    }

    // ── Tugas dari Admin ─────────────────────────────────

    public function assignedIndex()
    {
        $tasks = $this->taskService->getAssignedTasksFromAdmin(Auth::id());
        $tasks = $this->taskService->sortTasksByStatus($tasks, Auth::id());
        return view('pm.tasks.assigned', compact('tasks'));
    }

    public function assignedComplete(Request $request, Task $task)
    {
        $request->validate([
            'note'       => ['nullable', 'string', 'max:500'],
            'attachment' => ['nullable', 'file', 'image', 'mimes:jpeg,png,jpg,webp', 'max:5120'],
        ]);
        try {
            $this->taskService->completeTask($task, $request->note, $request->file('attachment'));
            $this->logActivity('task.completed', 'Tugas', "Menyelesaikan tugas '{$task->title}'", $task);
            return redirect()->route('pm.tasks.assigned')
                ->with('task_completed', 'Terima kasih sudah menyelesaikan tugas ini dengan baik. Tetap semangat!');
        } catch (ValidationException $e) {
            $errorMsg = $e->errors()['task'][0] ?? ($e->errors()['attachment'][0] ?? 'Gagal menyelesaikan tugas.');
            return back()->with('error', $errorMsg);
        }
    }

    // ── Semua Tugas ──────────────────────────────────────

    public function allIndex()
    {
        $tasks = $this->taskService->getAllTasksForUserToday(Auth::id());
        $tasks = $this->taskService->sortTasksByStatus($tasks, Auth::id());
        return view('pm.tasks.all', compact('tasks'));
    }

    public function allComplete(Request $request, Task $task)
    {
        $request->validate([
            'note'       => ['nullable', 'string', 'max:500'],
            'attachment' => ['nullable', 'file', 'image', 'mimes:jpeg,png,jpg,webp', 'max:5120'],
        ]);
        try {
            $this->taskService->completeTask($task, $request->note, $request->file('attachment'));
            $this->logActivity('task.completed', 'Tugas', "Menyelesaikan tugas '{$task->title}'", $task);
            return redirect()->route('pm.tasks.all')
                ->with('task_completed', 'Terima kasih sudah menyelesaikan tugas ini dengan baik. Tetap semangat!');
        } catch (ValidationException $e) {
            $errorMsg = $e->errors()['task'][0] ?? ($e->errors()['attachment'][0] ?? 'Gagal menyelesaikan tugas.');
            return back()->with('error', $errorMsg);
        }
    }

    // ── Riwayat ──────────────────────────────────────────

    public function history(Request $request)
    {
        $date   = $request->query('date');
        $search = $request->query('search');
        $tasks  = $this->taskService->getHistoryForUser(Auth::id(), $date, $search);
        return view('pm.history.index', compact('tasks', 'date', 'search'));
    }
}
