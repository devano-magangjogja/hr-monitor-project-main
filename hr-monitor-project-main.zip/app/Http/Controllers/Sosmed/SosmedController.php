<?php

namespace App\Http\Controllers\Sosmed;

use App\Http\Controllers\Controller;
use App\Models\SosmedAccount;
use App\Models\SosmedApprovalLog;
use App\Models\SosmedTask;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SosmedController extends Controller
{
    public function index(Request $request)
    {
        $currentUserId = Auth::id();

        $accountSearch = trim((string) $request->query('account_search', ''));

        // Akun yang didelegasikan ke user ini oleh PM
        $accounts = SosmedAccount::with(['pmUser', 'creator'])
            ->whereHas('staffUsers', fn($q) => $q->where('users.id', $currentUserId))
            ->when($accountSearch !== '', function ($q) use ($accountSearch) {
                $q->where(function ($qq) use ($accountSearch) {
                    $qq->where('name', 'like', "%{$accountSearch}%")
                       ->orWhere('username', 'like', "%{$accountSearch}%")
                       ->orWhere('platform', 'like', "%{$accountSearch}%")
                       ->orWhere('brand', 'like', "%{$accountSearch}%");
                });
            })
            ->orderBy('platform')
            ->paginate(5)
            ->appends($request->all());

        $accountIds = $accounts->pluck('id');

        // Tugas hari ini per akun untuk user ini
        $todayTasks = SosmedTask::with(['verifiedBy', 'hrVerifiedBy'])
            ->whereIn('sosmed_account_id', $accountIds)
            ->where('assigned_to', $currentUserId)
            ->whereDate('task_date', now()->toDateString())
            ->get()
            ->keyBy('sosmed_account_id');

        // Statistik hari ini
        $stats = [
            'total_accounts' => $accounts->count(),
            'pending_tasks'  => $accounts->filter(function ($acc) use ($todayTasks) {
                if (!isset($todayTasks[$acc->id])) return true;
                return in_array($todayTasks[$acc->id]->status, ['pending', 'rejected']);
            })->count(),
            'waiting_pm'     => $todayTasks->where('status', 'done_by_staff')->count(),
            'waiting_hr'     => $todayTasks->where('status', 'verified_by_pm')->count(),
            'approved_final' => $todayTasks->where('status', 'approved_hr')->count(),
        ];

        return view('sosmed.sosmed.index', compact('accounts', 'todayTasks', 'stats', 'accountSearch'));
    }

    /**
     * Sosmed staff submit bukti untuk akun yang ia pegang hari ini.
     * Menerima multi-link (array of URLs).
     */
    public function submitAccountTask(Request $request, SosmedAccount $account)
    {
        if (!$account->staffUsers()->where('users.id', Auth::id())->exists()) {
            abort(403, 'Akses ditolak. Anda bukan penanggung jawab akun ini.');
        }

        $validated = $request->validate([
            'links'       => ['required', 'array', 'min:1'],
            'links.*'     => ['required', 'string', 'max:500'],
            'description' => ['nullable', 'string', 'max:1000'],
        ]);

        // Hapus entri kosong
        $links = array_values(array_filter($validated['links'], fn($l) => !empty(trim($l))));
        if (empty($links)) {
            return back()->withErrors(['links' => 'Minimal satu link bukti harus diisi.'])->withInput();
        }

        // Cari atau buat tugas hari ini
        $task = SosmedTask::firstOrNew([
            'sosmed_account_id' => $account->id,
            'assigned_to'       => Auth::id(),
            'task_date'         => now()->toDateString(),
        ]);

        $task->fill([
            'assigned_to' => Auth::id(),
            'assigned_by' => $account->pm_id ?? $account->created_by ?? Auth::id(),
            'type'        => 'daily',
            'title'       => 'Laporan Konten - ' . $account->name,
            'link_upload' => $links,
            'description' => $validated['description'] ?? null,
            'status'      => 'done_by_staff',
        ]);
        $task->save();

        SosmedApprovalLog::create([
            'sosmed_task_id' => $task->id,
            'user_id'        => Auth::id(),
            'user_name'      => Auth::user()->name,
            'role_name'      => Auth::user()->role_label,
            'action'         => 'submitted',
            'notes'          => 'Bukti disubmit (' . count($links) . ' item). Menunggu verifikasi ' . ($account->levelOneVerifier()?->name ?? $account->finalVerifierLabel()) . '.',
        ]);

        return redirect()->route('sosmed.sosmed.index')
            ->with('success', $account->name . ' berhasil ditandai selesai. Menunggu verifikasi ' . ($account->levelOneVerifier()?->name ?? $account->finalVerifierLabel()) . '.');
    }
}
