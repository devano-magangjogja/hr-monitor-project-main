<?php

namespace App\Http\Controllers\Staff;

use App\Http\Controllers\Controller;
use App\Http\Traits\LogsActivity;
use App\Models\Task;
use App\Services\TaskService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class TaskController extends Controller
{
    use LogsActivity;

    public function __construct(
        protected TaskService $taskService
    ) {}

    public function assignIndex()
    {
        $tasks           = $this->taskService->getAssignedTasksForStaff(Auth::id());
        $assignableUsers = $this->taskService->getAssignableUsers();
        return view('staff.assign-tasks.index', compact('tasks', 'assignableUsers'));
    }

    public function assignStore(Request $request)
    {
        $validated = $request->validate([
            'title'             => ['required', 'string', 'max:200'],
            'description'       => ['nullable', 'string'],
            'kantor'            => ['nullable', 'string', 'in:Kantor 1,Kantor 2,Kantor 3,Kantor 4,Kantor 5,Kantor 6,Kantor 7,Kantor 8,Kantor 9,Kantor 10'],
            'proof_requirement' => ['nullable', 'string', 'in:required,optional,none'],
            'user_ids'          => ['required', 'array', 'min:1'],
            'user_ids.*'        => ['integer', 'exists:users,id'],
        ]);
        $validated['proof_requirement'] = $validated['proof_requirement'] ?? 'none';

        try {
            $task = $this->taskService->createAssignedTask($validated);
            
            $this->logActivity('task.assigned', 'Tugas', "Menugaskan tugas '{$validated['title']}' ke HR Assistant", $task);
            
            return redirect()->route('staff.assign.index')
                ->with('success', 'Tugas berhasil dikirim ke HR Assistant.');
        } catch (ValidationException $e) {
            return back()->withErrors($e->errors())->withInput();
        }
    }

    public function assignUpdate(Request $request, Task $task)
    {
        $validated = $request->validate([
            'title'             => ['required', 'string', 'max:200'],
            'description'       => ['nullable', 'string'],
            'kantor'            => ['nullable', 'string', 'in:Kantor 1,Kantor 2,Kantor 3,Kantor 4,Kantor 5,Kantor 6,Kantor 7,Kantor 8,Kantor 9,Kantor 10'],
            'proof_requirement' => ['nullable', 'string', 'in:required,optional,none'],
            'user_ids'          => ['required', 'array', 'min:1'],
            'user_ids.*'        => ['integer', 'exists:users,id'],
        ]);
        $validated['proof_requirement'] = $validated['proof_requirement'] ?? 'none';

        try {
            $this->taskService->updateTask($task, $validated);
            $this->logActivity('task.updated', 'Tugas', "Memperbarui tugas '{$task->title}'", $task);
            return redirect()->route('staff.assign.index')
                ->with('success', 'Tugas berhasil diperbarui.');
        } catch (ValidationException $e) {
            return back()->with('error', $e->errors()['task'][0] ?? 'Gagal memperbarui tugas.');
        }
    }

    public function assignDestroy(Task $task)
    {
        try {
            $title = $task->title;
            $this->taskService->deleteTask($task);
            $this->logActivity('task.deleted', 'Tugas', "Menghapus tugas '{$title}'");
            return redirect()->route('staff.assign.index')
                ->with('success', 'Tugas berhasil dihapus.');
        } catch (ValidationException $e) {
            return back()->with('error', $e->errors()['task'][0] ?? 'Gagal menghapus tugas.');
        }
    }

   // ── Self Task (Tugas Mandiri) ────────────────────────
   public function index()
   {
       $tasks = $this->taskService->getSelfTasksToday(Auth::id());
       $tasks = $this->taskService->sortTasksByStatus($tasks, Auth::id());
       return view('staff.tasks.index', compact('tasks'));
   }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title'       => ['required', 'string', 'max:200'],
            'description' => ['nullable', 'string'],
        ]);

        try {
            $task = $this->taskService->createSelfTask($validated);
            
            $this->logActivity('task.created', 'Tugas', "Membuat tugas mandiri '{$validated['title']}'", $task);
            
            return redirect()->route('staff.tasks.index')
                ->with('success', 'Tugas mandiri berhasil ditambahkan.');
        } catch (ValidationException $e) {
            return back()->withErrors($e->errors())->withInput();
        }
    }

    public function update(Request $request, Task $task)
    {
        $validated = $request->validate([
            'title'       => ['required', 'string', 'max:200'],
            'description' => ['nullable', 'string'],
        ]);

        try {
            $this->taskService->updateSelfTask($task, $validated);
            $this->logActivity('task.updated', 'Tugas', "Memperbarui tugas mandiri '{$task->title}'", $task);
            return redirect()->route('staff.tasks.index')
                ->with('success', 'Tugas mandiri berhasil diperbarui.');
        } catch (ValidationException $e) {
            return back()->with('error', $e->errors()['task'][0] ?? 'Gagal memperbarui tugas.');
        }
    }
    public function destroy(Task $task)
    {
        try {
            $title = $task->title;
            $this->taskService->deleteSelfTask($task);
            $this->logActivity('task.deleted', 'Tugas', "Menghapus tugas mandiri '{$title}'");
            return redirect()->route('staff.tasks.index')
                ->with('success', 'Tugas mandiri berhasil dihapus.');
        } catch (ValidationException $e) {
            return back()->with('error', $e->errors()['task'][0] ?? 'Gagal menghapus tugas.');
        }
    }
    public function complete(Request $request, Task $task)
    {
        $request->validate([
            'note'       => ['nullable', 'string', 'max:500'],
            'attachment' => ['nullable', 'file', 'image', 'mimes:jpeg,png,jpg,webp', 'max:5120'],
        ]);
        
        try {
            $this->taskService->completeTask($task, $request->note, $request->file('attachment'));
            
            $this->logActivity('task.completed', 'Tugas', "Menyelesaikan tugas '{$task->title}'", $task);
            
            return redirect()->route('staff.tasks.index')
                ->with('task_completed', 'Terima kasih sudah menyelesaikan tugas ini dengan baik. Tetap semangat!');
        } catch (ValidationException $e) {
            $errorMsg = $e->errors()['task'][0] ?? ($e->errors()['attachment'][0] ?? 'Gagal menyelesaikan tugas.');
            return back()->with('error', $errorMsg);
        }
    }
    public function history(Request $request)
    {
        $date   = $request->query('date');
        $search = $request->query('search');
        $tasks  = $this->taskService->getHistoryForUser(Auth::id(), $date, $search);
        return view('staff.history.index', compact('tasks', 'date', 'search'));
    }

    public function dailyIndex()
    {
        $tasks = $this->taskService->getDefaultTasksForUser(Auth::id());
        $tasks = $this->taskService->sortTasksByStatus($tasks, Auth::id());
        return view('staff.tasks.daily', compact('tasks'));
    }

    public function dailyComplete(Request $request, Task $task)
    {
        $request->validate([
            'note'       => ['nullable', 'string', 'max:500'],
            'attachment' => ['nullable', 'file', 'image', 'mimes:jpeg,png,jpg,webp', 'max:5120'],
        ]);

        try {
            $this->taskService->completeTask($task, $request->note, $request->file('attachment'));
            $this->logActivity('task.completed', 'Tugas', "Menyelesaikan tugas '{$task->title}'", $task);
            return redirect()->route('staff.tasks.daily')
                ->with('task_completed', 'Terima kasih sudah menyelesaikan tugas ini dengan baik. Tetap semangat!');
        } catch (ValidationException $e) {
            $errorMsg = $e->errors()['task'][0] ?? ($e->errors()['attachment'][0] ?? 'Gagal menyelesaikan tugas.');
            return back()->with('error', $errorMsg);
        }
    }

    public function assignedIndex()
    {
        $tasks = $this->taskService->getAssignedTasksFromAdmin(Auth::id());
        $tasks = $this->taskService->sortTasksByStatus($tasks, Auth::id());
        return view('staff.tasks.assigned', compact('tasks'));
    }

    public function assignedComplete(Request $request, Task $task)
    {
        $request->validate([
            'note'       => ['nullable', 'string', 'max:500'],
            'attachment' => ['nullable', 'file', 'image', 'mimes:jpeg,png,jpg,webp', 'max:5120'],
        ]);

        try {
            $this->taskService->completeTask($task, $request->note, $request->file('attachment'));
            return redirect()->route('staff.tasks.assigned')
                ->with('task_completed', 'Terima kasih sudah menyelesaikan tugas ini dengan baik. Tetap semangat!');
        } catch (ValidationException $e) {
            $errorMsg = $e->errors()['task'][0] ?? ($e->errors()['attachment'][0] ?? 'Gagal menyelesaikan tugas.');
            return back()->with('error', $errorMsg);
        }
    }
            
    public function allIndex()
    {
        $tasks = $this->taskService->getAllTasksForUserToday(Auth::id());
        $tasks = $this->taskService->sortTasksByStatus($tasks, Auth::id());
        return view('staff.tasks.all', compact('tasks'));
    }

    public function allComplete(Request $request, Task $task)
    {
        $request->validate([
            'note'       => ['nullable', 'string', 'max:500'],
            'attachment' => ['nullable', 'file', 'image', 'mimes:jpeg,png,jpg,webp', 'max:5120'],
        ]);

        try {
            $this->taskService->completeTask($task, $request->note, $request->file('attachment'));
            return redirect()->route('staff.tasks.all')
                ->with('task_completed', 'Terima kasih sudah menyelesaikan tugas ini dengan baik. Tetap semangat!');
        } catch (ValidationException $e) {
            $errorMsg = $e->errors()['task'][0] ?? ($e->errors()['attachment'][0] ?? 'Gagal menyelesaikan tugas.');
            return back()->with('error', $errorMsg);
        }
    }

    public function assistantProgress(Request $request)
    {
        $today    = \Carbon\Carbon::today()->toDateString();
        $dateFrom = $request->query('date_from', $today);
        $dateTo   = $request->query('date_to',   $today);

        if ($dateFrom > $dateTo) {
            [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
        }

        $assistants = $this->taskService->getAssistantProgressByRange($dateFrom, $dateTo);

        $scoreData = [];
        foreach ($assistants as $assistant) {
            $scoreData[$assistant->id] = [
                'week'  => $this->taskService->getUserScore($assistant->id, 'week'),
                'month' => $this->taskService->getUserScore($assistant->id, 'month'),
            ];
        }

        return view('staff.assistant-progress', compact(
            'assistants', 'scoreData', 'dateFrom', 'dateTo', 'today'
        ));
    }

    public function assistantProgressDetail(Request $request, \App\Models\User $user)
    {
        abort_if($user->role !== 'hr_assistant', 403);

        $today    = \Carbon\Carbon::today()->toDateString();
        $dateFrom = $request->query('date_from', $today);
        $dateTo   = $request->query('date_to',   $today);

        if ($dateFrom > $dateTo) {
            [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
        }

        $tasks = $this->taskService->getProductivityDetailForUser($user->id, $dateFrom, $dateTo);

        $scoreWeek  = $this->taskService->getUserScore($user->id, 'week');
        $scoreMonth = $this->taskService->getUserScore($user->id, 'month');

        // Hitung ringkasan
        $total = $tasks->count();
        $completed = $notDone = $pending = 0;
        foreach ($tasks as $task) {
            $s = $task->assignments->first()?->is_completed ?? 'pending';
            if ($s === 'completed')    $completed++;
            elseif ($s === 'not_done') $notDone++;
            else                       $pending++;
        }
        $pct = $total > 0 ? round(($completed / $total) * 100) : 0;

        // Kelompokkan per hari
        $tasksByDate = $tasks->groupBy(fn($t) => $t->task_date->toDateString());

        return view('staff.assistant-progress-detail', compact(
            'user', 'tasks', 'tasksByDate',
            'dateFrom', 'dateTo',
            'total', 'completed', 'notDone', 'pending', 'pct',
            'scoreWeek', 'scoreMonth'
        ));
    }

    public function productivity(Request $request)
    {
        $today        = \Carbon\Carbon::today()->toDateString();
        $dateFrom     = $request->query('date_from', $today);
        $dateTo       = $request->query('date_to',   $today);
        $selectedRole = $request->query('role', 'all');

        if ($dateFrom > $dateTo) {
            [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
        }

        // Hanya role di bawah staff (tidak bisa melihat admin dan tidak bisa melihat sesama staff)
        $belowStaffRoles = \App\Models\Role::whereNotIn('name', ['admin', 'hr_staff'])
            ->orderBy('label')
            ->get();
        $allowedRoleNames = $belowStaffRoles->pluck('name')->toArray();

        $report = $this->taskService->getProductivityByRange($dateFrom, $dateTo, $selectedRole, $allowedRoleNames);

        return view('staff.reports.productivity', compact(
            'report', 'dateFrom', 'dateTo', 'today', 'selectedRole', 'belowStaffRoles'
        ));
    }

    public function productivityDetail(Request $request, \App\Models\User $user)
    {
        // Hanya dapat melihat detail pengguna dari role di bawah staff
        abort_if(in_array($user->role, ['admin', 'hr_staff']), 403);

        $today    = \Carbon\Carbon::today()->toDateString();
        $dateFrom = $request->query('date_from', $today);
        $dateTo   = $request->query('date_to',   $today);
        $statusFilter = $request->query('status', 'all');

        if ($dateFrom > $dateTo) {
            [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
        }

        $tasks = $this->taskService->getProductivityDetailForUser($user->id, $dateFrom, $dateTo);

        $total = $tasks->count();
        $completed = $notDone = $pending = 0;
        foreach ($tasks as $task) {
            $s = $task->assignments->first()?->is_completed ?? 'pending';
            if ($s === 'completed')    $completed++;
            elseif ($s === 'not_done') $notDone++;
            else                       $pending++;
        }
        $pct = $total > 0 ? round(($completed / $total) * 100) : 0;

        $filteredTasks = $tasks;
        if ($statusFilter !== 'all') {
            $filteredTasks = $tasks->filter(function ($task) use ($statusFilter) {
                $s = $task->assignments->first()?->is_completed ?? 'pending';
                return $s === $statusFilter;
            })->values();
        }

        $tasksByDate = $filteredTasks->groupBy(fn($t) => $t->task_date->toDateString());

        return view('staff.reports.productivity-detail', compact(
            'user', 'tasks', 'filteredTasks', 'tasksByDate',
            'dateFrom', 'dateTo',
            'total', 'completed', 'notDone', 'pending', 'pct',
            'statusFilter'
        ));
    }
}