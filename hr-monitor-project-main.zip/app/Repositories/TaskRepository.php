<?php

namespace App\Repositories;

use App\Models\Task;
use App\Models\TaskAssignment;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class TaskRepository
{
    public function __construct(protected Task $model) {}

    public function getAllForAdmin(): Collection
    {
        /** @var Builder $query */
        $query = $this->model->newQuery();

        return $query
            ->with(['creator:id,name', 'assignedUsers:id,name,role'])
            ->whereDate('task_date', Carbon::today())
            ->orderByDesc('created_at')
            ->get();
    }

    public function getAssignedTasksForStaff(int $staffId): Collection
    {
        /** @var Builder $query */
        $query = $this->model->newQuery();

        // Tampilkan tugas yang dibuat staff ini (type assigned) HANYA hari ini
        // ATAU tugas default yang ditugaskan ke HR Assistant (carry-over pending tetap untuk default)
        return $query
            ->with(['assignments', 'assignedUsers:id,name,role'])
            ->where(function ($q) use ($staffId) {
                $q->where(function ($q1) use ($staffId) {
                    $q1->where('created_by', $staffId)
                       ->where('type', 'assigned');
                })
                ->orWhereHas('assignments.user', function ($q2) {
                    $q2->where('role', 'hr_assistant');
                });
            })
            // assigned: hanya hari ini | default: hanya hari ini
            ->whereDate('task_date', Carbon::today())
            ->orderByDesc('task_date')
            ->orderByDesc('created_at')
            ->get();
    }

   public function findById(int $id): ?Task
    {
        /** @var Builder $query */
        $query = $this->model->newQuery();

        return $query->with(['assignments', 'assignedUsers'])->find($id);
    }

    public function create(array $data): Task
    {
        return $this->model->create($data);
    }

    public function update(Task $task, array $data): bool
    {
        return $task->update($data);
    }

    public function delete(Task $task): bool
    {
        /** @var Task $task */
        return $task->delete();
    }

    public function createAssignment(int $taskId, int $userId): TaskAssignment
    {
        return TaskAssignment::create([
            'task_id'      => $taskId,
            'user_id'      => $userId,
            'is_completed' => 'pending', 
        ]);
    }

    public function deleteAssignments(int $taskId): void
    {
        /** @var Builder $query */
        $query = TaskAssignment::query();
        $query->where('task_id', $taskId)->delete();
    }
    public function hasAnyCompleted(int $taskId): bool
    {
        /** @var Builder $query */
        $query = TaskAssignment::query();
    
        return $query
            ->where('task_id', $taskId)
            ->where('is_completed', 'completed')
            ->exists();
    }

    public function markAllPendingAsNotDone(string $today): int
    {
        /** @var Builder $query */
        $query = TaskAssignment::query();
    
        return $query
            ->whereHas('task', function ($q) use ($today) {
                // Hanya default task hingga hari ini yang masih pending
                // Tugas assigned dan self TIDAK ditandai not_done
                $q->whereDate('task_date', '<=', $today)
                  ->where('type', 'default');
            })
            ->where('is_completed', 'pending')
            ->update(['is_completed' => 'not_done']);
    }

    public function getSelfTasksToday(int $userId): Collection
    {
        $today = Carbon::today()->toDateString();
        /** @var Builder $query */
        $query = $this->model->newQuery();

        // Tampilkan tugas mandiri hari ini ATAU tugas mandiri lama yang masih pending ATAU diselesaikan hari ini
        return $query
            ->with(['assignments' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            }])
            ->where('created_by', $userId)
            ->where('type', 'self')
            ->whereDate('task_date', '<=', Carbon::today())
            ->where(function ($q) use ($userId, $today) {
                // Tugas hari ini selalu tampil
                $q->whereDate('task_date', $today)
                  // Tugas lama yang assignment-nya masih pending tetap tampil
                  ->orWhereHas('assignments', function ($q2) use ($userId) {
                      $q2->where('user_id', $userId)
                         ->where('is_completed', 'pending');
                  })
                  // Tugas lama yang diselesaikan hari ini tetap tampil
                  ->orWhereHas('assignments', function ($q2) use ($userId, $today) {
                      $q2->where('user_id', $userId)
                         ->where('is_completed', 'completed')
                         ->whereDate('completed_at', $today);
                  });
            })
            ->orderByDesc('task_date')
            ->orderByDesc('created_at')
            ->get();
    }

    public function findAssignment(int $taskId, int $userId): ?TaskAssignment
    {
        /** @var Builder $query */
        $query = TaskAssignment::query();

        return $query
            ->where('task_id', $taskId)
            ->where('user_id', $userId)
            ->first();
    }

    public function completeAssignment(TaskAssignment $assignment, ?string $note, ?string $attachment = null): bool
    {
        $data = [
            'is_completed' => 'completed',
            'completed_at' => now(),
            'note'         => $note,
        ];

        if ($attachment !== null) {
            $data['attachment'] = $attachment;
        }

        return (bool) $assignment->update($data);
    }

    public function getAllTasksForUserToday(int $userId): Collection
    {
        $today = Carbon::today()->toDateString();
        /** @var Builder $query */
        $query = $this->model->newQuery();

        return $query
            ->with(['assignments' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            }, 'creator:id,name'])
            ->whereHas('assignments', function ($q) use ($userId) {
                $q->where('user_id', $userId);
            })
            // default: hanya hari ini
            // assigned: hanya hari ini (tidak carry-over ke hari berikutnya)
            // self: hari ini ATAU masih pending ATAU diselesaikan hari ini
            ->where(function ($q) use ($userId, $today) {
                $q->where(function ($q2) use ($today) {
                      // default task: hanya hari ini
                      $q2->where('type', 'default')
                         ->whereDate('task_date', $today);
                  })
                  ->orWhere(function ($q2) use ($today) {
                      // assigned: hanya hari ini
                      $q2->where('type', 'assigned')
                         ->whereDate('task_date', $today);
                  })
                  ->orWhere(function ($q2) use ($userId, $today) {
                      // self: hari ini ATAU masih pending ATAU diselesaikan hari ini
                      $q2->where('type', 'self')
                         ->whereDate('task_date', '<=', $today)
                         ->where(function ($q3) use ($userId, $today) {
                             $q3->whereDate('task_date', $today)
                                ->orWhereHas('assignments', function ($q4) use ($userId, $today) {
                                    $q4->where('user_id', $userId)
                                       ->where(function ($q5) use ($today) {
                                           $q5->where('is_completed', 'pending')
                                              ->orWhere(function ($q6) use ($today) {
                                                  $q6->where('is_completed', 'completed')
                                                     ->whereDate('completed_at', $today);
                                              });
                                       });
                                });
                         });
                  });
            })
            ->orderByDesc('task_date')
            ->orderByDesc('created_at')
            ->get();
    }

    public function getHistoryForUser(int $userId, ?string $date = null, ?string $search = null): LengthAwarePaginator
    {
        // Ambil tugas regular dari tabel tasks
        $regularTasksQuery = $this->model->newQuery()
            ->with(['assignments' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            }, 'creator:id,name'])
            ->whereHas('assignments', function ($q) use ($userId) {
                $q->where('user_id', $userId);
            })
            ->when($date, function ($q) use ($date) {
                $q->whereDate('task_date', $date);
            })
            ->when($search, function ($q) use ($search) {
                $q->where(function ($q2) use ($search) {
                    $q2->where('title', 'like', '%' . $search . '%')
                       ->orWhere('description', 'like', '%' . $search . '%');
                });
            })
            ->orderByDesc('task_date')
            ->orderByDesc('created_at');

        // Ambil tugas sosmed dari tabel sosmed_tasks
        $sosmedTasksQuery = \App\Models\SosmedTask::query()
            ->with(['account', 'assignedUser', 'verifiedBy', 'hrVerifiedBy'])
            ->where('assigned_to', $userId)
            ->when($date, function ($q) use ($date) {
                $q->whereDate('task_date', $date);
            })
            ->when($search, function ($q) use ($search) {
                $q->where(function ($q2) use ($search) {
                    $q2->where('title', 'like', '%' . $search . '%')
                       ->orWhere('description', 'like', '%' . $search . '%')
                       ->orWhereHas('account', fn($qa) => $qa->where('name', 'like', '%' . $search . '%'));
                });
            });

        // Gabungkan hasil dan urutkan
        $regularTasks = $regularTasksQuery->get();
        $sosmedTasks = $sosmedTasksQuery->get();

        // Merge dan transform sosmed tasks menjadi format yang sesuai dengan view
        $allTasks = $regularTasks->merge($sosmedTasks->map(function ($sosmedTask) use ($userId) {
            // Transform sosmed task menjadi format task biasa
            $task = new \App\Models\Task();
            $task->id = 'sosmed_' . $sosmedTask->id; // Prefix untuk membedakan
            $task->title = $sosmedTask->title;
            $task->description = $sosmedTask->description;
            $task->task_date = $sosmedTask->task_date;
            $task->created_at = $sosmedTask->created_at;
            $task->updated_at = $sosmedTask->updated_at;
            $task->creator = $sosmedTask->assignedBy;

            // Buat assignment palsu untuk compatibility dengan view
            // is_completed menggunakan string status sosmed agar task-status-badge bisa mendeteksi dengan benar
            $assignment = new \stdClass();
            $assignment->is_completed = $sosmedTask->status; // 'approved_hr', 'verified_by_pm', 'done_by_staff', 'rejected', 'pending'
            $assignment->completed_at = $sosmedTask->status === 'approved_hr' ?
                                       ($sosmedTask->hr_verified_at ?? $sosmedTask->updated_at) : null;

            // Note berisi info status proses
            $noteMap = [
                'approved_hr'    => 'Disetujui Final oleh HR Staff',
                'verified_by_pm' => 'Menunggu Persetujuan Final HR',
                'done_by_staff'  => 'Menunggu Verifikasi PM / Asisten atau HR Staff',
                'rejected'       => 'Ditolak - Perlu Revisi',
                'pending'        => 'Belum Disubmit',
            ];
            $noteText = $noteMap[$sosmedTask->status] ?? $sosmedTask->status;
            if ($sosmedTask->hasLinks()) {
                $noteText .= ' | Bukti: ' . count($sosmedTask->link_upload) . ' link';
            }
            $assignment->note = $noteText;
            
            $task->setRelation('assignments', collect([$assignment]));
            
            return $task;
        }));

        // Urutkan berdasarkan task_date desc
        $allTasks = $allTasks->sortByDesc('task_date')->values();

        // Manual pagination
        $perPage = 8;
        $currentPage = request()->get('page', 1);
        $offset = ($currentPage - 1) * $perPage;
        
        $paginatedItems = $allTasks->slice($offset, $perPage)->values();
        
        return new \Illuminate\Pagination\LengthAwarePaginator(
            $paginatedItems,
            $allTasks->count(),
            $perPage,
            $currentPage,
            ['path' => request()->url(), 'query' => request()->query()]
        );
    }
    public function getHistoryForAdmin(?int $userId = null, ?string $date = null, ?string $search = null, int $perPage = 10)
    {
        /** @var Builder $query */
        $query = $this->model->newQuery();

        return $query
            ->with([
                'assignments' => function ($q) use ($userId) {
                    if ($userId) {
                        $q->where('user_id', $userId);
                    }
                },
                'assignedUsers:id,name,role',
                'creator:id,name',
            ])
            ->when($userId, function ($q) use ($userId) {
                $q->whereHas('assignments', function ($q) use ($userId) {
                    $q->where('user_id', $userId);
                });
            })
            ->when($date, function ($q) use ($date) {
                $q->whereDate('task_date', $date);
            })
            ->when($search, function ($q) use ($search) {
                $q->where(function ($q2) use ($search) {
                    $q2->where('title', 'like', '%' . $search . '%')
                       ->orWhere('description', 'like', '%' . $search . '%');
                });
            })
            ->orderByDesc('task_date')
            ->orderByDesc('created_at')
            ->paginate($perPage);
    }

    public function getTasksCreatedByAdmin(): Collection
    {
        /** @var Builder $query */
        $query = $this->model->newQuery();

        return $query
            ->with(['creator:id,name', 'assignments', 'assignedUsers:id,name,role'])
            ->whereHas('creator', function ($q) {
                $q->where('role', 'admin');
            })
            ->where('type', 'assigned')
            ->whereDate('task_date', Carbon::today())
            ->orderByDesc('created_at')
            ->get();
    }
    public function getTasksByStaff(): Collection
    {
        /** @var Builder $query */
        $query = $this->model->newQuery();

        // Tasks created by any standalone role (hr_staff, cs, ob) — self + assigned
        $staffCreatedTasks = $query
            ->with(['creator:id,name', 'assignments', 'assignedUsers:id,name,role'])
            ->whereHas('creator', function ($q) {
                $q->whereIn('role', ['hr_staff', 'cs', 'ob']);
            })
            ->whereIn('type', ['self', 'assigned'])
            ->whereDate('task_date', Carbon::today());

        // Union with tasks assigned by admin to ANY staff-level member
        return $staffCreatedTasks->union(
            Task::query()
                ->with(['creator:id,name', 'assignments', 'assignedUsers:id,name,role'])
                ->whereHas('assignments', function ($q) {
                    $q->whereHas('user', function ($q) {
                        $q->whereIn('role', ['hr_staff', 'cs', 'ob']);
                    });
                })
                ->whereHas('creator', function ($q) {
                    $q->where('role', 'admin');
                })
                ->where('type', 'assigned')
                ->whereDate('task_date', Carbon::today())
        )
        ->orderByDesc('created_at')
        ->get();
    }

    public function getAllTasksForAssistant(): Collection
    {
        $today = Carbon::today()->toDateString();
        /** @var Builder $query */
        $query = $this->model->newQuery();

        // default: hanya hari ini
        // assigned: hanya hari ini (tidak carry-over)
        // self: hari ini + pending lama + selesai hari ini
        return $query
            ->with(['creator:id,name', 'assignments', 'assignedUsers:id,name,role'])
            ->whereHas('assignments', function ($q) {
                $q->whereHas('user', function ($q) {
                    $q->where('role', 'hr_assistant');
                });
            })
            ->where(function ($q) use ($today) {
                $q->where(function ($q2) use ($today) {
                      // default: hanya hari ini
                      $q2->where('type', 'default')
                         ->whereDate('task_date', $today);
                  })
                  ->orWhere(function ($q2) use ($today) {
                      // assigned: hanya hari ini
                      $q2->where('type', 'assigned')
                         ->whereDate('task_date', $today);
                  })
                  ->orWhere(function ($q2) use ($today) {
                      // self: hari ini + pending lama + selesai hari ini
                      $q2->where('type', 'self')
                         ->whereDate('task_date', '<=', $today)
                         ->where(function ($q3) use ($today) {
                             $q3->whereDate('task_date', $today)
                                ->orWhereHas('assignments', function ($q4) use ($today) {
                                    $q4->whereHas('user', function ($q5) {
                                        $q5->where('role', 'hr_assistant');
                                    })
                                    ->where(function ($q6) use ($today) {
                                        $q6->where('is_completed', 'pending')
                                           ->orWhere(function ($q7) use ($today) {
                                               $q7->where('is_completed', 'completed')
                                                  ->whereDate('completed_at', $today);
                                           });
                                    });
                                });
                         });
                  });
            })
            ->orderByDesc('task_date')
            ->orderByDesc('created_at')
            ->get();
    }

    /**
     * Ambil semua tugas yang masuk ke role tertentu (cs, ob, programmer, vg, dg, pm, dst.)
     * dengan pola yang sama seperti getAllTasksForAssistant.
     */
    public function getAllTasksForRole(string $role, int $perPage = 20, ?string $date = null, ?string $search = null)
    {
        $filterDate = $date ?? Carbon::today()->toDateString();
        /** @var Builder $query */
        $query = $this->model->newQuery();

        return $query
            ->with(['creator:id,name', 'assignments', 'assignedUsers:id,name,role'])
            ->whereHas('assignments', function ($q) use ($role) {
                $q->whereHas('user', function ($q) use ($role) {
                    $q->where('role', $role);
                });
            })
            ->where(function ($q) use ($role, $filterDate) {
                $q->where(function ($q2) use ($filterDate) {
                      // default: pada tanggal yang dipilih
                      $q2->where('type', 'default')
                         ->whereDate('task_date', $filterDate);
                  })
                  ->orWhere(function ($q2) use ($filterDate) {
                      // assigned: pada tanggal yang dipilih
                      $q2->where('type', 'assigned')
                         ->whereDate('task_date', $filterDate);
                  })
                  ->orWhere(function ($q2) use ($role, $filterDate) {
                      // self: tanggal dipilih + pending lama + selesai di tanggal tsb
                      $q2->where('type', 'self')
                         ->whereDate('task_date', '<=', $filterDate)
                         ->where(function ($q3) use ($role, $filterDate) {
                             $q3->whereDate('task_date', $filterDate)
                                ->orWhereHas('assignments', function ($q4) use ($role, $filterDate) {
                                    $q4->whereHas('user', function ($q5) use ($role) {
                                        $q5->where('role', $role);
                                    })
                                    ->where(function ($q6) use ($filterDate) {
                                        $q6->where('is_completed', 'pending')
                                           ->orWhere(function ($q7) use ($filterDate) {
                                               $q7->where('is_completed', 'completed')
                                                  ->whereDate('completed_at', $filterDate);
                                           });
                                    });
                                });
                         });
                  });
            })
            ->when($search, function ($q) use ($search) {
                $q->where(function ($w) use ($search) {
                    $w->where('title', 'like', "%{$search}%")
                        ->orWhere('description', 'like', "%{$search}%")
                        ->orWhereHas('assignedUsers', function ($u) use ($search) {
                            $u->where('name', 'like', "%{$search}%");
                        });
                });
            })
            ->orderByDesc('task_date')
            ->orderByDesc('created_at')
            ->paginate($perPage);
    }

    public function isDefaultTaskAlreadyGenerated(int $defaultTaskId, string $date): bool
    {
        /** @var Builder $query */
        $query = $this->model->newQuery();

        return $query
            ->where('default_task_id', $defaultTaskId)
            ->whereDate('task_date', $date)
            ->exists();
    }
    public function getUsersByRole(string $role): Collection
    {
        return \App\Models\User::query()
            ->where('role', $role)
            ->where('is_active', 1)
            ->get();
    }

    public function getDailyStats(): array
    {
        $today = Carbon::today()->toDateString();

        // Assignment yang aktif/berlaku hari ini:
        // 1. Task hari ini (task_date == today)
        // 2. Task lama yang masih pending (task_date < today and is_completed == pending)
        // 3. Task lama yang diselesaikan HARI INI (is_completed == completed and DATE(completed_at) == today)
        $activeAssignmentFilter = function ($q) use ($today) {
            $q->where(function ($q2) use ($today) {
                $q2->whereHas('task', function ($t) use ($today) {
                    $t->whereDate('task_date', $today);
                });
            })->orWhere(function ($q2) use ($today) {
                $q2->whereHas('task', function ($t) use ($today) {
                    $t->whereDate('task_date', '<', $today);
                })->where(function ($q3) use ($today) {
                    $q3->where('is_completed', 'pending')
                       ->orWhere(function ($q4) use ($today) {
                           $q4->where('is_completed', 'completed')
                              ->whereDate('completed_at', $today);
                       });
                });
            });
        };

        $total = TaskAssignment::query()->whereHas('task')->where($activeAssignmentFilter)->count();

        $completed = TaskAssignment::query()->whereHas('task')->where('is_completed', 'completed')
            ->where(function ($q) use ($today) {
                $q->whereDate('completed_at', $today)
                  ->orWhere(function ($q2) use ($today) {
                      $q2->whereNull('completed_at')
                         ->whereHas('task', fn($t) => $t->whereDate('task_date', $today));
                  });
            })->count();

        $notDone = TaskAssignment::query()->whereHas('task', fn($t) => $t->whereDate('task_date', $today))
            ->where('is_completed', 'not_done')
            ->count();

        $pending = max(0, $total - $completed - $notDone);

        return [
            'total'     => $total,
            'completed' => $completed,
            'pending'   => $pending,
            'not_done'  => $notDone,
        ];
    }

    public function getDailyStatsPerUser(): Collection
    {
        $today = Carbon::today()->toDateString();

        return \App\Models\User::query()
            ->where('role', '!=', 'admin')
            ->where('is_active', 1)
            ->withCount([
                'taskAssignments as total_tasks' => function ($q) use ($today) {
                    $q->where(function ($q2) use ($today) {
                        $q2->whereHas('task', function ($t) use ($today) {
                            $t->whereDate('task_date', $today);
                        });
                    })->orWhere(function ($q2) use ($today) {
                        $q2->whereHas('task', function ($t) use ($today) {
                            $t->whereDate('task_date', '<', $today);
                        })->where(function ($q3) use ($today) {
                            $q3->where('is_completed', 'pending')
                               ->orWhere(function ($q4) use ($today) {
                                   $q4->where('is_completed', 'completed')
                                      ->whereDate('completed_at', $today);
                               });
                        });
                    });
                },
                'taskAssignments as completed_tasks' => function ($q) use ($today) {
                    $q->where('is_completed', 'completed')
                      ->where(function ($q2) use ($today) {
                          $q2->whereDate('completed_at', $today)
                             ->orWhere(function ($q3) use ($today) {
                                 $q3->whereNull('completed_at')
                                    ->whereHas('task', fn($t) => $t->whereDate('task_date', $today));
                             });
                      });
                },
                'taskAssignments as not_done_tasks' => function ($q) use ($today) {
                    $q->where('is_completed', 'not_done')
                      ->whereHas('task', function ($t) use ($today) {
                          $t->whereDate('task_date', $today);
                      });
                },
            ])
            ->orderBy('role')
            ->orderBy('name')
            ->get();
    }

    /**
     * Ringkasan progres tim: belum/sudah dikerjakan (khusus tugas yang diberikan
     * HARI INI, mencakup tugas reguler/rutin/presensi/mandiri + tugas sosmed
     * termasuk akun binaan yang belum menyetor hari ini) dan total tugas all-time.
     *
     * @param  string[]  $excludeRoles  Role yang tidak ditampilkan (mis. ['admin'] / ['admin','hr_staff'])
     */
    public function getTeamProgressOverview(array $excludeRoles = ['admin']): Collection
    {
        $today = Carbon::today()->toDateString();

        $users = User::query()
            ->where('is_active', 1)
            ->whereNotIn('role', $excludeRoles)
            ->orderBy('role')
            ->orderBy('name')
            ->get();

        if ($users->isEmpty()) {
            return $users;
        }

        $ids = $users->pluck('id')->all();

        // Tugas reguler (default/rutin/presensi/mandiri/assigned) yang task_date-nya hari ini
        $regToday = DB::table('task_assignments')
            ->join('tasks', 'tasks.id', '=', 'task_assignments.task_id')
            ->whereIn('task_assignments.user_id', $ids)
            ->whereDate('tasks.task_date', $today)
            ->selectRaw("task_assignments.user_id,
                SUM(task_assignments.is_completed = 'completed') AS done,
                SUM(task_assignments.is_completed <> 'completed') AS undone")
            ->groupBy('task_assignments.user_id')
            ->get()
            ->keyBy('user_id');

        $regAllTime = DB::table('task_assignments')
            ->whereIn('user_id', $ids)
            ->selectRaw('user_id, COUNT(*) AS total')
            ->groupBy('user_id')
            ->pluck('total', 'user_id');

        // Tugas sosmed hari ini milik user (penugasan langsung)
        $sosToday = DB::table('sosmed_tasks')
            ->whereIn('assigned_to', $ids)
            ->whereDate('task_date', $today)
            ->selectRaw("assigned_to AS user_id,
                SUM(status = 'approved_hr') AS done,
                SUM(status <> 'approved_hr') AS undone")
            ->groupBy('assigned_to')
            ->get()
            ->keyBy('user_id');

        $sosAllTime = DB::table('sosmed_tasks')
            ->whereIn('assigned_to', $ids)
            ->selectRaw('assigned_to AS user_id, COUNT(*) AS total')
            ->groupBy('assigned_to')
            ->pluck('total', 'user_id');

        // Akun yang ia pegang vs akun yang sudah ada tugasnya hari ini → selisihnya = pending virtual
        $managedAccounts = DB::table('sosmed_account_users')
            ->whereIn('user_id', $ids)
            ->selectRaw('user_id, COUNT(DISTINCT sosmed_account_id) AS cnt')
            ->groupBy('user_id')
            ->pluck('cnt', 'user_id');

        $managedWithTodayTask = DB::table('sosmed_tasks')
            ->whereIn('assigned_to', $ids)
            ->whereDate('task_date', $today)
            ->selectRaw('assigned_to AS user_id, COUNT(DISTINCT sosmed_account_id) AS cnt')
            ->groupBy('assigned_to')
            ->pluck('cnt', 'user_id');

        foreach ($users as $user) {
            $id = $user->id;

            $sudah = (int) ($regToday[$id]->done ?? 0) + (int) ($sosToday[$id]->done ?? 0);
            $belum = (int) ($regToday[$id]->undone ?? 0) + (int) ($sosToday[$id]->undone ?? 0);
            $belum += max(0, (int) ($managedAccounts[$id] ?? 0) - (int) ($managedWithTodayTask[$id] ?? 0));

            $user->belum_hari_ini = $belum;
            $user->sudah_hari_ini = $sudah;
            $user->tugas_hari_ini = $belum + $sudah;
            $user->total_all_time = (int) ($regAllTime[$id] ?? 0) + (int) ($sosAllTime[$id] ?? 0);
            $user->persen_hari_ini  = $user->tugas_hari_ini > 0
                ? (int) round($sudah / $user->tugas_hari_ini * 100)
                : 0;
        }

        return $users;
    }

    public function getUserScore(int $userId, string $period): int
    {
        /** @var Builder $query */
        $query = TaskAssignment::query();

        $query->where('user_id', $userId)
            ->where('is_completed', 'completed');

        if ($period === 'week') {
            $start = Carbon::now()->startOfWeek();
            $end   = Carbon::now()->endOfWeek();
            $query->where(function ($q) use ($start, $end) {
                $q->whereBetween('completed_at', [$start, $end])
                  ->orWhere(function ($q2) use ($start, $end) {
                      $q2->whereNull('completed_at')
                         ->whereHas('task', function ($t) use ($start, $end) {
                             $t->whereBetween('task_date', [$start, $end]);
                         });
                  });
            });
        } elseif ($period === 'month') {
            $month = Carbon::now()->month;
            $year  = Carbon::now()->year;
            $query->where(function ($q) use ($month, $year) {
                $q->where(function ($q2) use ($month, $year) {
                    $q2->whereMonth('completed_at', $month)
                       ->whereYear('completed_at', $year);
                })->orWhere(function ($q2) use ($month, $year) {
                    $q2->whereNull('completed_at')
                       ->whereHas('task', function ($t) use ($month, $year) {
                           $t->whereMonth('task_date', $month)
                             ->whereYear('task_date', $year);
                       });
                });
            });
        }
        return $query->count();
    }
    
    public function getDefaultTasksForUser(int $userId): Collection
    {
        /** @var Builder $query */
        $query = $this->model->newQuery();
    
        return $query
            ->with(['assignments' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            }])
            ->whereHas('assignments', function ($q) use ($userId) {
                $q->where('user_id', $userId);
            })
            ->where('type', 'default')
            ->whereDate('task_date', Carbon::today())
            ->orderByDesc('created_at')
            ->get();
    }
    
    public function getAssignedTasksFromAdmin(int $userId): Collection
    {
        $today = Carbon::today()->toDateString();
        /** @var Builder $query */
        $query = $this->model->newQuery();

        // Tampilkan tugas dari admin: hari ini ATAU masih pending dari hari sebelumnya ATAU diselesaikan hari ini
        return $query
            ->with(['assignments' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            }, 'creator:id,name'])
            ->whereHas('assignments', function ($q) use ($userId) {
                $q->where('user_id', $userId);
            })
            ->whereHas('creator', function ($q) {
                $q->where('role', 'admin');
            })
            ->where('type', 'assigned')
            ->whereDate('task_date', '<=', Carbon::today())
            ->where(function ($q) use ($userId, $today) {
                $q->whereDate('task_date', $today)
                  ->orWhereHas('assignments', function ($q2) use ($userId, $today) {
                      $q2->where('user_id', $userId)
                         ->where(function ($q3) use ($today) {
                             $q3->where('is_completed', 'pending')
                                ->orWhere(function ($q4) use ($today) {
                                    $q4->where('is_completed', 'completed')
                                       ->whereDate('completed_at', $today);
                                });
                         });
                  });
            })
            ->orderByDesc('task_date')
            ->orderByDesc('created_at')
            ->get();
    }

    public function getDefaultTasksForAssistant(int $userId): Collection
    {
        /** @var Builder $query */
        $query = $this->model->newQuery();
    
        return $query
            ->with(['assignments' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            }])
            ->whereHas('assignments', function ($q) use ($userId) {
                $q->where('user_id', $userId);
            })
            ->where('type', 'default')
            ->whereDate('task_date', Carbon::today())
            ->orderByDesc('created_at')
            ->get();
    }
    
    public function getAllAssignedTasksForAssistant(int $userId): Collection
    {
        $today = Carbon::today()->toDateString();
        /** @var Builder $query */
        $query = $this->model->newQuery();

        // Tampilkan tugas dari admin/staff: HANYA hari ini (tidak carry-over ke hari berikutnya)
        return $query
            ->with(['assignments' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            }, 'creator:id,name,role'])
            ->whereHas('assignments', function ($q) use ($userId) {
                $q->where('user_id', $userId);
            })
            ->where('type', 'assigned')
            ->whereDate('task_date', $today)
            ->orderByDesc('task_date')
            ->orderByDesc('created_at')
            ->get();
    }

    public function getDailyStatsForAssistants(): Collection
    {
        $today = Carbon::today()->toDateString();

        return \App\Models\User::query()
            ->where('role', 'hr_assistant')
            ->where('is_active', 1)
            ->withCount([
                'taskAssignments as total_tasks' => function ($q) use ($today) {
                    $q->where(function ($q2) use ($today) {
                        $q2->whereHas('task', function ($t) use ($today) {
                            $t->whereDate('task_date', $today);
                        });
                    })->orWhere(function ($q2) use ($today) {
                        $q2->whereHas('task', function ($t) use ($today) {
                            $t->whereDate('task_date', '<', $today);
                        })->where(function ($q3) use ($today) {
                            $q3->where('is_completed', 'pending')
                               ->orWhere(function ($q4) use ($today) {
                                   $q4->where('is_completed', 'completed')
                                      ->whereDate('completed_at', $today);
                               });
                        });
                    });
                },
                'taskAssignments as completed_tasks' => function ($q) use ($today) {
                    $q->where('is_completed', 'completed')
                      ->where(function ($q2) use ($today) {
                          $q2->whereDate('completed_at', $today)
                             ->orWhere(function ($q3) use ($today) {
                                 $q3->whereNull('completed_at')
                                    ->whereHas('task', fn($t) => $t->whereDate('task_date', $today));
                             });
                      });
                },
                'taskAssignments as not_done_tasks' => function ($q) use ($today) {
                    $q->where('is_completed', 'not_done')
                      ->whereHas('task', function ($t) use ($today) {
                          $t->whereDate('task_date', $today);
                      });
                },
            ])
            ->orderBy('name')
            ->get();
    }

    // ── Admin: kelola assignment milik bawahan ───────────

    public function findAssignmentById(int $assignmentId): ?TaskAssignment
    {
        return TaskAssignment::with('task')->find($assignmentId);
    }

    public function adminCompleteAssignment(TaskAssignment $assignment): bool
    {
        return (bool) $assignment->update([
            'is_completed' => 'completed',
            'completed_at' => now(),
        ]);
    }

    public function deleteAssignmentById(int $assignmentId): bool
    {
        /** @var Builder $query */
        $query = TaskAssignment::query();
        return (bool) $query->where('id', $assignmentId)->delete();
    }

    // ── Laporan Produktivitas: rentang tanggal ───────────

    /**
     * Ringkasan produktivitas semua user (hr_staff + hr_assistant)
     * dalam rentang tanggal dateFrom – dateTo.
     *
     * @return \Illuminate\Support\Collection<int, array{user: \App\Models\User, total: int, completed: int, pending: int, not_done: int, pct: int}>
     */
    public function getProductivityByRange(string $dateFrom, string $dateTo, ?string $role = null, ?array $allowedRoles = null): \Illuminate\Support\Collection
    {
        $query = \App\Models\User::query()
            ->where('is_active', 1);

        if ($allowedRoles !== null) {
            $query->whereIn('role', $allowedRoles);
        } else {
            $query->where('role', '!=', 'admin');
        }

        if (!empty($role) && $role !== 'all') {
            $query->where('role', $role);
        }

        $users = $query->orderBy('role')
            ->orderBy('name')
            ->get();

        return $users->map(function ($user) use ($dateFrom, $dateTo) {
            $assignments = TaskAssignment::query()
                ->with('task:id,title,description,task_date')
                ->where('user_id', $user->id)
                ->whereHas('task', function ($q) use ($dateFrom, $dateTo) {
                    $q->whereBetween('task_date', [$dateFrom, $dateTo]);
                })
                ->get();

            $total     = $assignments->count();
            $completed = $assignments->where('is_completed', 'completed')->count();
            $notDone   = $assignments->where('is_completed', 'not_done')->count();
            $pending   = $total - $completed - $notDone;
            $pct       = $total > 0 ? round(($completed / $total) * 100) : 0;

            $details = $assignments->map(fn ($assignment) => [
                'title' => $assignment->task?->title ?? 'Tugas tanpa judul',
                'description' => $assignment->task?->description ?? '',
                'date' => $assignment->task?->task_date?->format('d M Y') ?? '-',
                'status' => $assignment->is_completed,
                'note' => $assignment->note ?? '',
            ])->values()->all();

            return compact('user', 'total', 'completed', 'pending', 'notDone', 'pct', 'details');
        });
    }

    /**
     * Detail tugas satu user dalam rentang tanggal dateFrom – dateTo,
     * dikelompokkan per hari (task_date), diurutkan terbaru dahulu.
     */
    public function getProductivityDetailForUser(int $userId, string $dateFrom, string $dateTo): Collection
    {
        /** @var Builder $query */
        $query = $this->model->newQuery();

        return $query
            ->with([
                'assignments' => function ($q) use ($userId) {
                    $q->where('user_id', $userId);
                },
                'creator:id,name,role',
            ])
            ->whereHas('assignments', function ($q) use ($userId) {
                $q->where('user_id', $userId);
            })
            ->whereBetween('task_date', [$dateFrom, $dateTo])
            ->orderByDesc('task_date')
            ->orderByDesc('created_at')
            ->get();
    }
}
