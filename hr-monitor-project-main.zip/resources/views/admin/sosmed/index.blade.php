@extends('layouts.app')
@section('title', 'Manajemen Akun & Monitoring Sosmed')
@section('page-title', 'Manajemen Akun & Monitoring Sosmed')
@section('page-subtitle', 'Kelola seluruh akun sosmed, delegasi penugasan & audit trail approval')
@section('sidebar')
    @include('components.sidebar-admin')
@endsection

@section('content')
    @php
        $executorsJson = json_encode($executors->map(fn($e) => [
            'id' => $e->id,
            'name' => $e->name,
            'role' => $e->role,
            'role_label' => match($e->role) {
                'pm' => 'PM Mandiri',
                'sosmed' => 'Staff Sosmed',
                'digital_marketing' => 'Digital Marketing',
                default => $e->role_label ?? strtoupper($e->role)
            }
        ]));
    @endphp
    @include('components.notification-popup')

    {{-- ═══════════════════════════════════════════════════════════════ --}}
    {{-- STAT CARDS --}}
    {{-- ═══════════════════════════════════════════════════════════════ --}}
    <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 mb-6">
        <a href="{{ route('admin.sosmed.index', ['tab' => 'accounts']) }}"
            class="block bg-white rounded-xl border {{ $tab === 'accounts' && !$accFilter ? 'border-gray-400 ring-2 ring-gray-300/40' : 'border-gray-200 hover:border-gray-300' }} p-4 shadow-sm transition">
            <p class="text-xs font-medium text-gray-500 mb-1">Total Akun</p>
            <p class="text-2xl font-bold text-gray-800">{{ $stats['total_accounts'] }}</p>
            <p class="text-[11px] text-gray-400 mt-0.5">akun terdaftar</p>
        </a>
        <a href="{{ route('admin.sosmed.index', ['tab' => 'accounts', 'acc_filter' => 'unassigned_pm']) }}"
            class="block bg-white rounded-xl border {{ $accFilter === 'unassigned_pm' ? 'border-amber-400 bg-amber-50/30 ring-2 ring-amber-300/50' : ($stats['unassigned_pm'] > 0 ? 'border-amber-300 bg-amber-50/20 hover:border-amber-400' : 'border-gray-200 hover:border-amber-300') }} p-4 shadow-sm transition">
            <p class="text-xs font-medium text-gray-500 mb-1">Belum Ada PM</p>
            <p class="text-2xl font-bold text-amber-600">{{ $stats['unassigned_pm'] }}</p>
            <p class="text-[11px] text-amber-600 mt-0.5">perlu assign PM</p>
        </a>
        <a href="{{ route('admin.sosmed.index', ['tab' => 'accounts', 'acc_filter' => 'unassigned_staff']) }}"
            class="block bg-white rounded-xl border {{ $accFilter === 'unassigned_staff' ? 'border-orange-400 bg-orange-50/30 ring-2 ring-orange-300/50' : ($stats['unassigned_staff'] > 0 ? 'border-orange-300 bg-orange-50/20 hover:border-orange-400' : 'border-gray-200 hover:border-orange-300') }} p-4 shadow-sm transition">
            <p class="text-xs font-medium text-gray-500 mb-1">Belum Ada Staff</p>
            <p class="text-2xl font-bold text-orange-600">{{ $stats['unassigned_staff'] }}</p>
            <p class="text-[11px] text-orange-600 mt-0.5">perlu assign Sosmed</p>
        </a>
        <a href="{{ route('admin.sosmed.index', ['tab' => 'tasks']) }}"
            class="block bg-white rounded-xl border {{ $tab === 'tasks' && !$taskStatus ? 'border-indigo-400 ring-2 ring-indigo-300/40' : 'border-gray-200 hover:border-indigo-300' }} p-4 shadow-sm transition">
            <p class="text-xs font-medium text-gray-500 mb-1">Total Tugas</p>
            <p class="text-2xl font-bold text-indigo-600">{{ $stats['total_tasks'] }}</p>
            <p class="text-[11px] text-gray-400 mt-0.5">harian & custom</p>
        </a>
        <a href="{{ route('admin.sosmed.index', ['tab' => 'tasks', 'task_status' => 'done_by_staff']) }}"
            class="block bg-white rounded-xl border {{ $taskStatus === 'done_by_staff' ? 'border-blue-400 bg-blue-50/30 ring-2 ring-blue-300/50' : 'border-gray-200 hover:border-blue-300' }} p-4 shadow-sm transition">
            <p class="text-xs font-medium text-gray-500 mb-1">Verif Level 1 (PM)</p>
            <p class="text-2xl font-bold text-blue-600">{{ $stats['need_pm_verify'] }}</p>
            <p class="text-[11px] text-gray-400 mt-0.5">tugas menunggu PM</p>
        </a>
        <a href="{{ route('admin.sosmed.index', ['tab' => 'staff_approvals']) }}"
            class="block bg-white rounded-xl border {{ $tab === 'staff_approvals' || $stats['need_admin_verify'] > 0 ? 'border-purple-400 bg-purple-50/30 ring-2 ring-purple-400/30' : 'border-gray-200 hover:border-purple-300' }} p-4 shadow-sm transition">
            <p class="text-xs font-medium text-purple-700 mb-1">Verifikasi Tugas (ACC)</p>
            <p class="text-2xl font-bold text-purple-600">{{ $stats['need_admin_verify'] }}</p>
            <p class="text-[11px] text-purple-600 mt-0.5">menunggu ACC Admin</p>
        </a>
        <a href="{{ route('admin.sosmed.index', ['tab' => 'tasks', 'task_status' => 'verified_by_pm']) }}"
            class="block bg-white rounded-xl border {{ $taskStatus === 'verified_by_pm' ? 'border-purple-400 bg-purple-50/30 ring-2 ring-purple-300/50' : 'border-gray-200 hover:border-purple-300' }} p-4 shadow-sm transition">
            <p class="text-xs font-medium text-gray-500 mb-1">Verif Level 2 (HR)</p>
            <p class="text-2xl font-bold text-purple-600">{{ $stats['need_hr_verify'] }}</p>
            <p class="text-[11px] text-gray-400 mt-0.5">tugas menunggu HR</p>
        </a>

        <a href="{{ route('admin.sosmed.index', ['tab' => 'tasks', 'task_status' => 'approved_hr']) }}"
            class="col-span-1 block bg-white rounded-xl border {{ $taskStatus === 'approved_hr' ? 'border-emerald-400 bg-emerald-50/30 ring-2 ring-emerald-300/50' : 'border-gray-200 hover:border-emerald-300' }} p-4 shadow-sm transition">
            <p class="text-xs font-medium text-gray-500 mb-1">Selesai Final</p>
            <p class="text-2xl font-bold text-emerald-600">{{ $stats['completed'] }}</p>
            <p class="text-[11px] text-emerald-600 mt-0.5">approved final</p>
        </a>
    </div>

    {{-- ═══════════════════════════════════════════════════════════════ --}}
    {{-- TABS & CONTENT --}}
    {{-- ═══════════════════════════════════════════════════════════════ --}}
    <div class="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        {{-- Navigation Tabs --}}
        <div class="flex border-b border-gray-200 overflow-x-auto scrollbar-none">
            <a href="{{ route('admin.sosmed.index', ['tab' => 'accounts']) }}"
                class="flex items-center gap-2 px-5 py-3.5 text-sm font-medium whitespace-nowrap border-b-2 transition
                                                                                                                                                                            {{ $tab === 'accounts' ? 'border-primary-600 text-primary-600 bg-primary-50/50' : 'border-transparent text-gray-500 hover:text-gray-700' }}">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
                Seluruh Akun Sosmed ({{ $accounts->total() }})
            </a>
            <a href="{{ route('admin.sosmed.index', ['tab' => 'staff_approvals']) }}"
                class="flex items-center gap-2 px-5 py-3.5 text-sm font-medium whitespace-nowrap border-b-2 transition
                                                                                                                                                                            {{ $tab === 'staff_approvals' ? 'border-purple-600 text-purple-600 bg-purple-50/50' : 'border-transparent text-gray-500 hover:text-gray-700' }}">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Verifikasi Tugas Sosmed
                @if($stats['need_admin_verify'] > 0)
                    <span class="ml-1 px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-purple-600 text-white">
                        {{ $stats['need_admin_verify'] }}
                    </span>
                @endif
            </a>
            <a href="{{ route('admin.sosmed.index', ['tab' => 'tasks']) }}"
                class="flex items-center gap-2 px-5 py-3.5 text-sm font-medium whitespace-nowrap border-b-2 transition
                                                                                                                                                                            {{ $tab === 'tasks' ? 'border-primary-600 text-primary-600 bg-primary-50/50' : 'border-transparent text-gray-500 hover:text-gray-700' }}">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                </svg>
                Monitoring Seluruh Tugas ({{ $tasks->total() }})
            </a>
            <a href="{{ route('admin.sosmed.index', ['tab' => 'logs']) }}"
                class="flex items-center gap-2 px-5 py-3.5 text-sm font-medium whitespace-nowrap border-b-2 transition
                                                                                                                                                                            {{ $tab === 'logs' ? 'border-primary-600 text-primary-600 bg-primary-50/50' : 'border-transparent text-gray-500 hover:text-gray-700' }}">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
                Audit Trail & Log Approval
            </a>
        </div>

        {{-- ── TAB 1: SELURUH AKUN SOSMED ─────────────────────────────── --}}
        @if($tab === 'accounts')
                <div class="p-4 sm:p-5">
                    {{-- Header: Judul kiri, Filter + Tombol kanan — semua sejajar satu baris --}}
                    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-4">
                        {{-- Kiri: Judul & Deskripsi --}}
                        <div class="min-w-0">
                            <h3 class="text-sm font-semibold text-gray-800">Distribusi & Penugasan Akun Sosial Media</h3>
                            <p class="text-xs text-gray-500 mt-0.5">Pemberian tugas pengelolaan akun sosial media kepada eksekutor (Staff Sosmed / PM)</p>
                            @if($accFilter)
                                <span
                                    class="inline-flex items-center gap-1.5 mt-1.5 px-2 py-1 rounded-md text-[11px] font-semibold {{ $accFilter === 'unassigned_pm' ? 'bg-amber-100 text-amber-700' : 'bg-orange-100 text-orange-700' }}">
                                    Filter aktif: {{ $accFilter === 'unassigned_pm' ? 'Belum Ada PM' : 'Belum Ada Staff' }}
                                    <a href="{{ route('admin.sosmed.index', ['tab' => 'accounts']) }}" class="hover:underline"
                                        title="Hapus filter">&times;</a>
                                </span>
                            @endif
                        </div>

                        {{-- Kanan: Form Pencarian + Tombol Aksi --}}
                        <div class="flex items-center gap-2 shrink-0 flex-wrap">
                            <form action="{{ route('admin.sosmed.index') }}" method="GET" class="flex items-center gap-2 flex-wrap sm:flex-nowrap">
                                <input type="hidden" name="tab" value="accounts">
                                @if($accFilter)
                                    <input type="hidden" name="acc_filter" value="{{ $accFilter }}">
                                @endif
                                <select name="brand"
                                    class="h-9 px-2.5 text-xs bg-white border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 text-gray-700 transition cursor-pointer"
                                    onchange="this.form.submit()">
                                    <option value="">Semua Brand</option>
                                    @foreach($brands as $b)
                                        <option value="{{ $b }}" {{ ($brand ?? '') === $b ? 'selected' : '' }}>{{ $b }}</option>
                                    @endforeach
                                </select>
                                <select name="search_type"
                                    class="h-9 px-2.5 text-xs bg-white border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 text-gray-700 transition cursor-pointer"
                                    onchange="if(this.form.account_search.value) this.form.submit()">
                                    <option value="all" {{ ($searchType ?? 'all') === 'all' ? 'selected' : '' }}>Semua Kriteria</option>
                                    <option value="brand" {{ ($searchType ?? 'all') === 'brand' ? 'selected' : '' }}>Brand</option>
                                    <option value="account" {{ ($searchType ?? 'all') === 'account' ? 'selected' : '' }}>Nama Akun</option>
                                    <option value="manager" {{ ($searchType ?? 'all') === 'manager' ? 'selected' : '' }}>Pengelola Akun</option>
                                    <option value="pm" {{ ($searchType ?? 'all') === 'pm' ? 'selected' : '' }}>Supervisor PM</option>
                                    <option value="assistant" {{ ($searchType ?? 'all') === 'assistant' ? 'selected' : '' }}>Asisten Pengawas</option>
                                    <option value="staff" {{ ($searchType ?? 'all') === 'staff' ? 'selected' : '' }}>Staff Pengawas</option>
                                </select>
                                <div class="relative flex items-center">
                                    <input type="text" name="account_search" value="{{ $accountSearch ?? '' }}"
                                        placeholder="Cari akun, brand, pengelola..."
                                        class="h-9 pl-3 pr-8 text-xs bg-white border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 text-gray-700 transition w-44 sm:w-52">
                                    <button type="submit" class="absolute right-2 text-gray-400 hover:text-primary-600 transition" title="Cari">
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                        </svg>
                                    </button>
                                </div>
                                @if($accountSearch || ($searchType ?? 'all') !== 'all' || $brand || $accFilter)
                                    <a href="{{ route('admin.sosmed.index', ['tab' => 'accounts']) }}"
                                        class="inline-flex items-center justify-center h-9 px-2.5 text-xs font-medium text-gray-500 hover:text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition shrink-0"
                                        title="Reset pencarian & filter">
                                        Reset
                                    </a>
                                @endif
                            </form>
                            <button onclick="openAssignTaskModal()"
                                class="inline-flex items-center justify-center gap-1.5 px-4 py-2 h-9 bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold rounded-lg transition shadow-sm shrink-0">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                                </svg>
                                Beri Tugas
                            </button>
                        </div>
                    </div>

                    {{-- Desktop Table (md+) --}}
                    <div class="hidden md:block overflow-x-auto rounded-lg border border-gray-100">
                        <table class="w-full table-fixed text-sm">
                            <colgroup>
                                <col class="w-[24%]"> {{-- Nama Akun & Catatan --}}
                                <col class="w-28"> {{-- Platform --}}
                                <col class="w-32"> {{-- Link URL --}}
                                <col class="w-36"> {{-- Eksekutor --}}
                                <col class="w-36"> {{-- Supervisor PM --}}
                                <col class="w-36"> {{-- Asisten Pengawas --}}
                                <col class="w-36"> {{-- Staff Pengawas --}}
                                <col class="w-28"> {{-- Aksi --}}
                            </colgroup>
                            <thead>
                                <tr class="bg-gray-50 border-b border-gray-200 text-xs font-semibold text-gray-500 tracking-wide">
                                    <th class="px-4 py-3 text-left">Nama Akun</th>
                                    <th class="px-4 py-3 text-left">Platform</th>
                                    <th class="px-4 py-3 text-left">URL</th>
                                    <th class="px-4 py-3 text-left">Dikelola</th>
                                    <th class="px-4 py-3 text-left">PM</th>
                                    <th class="px-4 py-3 text-left">Asisten Pengawas</th>
                                    <th class="px-4 py-3 text-left">Staff Pengawas</th>
                                    <th class="px-4 py-3 text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                @forelse($accounts as $acc)
                                    @php
                                        $managers = $acc->staffUsers;
                                        $hasManagers = $managers->count() > 0;

                                        // Ketika search berdasarkan nama pengelola, filter baris agar
                                        // hanya pengelola yang namanya cocok yang ditampilkan
                                        if ($accountSearch && $searchType === 'manager') {
                                            $filteredManagers = $managers->filter(
                                                fn($u) => str_contains(strtolower($u->name), strtolower(trim($accountSearch)))
                                            );
                                            $rows = $filteredManagers->count() > 0 ? $filteredManagers : collect([null]);
                                        } elseif ($accountSearch && $searchType === 'all') {
                                            // Mode 'all': jika pencariannya karena pengelola, filter baris ke pengelola yg cocok
                                            // Jika akun itu sendiri yg cocok (by name), tampilkan semua pengelolanya
                                            $accNameMatch = str_contains(strtolower($acc->name), strtolower(trim($accountSearch)))
                                                || str_contains(strtolower($acc->username ?? ''), strtolower(trim($accountSearch)));
                                            if (!$accNameMatch) {
                                                $filteredManagers = $managers->filter(
                                                    fn($u) => str_contains(strtolower($u->name), strtolower(trim($accountSearch)))
                                                );
                                                $rows = $filteredManagers->count() > 0 ? $filteredManagers : ($hasManagers ? $managers : collect([null]));
                                            } else {
                                                $rows = $hasManagers ? $managers : collect([null]);
                                            }
                                        } else {
                                            // Kalau belum ada pengelola, tetap tampilkan 1 baris kosong
                                            $rows = $hasManagers ? $managers : collect([null]);
                                        }
                                    @endphp

                                    @foreach($rows as $stUser)
                                        @php
                                            $staffRoleTag = $stUser ? match ($stUser->role) {
                                                'pm' => 'PM Mandiri',
                                                'sosmed' => 'Staff Sosmed',
                                                'digital_marketing' => 'Digital Marketing',
                                                'hr_assistant' => 'HR Assistant',
                                                'hr_staff' => 'HR Staff',
                                                default => $stUser->role_label ?? strtoupper($stUser->role)
                                            } : null;

                                            // Logic verifikasi berdasarkan ROLE pengelola di baris ini
                                            $isDirectAdmin = $stUser && $stUser->role === 'hr_staff';
                                            $isDirectHr    = $stUser && in_array($stUser->role, ['pm', 'hr_assistant']);
                                        @endphp

                                        <tr class="hover:bg-gray-50/80 transition align-middle">
                                            {{-- Nama Akun --}}
                                            <td class="px-4 py-3.5 min-w-[180px]">
                                                <div class="flex items-center gap-1.5 min-w-0">
                                                    <span class="font-semibold text-gray-800 truncate min-w-0" title="{{ $acc->name }}">
                                                        {{ $acc->name }}
                                                    </span>
                                                    <x-brand-badge :acc="$acc" :logos="$brandLogos" />
                                                </div>
                                                @if($acc->notes)
                                                    <p class="text-xs text-gray-400 mt-0.5 truncate max-w-full block" title="{{ $acc->notes }}">
                                                        {{ $acc->notes }}
                                                    </p>
                                                @endif
                                            </td>

                                            {{-- Platform --}}
                                            <td class="px-4 py-3.5">
                                                <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium border whitespace-nowrap {{ $acc->platform_color }}">
                                                    {{ $acc->platform_icon }} {{ $acc->platform }}
                                                </span>
                                            </td>

                                            {{-- URL --}}
                                            <td class="px-4 py-3.5">
                                                @if($acc->link)
                                                    <a href="{{ $acc->link }}" target="_blank"
                                                    class="inline-flex items-center gap-1 text-xs text-primary-600 hover:underline truncate max-w-full block"
                                                    title="{{ $acc->link }}">
                                                        <svg class="w-3 h-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                                d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                                                        </svg>
                                                        <span class="truncate">Buka</span>
                                                    </a>
                                                @else
                                                    <span class="text-xs text-gray-300">—</span>
                                                @endif
                                            </td>

                                            {{-- Dikelola (1 orang saja per baris) --}}
                                            <td class="px-4 py-3 text-xs min-w-0">
                                                @if($stUser)
                                                    <div class="min-w-0">
                                                        <span class="font-semibold text-gray-800 block truncate" title="{{ $stUser->name }}">
                                                            {{ $stUser->name }}
                                                        </span>
                                                        <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold mt-0.5
                                                            {{ $stUser->role === 'pm' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' : 'bg-pink-50 text-pink-700 border border-pink-200' }}">
                                                            {{ $staffRoleTag }}
                                                        </span>
                                                    </div>
                                                @else
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600 whitespace-nowrap">
                                                        Belum Ditugaskan
                                                    </span>
                                                @endif
                                            </td>

                                            {{-- PM (berdasarkan role pengelola di baris ini) --}}
                                            <td class="px-4 py-3 text-xs min-w-0">
                                                @if($isDirectAdmin)
                                                    <span class="text-gray-400 text-[11px] block">Langsung ke Admin</span>
                                                @elseif($isDirectHr)
                                                    <span class="text-gray-400 text-[11px] block">Langsung ke HR</span>
                                                @elseif($acc->pmUser)
                                                    <div class="min-w-0">
                                                        <span class="font-semibold text-gray-800 block truncate" title="{{ $acc->pmUser->name }}">
                                                            {{ $acc->pmUser->name }}
                                                        </span>
                                                        <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold mt-1 bg-purple-50 text-purple-700 border border-purple-200">
                                                            Supervisor PM
                                                        </span>
                                                    </div>
                                                @else
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600 whitespace-nowrap">
                                                        Belum Ada PM
                                                    </span>
                                                @endif
                                            </td>

                                            {{-- Asisten Pengawas --}}
                                            <td class="px-4 py-3 text-xs min-w-0">
                                                @if($isDirectAdmin)
                                                    <span class="text-gray-400 text-[11px] block">Langsung ke Admin</span>
                                                @elseif($isDirectHr)
                                                    <span class="text-gray-400 text-[11px] block">Langsung ke HR</span>
                                                @elseif($acc->assistantUser)
                                                    <div class="min-w-0">
                                                        <span class="font-semibold text-gray-800 block truncate" title="{{ $acc->assistantUser->name }}">
                                                            {{ $acc->assistantUser->name }}
                                                        </span>
                                                        <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold mt-0.5 bg-teal-50 text-teal-700 border border-teal-200">
                                                            Asisten HR
                                                        </span>
                                                    </div>
                                                @else
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600 whitespace-nowrap">
                                                        Tanpa Asisten
                                                    </span>
                                                @endif
                                            </td>

                                            {{-- Staff Pengawas (tetap level akun) --}}
                                            <td class="px-4 py-3 text-xs min-w-0">
                                                @if($acc->supervisorStaff)
                                                    <div class="min-w-0">
                                                        <span class="font-semibold text-gray-800 block truncate" title="{{ $acc->supervisorStaff->name }}">
                                                            {{ $acc->supervisorStaff->name }}
                                                        </span>
                                                        <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold mt-0.5 bg-blue-50 text-blue-700 border border-blue-200">
                                                            Staff Pengawas
                                                        </span>
                                                    </div>
                                                @else
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-500 whitespace-nowrap">
                                                        Tanpa Pengawas
                                                    </span>
                                                @endif
                                            </td>

                                            {{-- Aksi --}}
                                            <td class="px-4 py-3.5 text-center">
                                                <div class="flex items-center justify-center gap-1">
                                                    {{-- Edit penugasan akun --}}
                                                    <button type="button"
                                                        onclick="openEditAccountModal({
                                                            id: {{ $acc->id }},
                                                            name: '{{ addslashes($acc->name) }}',
                                                            platform: '{{ addslashes($acc->platform) }}',
                                                            link: '{{ addslashes($acc->link ?? '') }}',
                                                            pm_id: {{ $acc->pm_id ?? 'null' }},
                                                            assistant_id: {{ $acc->assistant_id ?? 'null' }},
                                                            supervisor_staff_id: {{ $acc->supervisor_staff_id ?? 'null' }},
                                                            notes: '{{ addslashes(str_replace(["\r", "\n"], [' ', ' '], $acc->notes ?? '')) }}',
                                                            staff_users: {{ json_encode($acc->staffUsers->map(fn($u) => ['id' => $u->id, 'name' => $u->name, 'role' => $u->role, 'role_label' => match($u->role) { 'pm' => 'PM Mandiri', 'sosmed' => 'Staff Sosmed', 'digital_marketing' => 'Digital Marketing', default => $u->role_label ?? strtoupper($u->role) }])) }},
                                                            managers_count: {{ $acc->staffUsers->count() }},
                                                            assigned_user_ids: {{ json_encode($acc->staffUsers->pluck('id')) }},
                                                            current_staff_id: {{ $stUser ? $stUser->id : 'null' }}
                                                        })"
                                                        class="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                                                        title="Atur Penugasan">
                                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                                d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                                        </svg>
                                                    </button>

                                                    {{-- Ikon sampah = lepas HANYA pengelola di baris ini --}}
                                                    @if($stUser)
                                                        <form method="POST" action="{{ route('admin.sosmed.accounts.unassign', $acc) }}"
                                                            onsubmit="return confirm('Lepas akses {{ addslashes($stUser->name) }} dari akun {{ addslashes($acc->name) }}?')"
                                                            class="inline">
                                                            @csrf
                                                            <input type="hidden" name="user_id" value="{{ $stUser->id }}">
                                                            <button type="submit"
                                                                    class="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                                                                    title="Lepas {{ $stUser->name }} dari akun ini">
                                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                                                </svg>
                                                            </button>
                                                        </form>
                                                    @endif
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                @empty
                                    <tr>
                                        <td colspan="8" class="px-4 py-8 text-center text-sm text-gray-400">
                                            @if($accountSearch)
                                                Tidak ditemukan akun yang cocok dengan pencarian "<strong>{{ $accountSearch }}</strong>".
                                                <div class="mt-2">
                                                    <a href="{{ route('admin.sosmed.index', ['tab' => 'accounts']) }}" class="text-xs text-primary-600 hover:underline">Reset pencarian</a>
                                                </div>
                                            @else
                                                Belum ada akun sosial media yang didaftarkan.
                                            @endif
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    {{-- Mobile Cards (< md) --}} <div class="md:hidden space-y-3">
                    @forelse($accounts as $acc)
                        @php
                            $managers = $acc->staffUsers;
                            $hasManagers = $managers->count() > 0;
                            if ($accountSearch && $searchType === 'manager') {
                                $filteredManagers = $managers->filter(
                                    fn($u) => str_contains(strtolower($u->name), strtolower(trim($accountSearch)))
                                );
                                $rows = $filteredManagers->count() > 0 ? $filteredManagers : collect([null]);
                            } elseif ($accountSearch && $searchType === 'all') {
                                $accNameMatch = str_contains(strtolower($acc->name), strtolower(trim($accountSearch)))
                                    || str_contains(strtolower($acc->username ?? ''), strtolower(trim($accountSearch)));
                                if (!$accNameMatch) {
                                    $filteredManagers = $managers->filter(
                                        fn($u) => str_contains(strtolower($u->name), strtolower(trim($accountSearch)))
                                    );
                                    $rows = $filteredManagers->count() > 0 ? $filteredManagers : ($hasManagers ? $managers : collect([null]));
                                } else {
                                    $rows = $hasManagers ? $managers : collect([null]);
                                }
                            } else {
                                $rows = $hasManagers ? $managers : collect([null]);
                            }
                        @endphp

                        @foreach($rows as $stUser)
                            @php
                                $staffRoleTag = $stUser ? match ($stUser->role) {
                                    'pm' => 'PM Mandiri',
                                    'sosmed' => 'Staff Sosmed',
                                    'digital_marketing' => 'Digital Marketing',
                                    'hr_assistant' => 'HR Assistant',
                                    'hr_staff' => 'HR Staff',
                                    default => $stUser->role_label ?? strtoupper($stUser->role)
                                } : null;

                                $isDirectAdmin = $stUser && $stUser->role === 'hr_staff';
                                $isDirectHr    = $stUser && in_array($stUser->role, ['pm', 'hr_assistant']);
                            @endphp

                            <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                                {{-- Header: Nama + Platform + Aksi --}}
                                <div class="flex items-start justify-between gap-2 mb-3">
                                    <div class="min-w-0">
                                        <div class="flex items-center gap-1.5 min-w-0">
                                            <p class="font-semibold text-gray-800 text-sm truncate min-w-0" title="{{ $acc->name }}">
                                                {{ $acc->name }}
                                            </p>
                                            <x-brand-badge :acc="$acc" :logos="$brandLogos" />
                                        </div>
                                        <span class="inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded-md text-xs font-medium border {{ $acc->platform_color }}">
                                            {{ $acc->platform_icon }} {{ $acc->platform }}
                                        </span>
                                        @if($acc->notes)
                                            <p class="text-xs text-gray-400 mt-1 line-clamp-2" title="{{ $acc->notes }}">
                                                {{ $acc->notes }}
                                            </p>
                                        @endif
                                    </div>

                                    <div class="flex items-center gap-1 flex-shrink-0">
                                        {{-- Edit --}}
                                        <button type="button"
                                            onclick="openEditAccountModal({
                                                id: {{ $acc->id }},
                                                name: '{{ addslashes($acc->name) }}',
                                                platform: '{{ addslashes($acc->platform) }}',
                                                link: '{{ addslashes($acc->link ?? '') }}',
                                                pm_id: {{ $acc->pm_id ?? 'null' }},
                                                assistant_id: {{ $acc->assistant_id ?? 'null' }},
                                                supervisor_staff_id: {{ $acc->supervisor_staff_id ?? 'null' }},
                                                notes: '{{ addslashes(str_replace(["\r", "\n"], [' ', ' '], $acc->notes ?? '')) }}',
                                                staff_users: {{ json_encode($acc->staffUsers->map(fn($u) => ['id' => $u->id, 'name' => $u->name, 'role' => $u->role, 'role_label' => match($u->role) { 'pm' => 'PM Mandiri', 'sosmed' => 'Staff Sosmed', 'digital_marketing' => 'Digital Marketing', default => $u->role_label ?? strtoupper($u->role) }])) }},
                                                managers_count: {{ $acc->staffUsers->count() }},
                                                assigned_user_ids: {{ json_encode($acc->staffUsers->pluck('id')) }},
                                                current_staff_id: {{ $stUser ? $stUser->id : 'null' }}
                                            })"
                                            class="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                                            title="Atur Penugasan">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                            </svg>
                                        </button>

                                        {{-- Ikon sampah = lepas HANYA pengelola di card ini --}}
                                        @if($stUser)
                                            <form method="POST" action="{{ route('admin.sosmed.accounts.unassign', $acc) }}"
                                                onsubmit="return confirm('Lepas akses {{ addslashes($stUser->name) }} dari akun {{ addslashes($acc->name) }}?')"
                                                class="inline">
                                                @csrf
                                                <input type="hidden" name="user_id" value="{{ $stUser->id }}">
                                                <button type="submit"
                                                        class="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                                                        title="Lepas {{ $stUser->name }} dari akun ini">
                                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                                    </svg>
                                                </button>
                                            </form>
                                        @endif
                                    </div>
                                </div>

                                {{-- Link Akun --}}
                                @if($acc->link)
                                    <div class="border-t border-gray-100 pt-2.5 mt-2.5">
                                        <p class="text-gray-400 text-xs mb-1">Link Akun</p>
                                        <a href="{{ $acc->link }}" target="_blank" rel="noopener noreferrer"
                                        class="inline-flex items-center gap-1 text-xs text-primary-600 hover:text-primary-800 hover:underline truncate">
                                            <svg class="w-3 h-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                                            </svg>
                                            <span class="truncate">Buka Link</span>
                                        </a>
                                    </div>
                                @endif

                                {{-- Eksekutor (1 orang) & Supervisor PM --}}
                                <div class="flex items-center justify-between gap-2 pt-2.5 mt-2.5 border-t border-gray-100">
                                    <div class="min-w-0">
                                        <p class="text-gray-400 text-xs mb-0.5">Eksekutor</p>
                                        <div class="font-medium text-gray-800 text-xs">
                                            @if($stUser)
                                                <div class="truncate">
                                                    {{ $stUser->name }}
                                                    <span class="text-[10px] text-gray-500 font-normal">({{ $staffRoleTag }})</span>
                                                </div>
                                            @else
                                                <span class="text-amber-600 font-medium">Belum Ditugaskan</span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="min-w-0 text-right">
                                        <p class="text-gray-400 text-xs mb-0.5">Supervisor PM</p>
                                        <p class="font-medium text-gray-800 truncate block text-xs">
                                            @if($isDirectAdmin)
                                                Langsung ke Admin
                                            @elseif($isDirectHr)
                                                Langsung ke HR
                                            @else
                                                {{ $acc->pmUser?->name ?? 'Belum Ada PM' }}
                                            @endif
                                        </p>
                                    </div>
                                </div>

                                {{-- Asisten Pengawas --}}
                                <div class="pt-2 border-t border-gray-50 flex items-center justify-between text-xs mt-2">
                                    <span class="text-gray-400">Asisten Pengawas:</span>
                                    <span class="font-medium text-gray-800 truncate text-xs">
                                        @if($isDirectAdmin)
                                            Langsung ke Admin
                                        @elseif($isDirectHr)
                                            Langsung ke HR
                                        @else
                                            {{ $acc->assistantUser?->name ?? 'Tanpa Asisten' }}
                                        @endif
                                    </span>
                                </div>

                                {{-- Staff Pengawas --}}
                                <div class="pt-2 border-t border-gray-50 flex items-center justify-between text-xs mt-1">
                                    <span class="text-gray-400">Staff Pengawas:</span>
                                    <span class="font-medium text-gray-800 truncate text-xs">
                                        {{ $acc->supervisorStaff?->name ?? 'Tanpa Pengawas' }}
                                    </span>
                                </div>
                            </div>
                        @endforeach
                    @empty
                        <div class="py-8 text-center text-sm text-gray-400">
                            @if($accountSearch)
                                Tidak ditemukan akun yang cocok dengan pencarian "<strong>{{ $accountSearch }}</strong>".
                                <div class="mt-2">
                                    <a href="{{ route('admin.sosmed.index', ['tab' => 'accounts']) }}" class="text-xs text-primary-600 hover:underline">Reset pencarian</a>
                                </div>
                            @else
                                Belum ada akun sosial media.
                            @endif
                        </div>
                    @endforelse
                </div>

                {{-- Pagination --}}
                @if($accounts->hasPages())
                    <div class="mt-4 px-4 py-3 border-t border-gray-100 bg-gray-50/50">
                        {{ $accounts->links() }}
                    </div>
                @endif
            </div>
        @endif

    {{-- ── TAB: VERIFIKASI TUGAS STAFF (ADMIN LANGSUNG) ────────────── --}}
    @if($tab === 'staff_approvals')
        <div class="p-4 sm:p-5">
            <div class="mb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                    <h3 class="text-sm font-semibold text-gray-800">Verifikasi Tugas Sosmed Staff</h3>
                    <p class="text-xs text-gray-500 mt-0.5">Administrator berwenang meng-acc semua tugas sosmed tanpa
                        terkecuali, baik yang selesai dikerjakan staff maupun yang telah diverifikasi PM/Asisten.</p>
                </div>
                <form method="GET" action="{{ route('admin.sosmed.index') }}" class="flex items-center gap-2 w-full sm:w-auto">
                    <input type="hidden" name="tab" value="staff_approvals">
                    <input type="text" name="verify_search" value="{{ $verifySearch }}"
                        placeholder="Cari judul tugas, akun, atau petugas..."
                        class="w-full sm:w-64 h-9 px-3 text-xs bg-white border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500/30 focus:border-purple-500 text-gray-700 transition">
                    <button type="submit"
                        class="h-9 px-3 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold rounded-lg transition shrink-0">Cari</button>
                    @if($verifySearch !== '')
                        <a href="{{ route('admin.sosmed.index', ['tab' => 'staff_approvals']) }}"
                            class="text-xs text-purple-600 hover:underline whitespace-nowrap">Reset</a>
                    @endif
                </form>
            </div>

            <div class="space-y-3 mb-6">
                @forelse($staffPendingTasks as $task)
                    <div class="p-4 bg-purple-50/50 border border-purple-200 rounded-xl hover:border-purple-300 transition">
                        {{-- Ubah ke flex-col di mobile, flex-row di layar sm ke atas --}}
                        <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                            <div class="min-w-0 flex-1 w-full">

                                {{-- Judul dan Badge: Stack vertikal di mobile --}}
                                <div class="flex flex-col sm:flex-row sm:items-center gap-2 mb-1 sm:mb-0">
                                    <span class="font-semibold text-gray-800 text-base sm:text-sm">{{ $task->title }}</span>
                                    <div class="flex flex-wrap items-center gap-2">
                                        <span class="px-2 py-0.5 rounded-md text-xs font-medium border bg-white text-gray-700">
                                            {{ $task->account?->name }} ({{ $task->account?->platform }})
                                        </span>
                                        <span class="px-2 py-0.5 rounded text-[11px] bg-purple-100 text-purple-700 font-semibold">
                                            Menunggu Verifikasi Admin
                                        </span>
                                    </div>
                                </div>

                                {{-- Info Meta: Disesuaikan agar rapi saat turun baris --}}
                                <div
                                    class="flex flex-col sm:flex-row sm:flex-wrap sm:items-center gap-1.5 sm:gap-3 mt-2 sm:mt-1.5 text-xs text-gray-500">
                                    <span>Dikerjakan oleh: <strong
                                            class="text-gray-800">{{ $task->assignedUser?->name ?? '-' }}</strong></span>
                                    <span class="hidden sm:inline">·</span>
                                    <span>Tanggal: {{ $task->task_date->translatedFormat('d M Y') }}</span>

                                    @if($task->hasLinks())
                                        <span class="hidden sm:inline">·</span>
                                        <button type="button"
                                            onclick="openLinksPopup({{ json_encode($task->link_upload) }}, '{{ addslashes($task->title) }}')"
                                            class="text-primary-600 font-medium hover:underline inline-flex items-center gap-1 w-fit mt-1 sm:mt-0">
                                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                                            </svg>
                                            {{ $task->link_count }} Bukti Link
                                        </button>
                                    @endif
                                </div>

                                @if($task->description)
                                    <p class="text-xs text-gray-600 mt-3 bg-white/80 p-2.5 rounded-lg border border-purple-100">
                                        {{ $task->description }}
                                    </p>
                                @endif
                            </div>

                            {{-- Tombol Verifikasi: Lebar penuh di mobile --}}
                            <div class="w-full sm:w-auto sm:flex-shrink-0 mt-2 sm:mt-0">
                                <button onclick="openVerifyModal({{ $task->id }}, '{{ addslashes($task->title) }}')"
                                    class="w-full sm:w-auto inline-flex justify-center items-center gap-1.5 px-4 py-2.5 sm:py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold rounded-xl transition shadow-sm whitespace-nowrap">
                                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    Verifikasi
                                </button>
                            </div>
                        </div>
                    </div>
                @empty
                    <!-- Bagian Empty State Tetap Sama -->
                    <div class="flex flex-col items-center justify-center py-16 text-center">
                        <div class="w-16 h-16 rounded-full bg-green-50 flex items-center justify-center mb-4">
                            <svg class="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                        </div>
                        <p class="text-sm font-semibold text-gray-700">Semua Tugas Staff Sudah Diverifikasi</p>
                        <p class="text-xs text-gray-400 mt-1 max-w-xs">
                            Tidak ada tugas sosmed Staff yang menunggu verifikasi Admin saat ini.
                        </p>
                    </div>
                @endforelse
            </div>
        </div>
    @endif

    {{-- ── TAB 3: MONITORING SELURUH TUGAS ────────────────────────── --}}
    @if($tab === 'tasks')
        <div class="p-4 sm:p-5">
            {{-- Top Bar Filter & Action Buttons --}}
            <div class="mb-4 flex flex-col sm:flex-row items-stretch sm:items-center sm:justify-end gap-2.5 sm:gap-3">

                {{-- Pencarian Tugas (pojok kiri) --}}
                <form action="{{ route('admin.sosmed.index') }}" method="GET" class="flex items-center gap-2 w-full sm:w-auto sm:mr-auto">
                    <input type="hidden" name="tab" value="tasks">
                    @if($taskStatus)
                        <input type="hidden" name="task_status" value="{{ $taskStatus }}">
                    @endif
                    @if($taskDateFilter)
                        <input type="hidden" name="task_date" value="{{ $taskDateFilter }}">
                    @endif
                    <div class="relative flex-1 sm:flex-initial sm:w-64">
                        <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" fill="none"
                            stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                        <input type="text" name="task_search" value="{{ $taskSearch }}"
                            placeholder="Cari judul, akun, atau pelaksana..."
                            class="w-full h-9 pl-9 pr-3 text-xs bg-white border border-gray-300 rounded-lg shadow-sm
                                focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 text-gray-700 transition">
                    </div>
                    <button type="submit"
                        class="shrink-0 inline-flex items-center justify-center h-9 px-3.5 bg-primary-600 hover:bg-primary-700 active:bg-primary-800
                            text-white text-xs font-medium rounded-lg transition shadow-sm">
                        Cari
                    </button>
                    @if($taskSearch !== '')
                        <a href="{{ route('admin.sosmed.index', array_filter(['tab' => 'tasks', 'task_status' => $taskStatus, 'task_date' => $taskDateFilter])) }}"
                            class="shrink-0 inline-flex items-center justify-center h-9 px-3 text-xs font-medium text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition">
                            Reset
                        </a>
                    @endif
                </form>

                @if($taskStatus)
                    <span
                        class="inline-flex items-center gap-1.5 px-2.5 h-9 rounded-lg text-[11px] font-semibold bg-indigo-100 text-indigo-700 w-fit">
                        Filter status:
                        {{ match ($taskStatus) {
                            'pending' => 'Belum Dikerjakan',
                            'done_by_staff' => 'Menunggu Verifikasi PM/Asisten',
                            'verified_by_pm' => 'Menunggu HR Staff',
                            'approved_hr' => 'Disetujui Final',
                            'rejected' => 'Ditolak',
                        } }}
                        <a href="{{ route('admin.sosmed.index', array_filter(['tab' => 'tasks', 'task_date' => $taskDateFilter, 'task_search' => $taskSearch])) }}"
                            class="hover:underline" title="Hapus filter">&times;</a>
                    </span>
                @endif

                {{-- Filter Tanggal --}}
                <form action="{{ route('admin.sosmed.index') }}" method="GET" class="w-full sm:w-auto">
                    <input type="hidden" name="tab" value="tasks">
                    @if($taskStatus)
                        <input type="hidden" name="task_status" value="{{ $taskStatus }}">
                    @endif
                    @if($taskSearch !== '')
                        <input type="hidden" name="task_search" value="{{ $taskSearch }}">
                    @endif
                    <input type="date" name="task_date" value="{{ $taskDateFilter }}"
                        class="w-full sm:w-auto h-9 px-3 text-xs bg-white border border-gray-300 rounded-lg shadow-sm
                                                                                                                                                                                                                                                                           focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500
                                                                                                                                                                                                                                                                           text-gray-700 transition"
                        onchange="this.form.submit()">
                </form>

                {{-- Action Buttons (Grid di Mobile, Inline di Tablet/Desktop) --}}
                <div class="grid grid-cols-2 sm:flex sm:items-center gap-2">
                    {{-- Cetak PDF --}}
                    <button type="button" onclick="printTableOnly('tasksPrintArea', 'Monitoring Seluruh Tugas Sosmed')"
                        class="w-full sm:w-auto inline-flex items-center justify-center gap-2 h-9 px-3 sm:px-3.5 bg-primary-600 hover:bg-primary-700 active:bg-primary-800
                                                                                                                                                                                                                                                                           text-white text-xs font-medium rounded-lg transition shadow-sm">
                        <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                        </svg>
                        <span>Cetak PDF</span>
                    </button>

                    {{-- Hapus Data --}}
                    <div class="relative w-full sm:w-auto" id="purgeDropdown">
                        <button type="button" onclick="togglePurgeDropdown()"
                            class="w-full sm:w-auto inline-flex items-center justify-center gap-2 h-9 px-3 sm:px-3.5 bg-white border border-red-200 text-red-600
                                                                                                                                                                                                                                                                               hover:bg-red-50 hover:border-red-300 active:bg-red-100
                                                                                                                                                                                                                                                                               text-xs font-medium rounded-lg transition shadow-sm">
                            <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                            <span>Hapus Data</span>
                            <svg id="purgeChevron" class="w-3.5 h-3.5 text-red-400 transition-transform duration-200 shrink-0"
                                fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>

                        {{-- Dropdown --}}
                        <div id="purgeMenu"
                            class="absolute right-0 mt-2 w-56 bg-white border border-gray-100 rounded-xl shadow-lg
                                                                                                                                                                                                                                                                                                opacity-0 invisible translate-y-1
                                                                                                                                                                                                                                                                                                transition-all duration-150 z-20 overflow-hidden">
                            <div class="px-3.5 py-2.5 bg-gray-50 border-b border-gray-100">
                                <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-wider">Hapus data tugas</p>
                            </div>
                            <div class="p-1.5 space-y-0.5">
                                <form action="{{ route('admin.sosmed.tasks.purge') }}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" name="range" value="weekly"
                                        class="w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 rounded-lg transition"
                                        onclick="return confirm('Hapus data sebelum minggu ini?')">
                                        Lebih lama dari 1 Minggu
                                    </button>
                                    <button type="submit" name="range" value="monthly"
                                        class="w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 rounded-lg transition"
                                        onclick="return confirm('Hapus data sebelum bulan ini?')">
                                        Lebih lama dari 1 Bulan
                                    </button>
                                    <button type="submit" name="range" value="yearly"
                                        class="w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 rounded-lg transition"
                                        onclick="return confirm('Hapus data sebelum tahun ini?')">
                                        Lebih lama dari 1 Tahun
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Desktop Table (md+) --}}
            <div id="tasksPrintArea" class="hidden md:block overflow-x-auto rounded-lg border border-gray-100">
                <table class="w-full table-fixed text-sm">
                    <colgroup>
                        <col class="w-[20%]"> {{-- Judul Tugas --}}
                        <col class="w-[12%]"> {{-- Akun --}}
                        <col class="w-[10%]"> {{-- PJ PM --}}
                        <col class="w-[10%]"> {{-- Pelaksana --}}
                        <col class="w-[12%]"> {{-- Verif PM --}}
                        <col class="w-[14%]"> {{-- Final HR --}}
                        <col class="w-[14%]"> {{-- Status --}}
                        <col class="w-[8%]">  {{-- Aksi --}}
                    </colgroup>
                    <thead>
                        <tr class="bg-gray-50 border-b border-gray-200 text-xs font-semibold text-gray-500 tracking-wide">
                            <th class="px-2.5 py-3 text-left">Judul Tugas</th>
                            <th class="px-2.5 py-3 text-left">Akun</th>
                            <th class="px-2.5 py-3 text-left">PJ PM</th>
                            <th class="px-2.5 py-3 text-left">Pelaksana</th>
                            <th class="px-2.5 py-3 text-left">Verif PM</th>
                            <th class="px-2.5 py-3 text-left">Final HR</th>
                            <th class="px-2.5 py-3 text-left">Status</th>
                            <th class="px-2.5 py-3 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @forelse($tasks as $t)
                            <tr class="hover:bg-gray-50/80 transition align-middle">
                                <td class="px-2.5 py-2.5 min-w-0">
                                    <p class="font-semibold text-gray-800 truncate" title="{{ $t->title }}">{{ $t->title }}</p>
                                    <div class="flex items-center gap-1.5 mt-0.5 min-w-0">
                                        <span class="shrink-0 px-1.5 py-0.5 text-[10px] rounded font-medium {{ $t->type === 'daily' ? 'bg-gray-100 text-gray-600' : 'bg-purple-50 text-purple-700' }}">
                                            {{ $t->type === 'daily' ? 'Harian' : 'Custom' }}
                                        </span>
                                        <span class="text-[10px] text-gray-400 shrink-0">{{ $t->task_date->translatedFormat('d M Y') }}</span>
                                    </div>
                                </td>
                                <td class="px-2.5 py-2.5 text-xs min-w-0">
                                    <p class="font-medium text-gray-800 truncate" title="{{ $t->account?->name ?? '—' }}">{{ $t->account?->name ?? '—' }}</p>
                                    <p class="text-gray-400 truncate">{{ $t->account?->platform }}</p>
                                </td>
                                <td class="px-2.5 py-2.5 text-xs min-w-0">
                                    @if($t->account?->pmUser)
                                        <span class="font-medium text-gray-800 truncate block" title="{{ $t->account->pmUser->name }}">{{ $t->account->pmUser->name }}</span>
                                    @else
                                        <span class="text-gray-300">—</span>
                                    @endif
                                </td>
                                <td class="px-2.5 py-2.5 text-xs min-w-0">
                                    @if($t->assignedUser)
                                        <span class="font-medium text-gray-800 truncate block" title="{{ $t->assignedUser->name }}">{{ $t->assignedUser->name }}</span>
                                    @else
                                        <span class="text-gray-300">—</span>
                                    @endif
                                </td>
                                <td class="px-2.5 py-2.5 text-xs min-w-0">
                                    @if($t->verifiedBy)
                                        <span class="text-blue-700 font-semibold truncate block" title="{{ $t->verifiedBy->name }}">{{ $t->verifiedBy->name }}</span>
                                        <p class="text-[10px] text-gray-400 mt-0.5">{{ $t->verified_at?->translatedFormat('d M, H:i') }}</p>
                                    @else
                                        <span class="text-gray-300">—</span>
                                    @endif
                                </td>
                                <td class="px-2.5 py-2.5 text-xs min-w-0">
                                    @if($t->hrVerifiedBy)
                                        <span class="text-emerald-700 font-semibold truncate block" title="{{ $t->hrVerifiedBy->name }}">{{ $t->hrVerifiedBy->name }}</span>
                                        <p class="text-[10px] text-gray-400 mt-0.5">{{ $t->hr_verified_at?->translatedFormat('d M, H:i') }}</p>
                                    @else
                                        <span class="text-gray-300">—</span>
                                    @endif
                                </td>
                                <td class="px-2.5 py-2.5 min-w-0">
                                    <span
                                        class="inline-flex items-center justify-center px-2 py-0.5 rounded-full text-[11px] font-medium max-w-full {{ $t->status_badge_class }}">
                                        <span class="truncate">{{ $t->status_label }}</span>
                                    </span>
                                </td>
                                <td class="px-2.5 py-2.5 text-center">
                                    @php
                                        $taskDetail = [
                                            'title'       => $t->title,
                                            'desc'        => $t->description,
                                            'type'        => $t->type === 'daily' ? 'Harian' : 'Custom',
                                            'date'        => $t->task_date->translatedFormat('d M Y'),
                                            'account'     => $t->account?->name,
                                            'platform'    => $t->account?->platform,
                                            'pmPic'       => $t->account?->pmUser?->name,
                                            'executor'    => $t->assignedUser?->name,
                                            'pmVerified'  => $t->verifiedBy?->name,
                                            'pmAt'        => $t->verified_at?->translatedFormat('d M Y, H:i'),
                                            'hrVerified'  => $t->hrVerifiedBy?->name,
                                            'hrAt'        => $t->hr_verified_at?->translatedFormat('d M Y, H:i'),
                                            'status'      => $t->status_label,
                                            'badgeClass'  => $t->status_badge_class,
                                            'links'       => $t->link_upload ?? [],
                                        ];
                                    @endphp
                                    <button type="button"
                                        data-detail="{{ json_encode($taskDetail) }}"
                                        onclick="openTaskDetail(JSON.parse(this.getAttribute('data-detail')))"
                                        class="inline-flex items-center justify-center px-2 py-1 text-[11px] font-medium text-primary-700 bg-primary-50 hover:bg-gray-100 border border-primary-100 rounded-lg transition"
                                        title="Lihat detail tugas">
                                        Detail
                                    </button>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="px-4 py-8 text-center text-sm text-gray-400">Belum ada aktivitas tugas.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            {{-- Mobile Cards (< md) --}} <div class="md:hidden space-y-3">
                @forelse($tasks as $t)
                    <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                        <div class="flex items-start justify-between gap-2 mb-2">
                            <div class="min-w-0">
                                <p class="font-semibold text-gray-800 text-sm truncate">{{ $t->title }}</p>
                                <p class="text-xs text-gray-400 mt-0.5">{{ $t->account?->name }} ({{ $t->account?->platform }})</p>
                            </div>
                            <span
                                class="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium whitespace-nowrap {{ $t->status_badge_class }}">
                                {{ $t->status_label }}
                            </span>
                        </div>
                        <div class="grid grid-cols-2 gap-2 text-xs border-t border-gray-100 pt-2.5 mt-2">
                            {{-- Kiri --}}
                            <div class="min-w-0">
                                <p class="text-gray-400 mb-0.5">PJ PM</p>
                                <p class="font-medium text-gray-800 truncate">{{ $t->account?->pmUser?->name ?? '—' }}</p>
                            </div>
                            {{-- Kanan (Pelaksana) --}}
                            <div class="min-w-0 text-right">
                                <p class="text-gray-400 mb-0.5">Pelaksana</p>
                                <p class="font-medium text-gray-800 truncate">{{ $t->assignedUser?->name ?? '—' }}</p>
                            </div>
                            {{-- Kiri --}}
                            <div class="min-w-0">
                                <p class="text-gray-400 mb-0.5">Verif PM</p>
                                <p class="font-medium text-blue-700 truncate">{{ $t->verifiedBy?->name ?? '—' }}</p>
                            </div>
                            {{-- Kanan (Final HR) --}}
                            <div class="min-w-0 text-right">
                                <p class="text-gray-400 mb-0.5">Final HR</p>
                                <p class="font-medium text-emerald-700 truncate">{{ $t->hrVerifiedBy?->name ?? '—' }}</p>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="py-8 text-center text-sm text-gray-400">Belum ada aktivitas tugas.</div>
                @endforelse
        </div>

        {{-- Pagination --}}
        @if($tasks->hasPages())
            <div class="px-4 py-3 border-t border-gray-100 bg-gray-50/50">
                {{ $tasks->links() }}
            </div>
        @endif
        </div>
    @endif

    {{-- ── TAB 3: AUDIT TRAIL LOG APPROVAL ─────────────────────────── --}}
    @if($tab === 'logs')
        <div class="p-4 sm:p-5">
            {{-- Top Bar Filter & Action Buttons --}}
            <div class="mb-5 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 sm:gap-4">

                {{-- Form Filter --}}
                <form action="{{ route('admin.sosmed.index') }}" method="GET"
                    class="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-2">
                    <input type="hidden" name="tab" value="logs">

                    {{-- Search Assignee --}}
                    <div class="relative w-full sm:w-auto">
                        <input type="text" name="log_search" value="{{ $logSearch ?? '' }}" placeholder="Cari nama assignee..."
                            class="w-full sm:w-44 h-9 px-3 text-xs bg-white border border-gray-300 rounded-lg shadow-sm
                                                                                                                                                                                                                                                               focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 text-gray-700 transition">
                    </div>

                    {{-- Filter Aksi --}}
                    <select name="log_action"
                        class="w-full sm:w-auto h-9 pl-3 pr-8 text-xs bg-white border border-gray-300 rounded-lg shadow-sm
                                                                                                                                                                                                                                                                                 focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 text-gray-700 transition"
                        onchange="this.form.submit()">
                        <option value="">Semua Aksi</option>
                        <option value="submitted" {{ request('log_action') === 'submitted' ? 'selected' : '' }}>Selesai Dikerjakan
                        </option>
                        <option value="approved_pm" {{ request('log_action') === 'approved_pm' ? 'selected' : '' }}>Diverifikasi
                            PM</option>
                        <option value="approved_hr" {{ request('log_action') === 'approved_hr' ? 'selected' : '' }}>Disetujui HR
                            Staff</option>
                        <option value="rejected" {{ request('log_action') === 'rejected' ? 'selected' : '' }}>Ditolak / Revisi
                        </option>
                    </select>

                    {{-- Filter Rentang Waktu --}}
                    <select name="log_range"
                        class="w-full sm:w-auto h-9 pl-3 pr-8 text-xs bg-white border border-gray-300 rounded-lg shadow-sm
                                                                                                                                                                                                                                                                                focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 text-gray-700 transition"
                        onchange="this.form.submit()">
                        <option value="">Semua Waktu</option>
                        <option value="weekly" {{ request('log_range') === 'weekly' ? 'selected' : '' }}>Minggu Ini</option>
                        <option value="monthly" {{ request('log_range') === 'monthly' ? 'selected' : '' }}>Bulan Ini</option>
                        <option value="yearly" {{ request('log_range') === 'yearly' ? 'selected' : '' }}>Tahun Ini</option>
                    </select>

                    {{-- Filter Tanggal --}}
                    <input type="date" name="log_date" value="{{ $logDateFilter ?? '' }}"
                        class="w-full sm:w-auto h-9 px-3 text-xs bg-white border border-gray-300 rounded-lg shadow-sm
                                                                                                                                                                                                                                                           focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 text-gray-700 transition"
                        onchange="this.form.submit()">

                    {{-- Submit & Reset (Grouped di Mobile) --}}
                    <div class="grid grid-cols-2 sm:flex items-center gap-2 mt-1 sm:mt-0">
                        <button type="submit"
                            class="h-9 px-3.5 bg-primary-600 hover:bg-primary-700 active:bg-primary-800 text-white text-xs font-medium rounded-lg transition shadow-sm text-center">
                            Terapkan
                        </button>
                        <a href="{{ route('admin.sosmed.index', ['tab' => 'logs']) }}"
                            class="h-9 px-3.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-medium rounded-lg transition text-center inline-flex items-center justify-center">
                            Reset
                        </a>
                    </div>
                </form>

                {{-- Action Buttons (Aksi Ekspor & Hapus) --}}
                <div class="grid grid-cols-2 lg:flex lg:items-center gap-2 pt-2 lg:pt-0 border-t border-gray-100 lg:border-t-0">
                    {{-- Cetak PDF --}}
                    <button onclick="window.print()"
                        class="w-full lg:w-auto inline-flex items-center justify-center gap-2 h-9 px-3.5 bg-primary-600 hover:bg-primary-700 active:bg-primary-800 text-white text-xs font-medium rounded-lg transition shadow-sm">
                        <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                        </svg>
                        <span>Cetak PDF</span>
                    </button>

                    {{-- Hapus Data Dropdown --}}
                    <div class="relative w-full lg:w-auto" id="logsPurgeDropdown">
                        <button type="button" onclick="toggleLogsPurgeDropdown()"
                            class="w-full lg:w-auto inline-flex items-center justify-center gap-2 h-9 px-3.5 bg-white border border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 active:bg-red-100 text-xs font-medium rounded-lg transition shadow-sm">
                            <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                            <span>Hapus Data</span>
                            <svg id="logsPurgeChevron"
                                class="w-3.5 h-3.5 text-red-400 transition-transform duration-200 shrink-0" fill="none"
                                stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>

                        {{-- Dropdown Menu --}}
                        <div id="logsPurgeMenu"
                            class="absolute right-0 mt-2 w-56 bg-white border border-gray-100 rounded-xl shadow-lg opacity-0 invisible translate-y-1 transition-all duration-150 z-20 overflow-hidden">
                            <div class="px-3.5 py-2.5 bg-gray-50 border-b border-gray-100">
                                <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-wider">Hapus data log</p>
                            </div>
                            <div class="p-1.5 space-y-0.5">
                                <form action="{{ route('admin.sosmed.logs.purge') }}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" name="range" value="weekly"
                                        class="w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 rounded-lg transition"
                                        onclick="return confirm('Hapus data sebelum minggu ini?')">
                                        Lebih lama dari 1 Minggu
                                    </button>
                                    <button type="submit" name="range" value="monthly"
                                        class="w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 rounded-lg transition"
                                        onclick="return confirm('Hapus data sebelum bulan ini?')">
                                        Lebih lama dari 1 Bulan
                                    </button>
                                    <button type="submit" name="range" value="yearly"
                                        class="w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 rounded-lg transition"
                                        onclick="return confirm('Hapus data sebelum tahun ini?')">
                                        Lebih lama dari 1 Tahun
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Desktop Table (md+) --}}
            <div class="hidden md:block overflow-x-auto rounded-lg border border-gray-100">
                <table class="w-full text-sm">
                    <colgroup>
                        <col class="w-36"> {{-- Waktu --}}
                        <col class="w-36"> {{-- Pelaku --}}
                        <col class="w-32"> {{-- Role --}}
                        <col class="w-40"> {{-- Aksi --}}
                        <col class="w-1/4"> {{-- Tugas & Akun --}}
                        <col class="w-1/3"> {{-- Catatan --}}
                    </colgroup>
                    <thead>
                        <tr class="bg-gray-50 border-b border-gray-200 text-xs font-semibold text-gray-500 tracking-wide">
                            <th class="px-4 py-3 text-left">Waktu</th>
                            <th class="px-4 py-3 text-left">Assign</th>
                            <th class="px-4 py-3 text-left">Role</th>
                            <th class="px-4 py-3 text-left">Aksi</th>
                            <th class="px-4 py-3 text-left">Tugas & Akun</th>
                            <th class="px-4 py-3 text-left">Catatan</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @forelse($logs as $log)
                            <tr class="hover:bg-gray-50/80 transition align-middle">
                                <td class="px-4 py-3.5 text-xs text-gray-500 whitespace-nowrap">
                                    {{ $log->created_at->translatedFormat('d M Y, H:i') }}
                                </td>
                                <td class="px-4 py-3.5 text-xs font-semibold text-gray-800 whitespace-nowrap"
                                    title="{{ $log->user_name ?? $log->user?->name }}">
                                    {{ $log->user_name ?? $log->user?->name ?? 'System' }}
                                </td>
                                <td class="px-4 py-3.5 text-xs text-gray-600 whitespace-nowrap">
                                    {{ $log->role_name ?? $log->user?->role_label ?? '—' }}
                                </td>
                                <td class="px-4 py-3.5 text-xs whitespace-nowrap">
                                    <span
                                        class="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium {{ $log->action_badge_class }}">
                                        {{ $log->action_label }}
                                    </span>
                                </td>
                                <td class="px-4 py-3.5 text-xs">
                                    <p class="font-medium text-gray-800 truncate" title="{{ $log->task?->title }}">
                                        {{ $log->task?->title ?? '—' }}
                                    </p>
                                    @if($log->task?->account)
                                        <p class="text-gray-400 mt-0.5">{{ $log->task->account->name }}
                                            ({{ $log->task->account->platform }})</p>
                                    @endif
                                </td>
                                <td class="px-4 py-3.5 text-xs text-gray-600 leading-relaxed">
                                    {{ $log->notes ?? '—' }}
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="px-4 py-8 text-center text-sm text-gray-400">Belum ada riwayat audit log.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            {{-- Mobile Cards (< md) --}} <div class="md:hidden space-y-3">
                @forelse($logs as $log)
                    <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                        <div class="flex items-start justify-between gap-2 mb-2">
                            <div class="min-w-0">
                                <p class="font-semibold text-gray-800 text-xs">
                                    {{ $log->user_name ?? $log->user?->name ?? 'System' }}
                                    <span
                                        class="text-gray-400 font-normal">({{ $log->role_name ?? $log->user?->role_label ?? '—' }})</span>
                                </p>
                                <p class="text-[10px] text-gray-400 mt-0.5">{{ $log->created_at->translatedFormat('d M Y, H:i') }}
                                </p>
                            </div>
                            <span
                                class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium whitespace-nowrap {{ $log->action_badge_class }}">
                                {{ $log->action_label }}
                            </span>
                        </div>
                        <div class="border-t border-gray-100 pt-2 mt-2 text-xs">
                            <p class="font-medium text-gray-800 truncate">{{ $log->task?->title ?? '—' }}</p>
                            @if($log->notes)
                                <p class="text-gray-500 mt-1 italic text-[11px] bg-gray-50 p-2 rounded">"{{ $log->notes }}"</p>
                            @endif
                        </div>
                    </div>
                @empty
                    <div class="py-8 text-center text-sm text-gray-400">Belum ada riwayat audit log.</div>
                @endforelse
        </div>

        {{-- Pagination --}}
        <div class="mt-4">
            {{ $logs->links() }}
        </div>
        </div>
    @endif

    {{-- ── MODAL BERI TUGAS PENGELOLAAN SOSMED (ADMIN) ─────────────── --}}
    <div id="modal-assign-task" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onclick="document.getElementById('modal-assign-task').classList.add('hidden')"></div>
        <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg z-10 max-h-[90vh] flex flex-col overflow-visible"
            x-data="assignTaskDropdown({{ json_encode($availableAccounts) }}, {{ $executorsJson }})"
            @reset-assign-task.window="resetState()">
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200">
                <div>
                    <h3 class="text-base font-bold text-gray-800">Beri Tugas Pengelolaan Sosmed</h3>
                    <p class="text-xs text-gray-400 mt-0.5">Tugaskan akun kepada eksekutor (dapat dikelola lebih dari satu user)</p>
                </div>
                <button type="button" onclick="document.getElementById('modal-assign-task').classList.add('hidden')"
                    class="text-gray-400 hover:text-gray-600 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

            <form method="POST" action="{{ route('admin.sosmed.assign') }}" class="p-6 pt-1 space-y-4 overflow-y-auto">
                @csrf

                {{-- Dropdown Searchable: Pilih Akun yang Tersedia --}}
                <div class="relative">
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Pilih Akun yang Dikelola <span class="text-red-500">*</span>
                    </label>
                    <input type="hidden" name="sosmed_account_id" :value="selectedId" required>

                    {{-- Dropdown Trigger --}}
                    <button type="button" @click="open = !open"
                        class="w-full flex items-center justify-between gap-2 border border-gray-300 rounded-lg px-3 py-2.5 text-sm bg-white hover:bg-gray-50 focus:ring-2 focus:ring-primary-500 focus:outline-none transition min-w-0">
                        <div x-show="selectedId" class="flex items-center gap-2 truncate min-w-0 text-left">
                            <span class="font-medium text-gray-800 truncate" :title="selectedLabel" x-text="selectedLabel"></span>
                            <template x-if="selectedManagersCount > 0">
                                <span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-700 border border-indigo-200 shrink-0"
                                    :title="`${selectedManagersCount} user sedang mengelola`"
                                    x-text="selectedManagersCount"></span>
                            </template>
                        </div>
                        <span x-show="!selectedId" class="text-gray-400">-- Pilih Akun Tersedia --</span>
                        <svg class="w-4 h-4 text-gray-400 shrink-0 transition-transform duration-150"
                            :class="open ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>

                    {{-- Dropdown Menu (Searchable) --}}
                    <div x-show="open" @click.away="open = false" x-cloak
                        class="absolute z-50 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-xl max-h-60 overflow-hidden flex flex-col">
                        {{-- Search Input --}}
                        <div class="p-2 border-b border-gray-100 bg-gray-50/80 sticky top-0">
                            <div class="relative">
                                <span
                                    class="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none text-gray-400">
                                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                    </svg>
                                </span>
                                <input type="text" x-model="search" placeholder="Cari nama akun atau platform..."
                                    class="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-gray-200 rounded-lg focus:ring-1 focus:ring-primary-500 focus:outline-none">
                            </div>
                        </div>

                        {{-- Options List --}}
                        <div class="overflow-y-auto max-h-48 divide-y divide-gray-50">
                            <template x-for="acc in filteredAccounts" :key="acc.id">
                                <button type="button" @click="selectAccount(acc)"
                                    class="w-full text-left px-3 py-2 text-xs hover:bg-primary-50 hover:text-primary-700 transition flex items-center justify-between gap-2 min-w-0"
                                    :class="selectedId == acc.id ? 'bg-primary-50/70 font-semibold text-primary-700' : 'text-gray-700'"
                                    :title="`${acc.name} (${acc.platform})`">
                                    <div class="flex items-center gap-1.5 min-w-0">
                                        <span class="truncate min-w-0" x-text="`${acc.name} (${acc.platform})`"></span>
                                        <template x-if="acc.managers_count > 0">
                                            <span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 shrink-0"
                                                :title="`${acc.managers_count} user sedang mengelola`"
                                                x-text="acc.managers_count"></span>
                                        </template>
                                    </div>
                                    <span x-show="selectedId == acc.id" class="text-primary-600 shrink-0">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M5 13l4 4L19 7" />
                                        </svg>
                                    </span>
                                </button>
                            </template>

                            <div x-show="filteredAccounts.length === 0"
                                class="p-4 text-center text-xs text-gray-400 italic">
                                <span x-show="accounts.length === 0">Semua akun sudah dimasukkan ke daftar kelola sosmed
                                    atau belum ada akun di
                                    Manajemen Akun.</span>
                                <span x-show="accounts.length > 0">Tidak ada akun yang cocok dengan pencarian.</span>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Link Akun (Readonly & Auto-filled) --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Link Akun <span class="text-xs text-gray-400 font-normal">(Otomatis terisi & tidak dapat diubah)</span>
                    </label>
                    <div class="relative flex items-center w-full bg-gray-100/80 border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-primary-500">
                        <input type="text" readonly :value="selectedLink || '-'"
                            class="w-full bg-transparent border-none px-3 py-2 text-sm text-gray-600 cursor-not-allowed select-all focus:outline-none focus:ring-0">
                        <template x-if="selectedLink && selectedLink !== '-'">
                            <a :href="selectedLink" target="_blank" rel="noopener noreferrer"
                                class="shrink-0 mr-2.5 p-1 text-primary-600 hover:text-primary-800"
                                title="Buka Link di Tab Baru">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                </svg>
                            </a>
                        </template>
                    </div>
                </div>

                {{-- Eksekutor Akun --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Eksekutor Akun (Dikelola Oleh) <span class="text-gray-400 font-normal">(Opsional)</span>
                    </label>
                    <div id="assign-task-staff-managed" class="hidden mb-1"></div>
                    <select name="staff_id" id="assign-task-staff"
                        x-model="selectedStaffId"
                        :disabled="!selectedId"
                        @change="syncSupervisorState($el, 'assign-task-pm', 'assign-task-pm-hint', 'assign-task-ast'); renderManagedInfo($el)"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none
                            disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed">
                        <option value="" data-role="">-- Belum Ditugaskan / Pilih Nanti --</option>
                        <template x-for="ex in availableExecutors" :key="ex.id">
                            <option :value="ex.id" :data-role="ex.role" x-text="`${ex.name} (${ex.role_label})`"></option>
                        </template>
                    </select>
                    <p x-show="!selectedId" class="text-[11px] text-gray-400 mt-1 italic">
                        Pilih akun terlebih dahulu untuk mengaktifkan delegasi.
                    </p>
                    <p x-show="selectedAccount && availableExecutors.length === 0" class="text-[11px] text-amber-600 mt-1 italic">
                        Semua user yang berwenang sudah mengelola akun ini.
                    </p>
                </div>

                {{-- Supervisor PM --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Supervisor PM <span class="text-gray-400 font-normal">(Opsional)</span>
                    </label>
                    <div id="assign-task-pm-managed" class="hidden mb-1"></div>
                    <select name="pm_id" id="assign-task-pm"
                        :disabled="!selectedId"
                        onchange="renderManagedInfo(this)"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none
                            disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed">
                        <option value="">-- Tanpa Supervisor / Langsung ke HR --</option>
                        @foreach($pms as $pm)
                            <option value="{{ $pm->id }}">{{ $pm->name }} (PM)</option>
                        @endforeach
                    </select>
                    <p id="assign-task-pm-hint" class="text-[11px] text-gray-400 mt-1">
                        PM yang berwenang meninjau & approve tugas.
                    </p>
                </div>

                {{-- Asisten Pengawas --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Asisten Pengawas <span class="text-gray-400 font-normal">(Opsional)</span>
                    </label>
                    <div id="assign-task-ast-managed" class="hidden mb-1"></div>
                    <select name="assistant_id" id="assign-task-ast"
                        :disabled="!selectedId"
                        onchange="renderManagedInfo(this)"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none
                            disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed">
                        <option value="">-- Tanpa Asisten --</option>
                        @foreach($assistants as $asst)
                            <option value="{{ $asst->id }}">{{ $asst->name }} (Asisten)</option>
                        @endforeach
                    </select>
                </div>

                {{-- Staff Pengawas --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Staff Pengawas <span class="text-gray-400 font-normal">(Opsional)</span>
                    </label>
                    <div id="assign-task-sup-managed" class="hidden mb-1"></div>
                    <select name="supervisor_staff_id" id="assign-task-sup"
                        :disabled="!selectedId"
                        onchange="renderManagedInfo(this)"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none
                            disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed">
                        <option value="">-- Tanpa Staff Pengawas --</option>
                        @foreach($supervisors as $sup)
                            <option value="{{ $sup->id }}">{{ $sup->name }} (HR Staff)</option>
                        @endforeach
                    </select>
                    <p class="text-[11px] text-gray-400 mt-1">Staff HR yang berwenang memverifikasi tugas jika PM/Asisten tidak ada.</p>
                </div>

                {{-- Catatan / Arahan Penugasan --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">Catatan / Arahan Penugasan</label>
                    <textarea name="notes" rows="2" placeholder="Catatan atau instruksi pengelolaan akun..."
                        :disabled="!selectedId"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none
                            disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed"></textarea>
                </div>

                <div class="flex gap-3 pt-2">
                    <button type="button" onclick="document.getElementById('modal-assign-task').classList.add('hidden')"
                        class="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition">Batal</button>
                    <button type="submit"
                        :disabled="!selectedId"
                        class="flex-1 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg text-sm font-semibold shadow-sm transition
                            disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-primary-600">Tambahkan
                        ke Sosmed</button>
                </div>
            </form>
        </div>
    </div>

    {{-- ── MODAL CREATE ACCOUNT (ADMIN ONLY) ───────────────────────── --}}
    <div id="modal-create-account" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onclick="document.getElementById('modal-create-account').classList.add('hidden')"></div>
        <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-md z-10 max-h-[90vh] flex flex-col">
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200">
                <h3 class="text-base font-bold text-gray-800">Tambah Akun Sosial Media Baru</h3>
                <button onclick="document.getElementById('modal-create-account').classList.add('hidden')"
                    class="text-gray-400 hover:text-gray-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
            <form method="POST" action="{{ route('admin.sosmed.accounts.store') }}"
                class="p-6 pt-1 space-y-4 overflow-y-auto">
                @csrf
                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-1.5">Nama Akun / Username <span
                            class="text-red-500">*</span></label>
                    <input type="text" name="name" required placeholder="Contoh: @republikweb_net"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-1.5">Platform <span
                            class="text-red-500">*</span></label>
                    <select name="platform" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                        <option value="">-- Pilih Platform --</option>
                        @foreach(['Instagram', 'TikTok', 'YouTube', 'Facebook', 'Twitter/X', 'LinkedIn', 'Threads', 'Website'] as $p)
                            <option value="{{ $p }}">{{ $p }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-1.5">Link URL Akun</label>
                    <input type="url" name="link" placeholder="https://instagram.com/republikweb_net"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1">Dikelola Oleh <span
                            class="text-gray-400 font-normal">(Opsional)</span></label>
                    <select name="staff_id" id="create-acc-staff"
                        onchange="syncSupervisorState(this, 'create-acc-pm', 'create-pm-hint')"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                        <option value="" data-role="">-- Belum Ditugaskan --</option>
                        @foreach($executors as $ex)
                            @php
                                $exRoleLabel = match ($ex->role) {
                                    'pm' => 'PM Mandiri',
                                    'sosmed' => 'Staff Sosmed',
                                    'digital_marketing' => 'Digital Marketing',
                                    default => $ex->role_label ?? strtoupper($ex->role)
                                };
                            @endphp
                            <option value="{{ $ex->id }}" data-role="{{ $ex->role }}">
                                {{ $ex->name }} ({{ $exRoleLabel }})
                            </option>
                        @endforeach
                    </select>
                    <p class="text-[11px] text-gray-400 mt-1">Bisa ditugaskan ke Staff Sosmed maupun PM langsung sebagai
                        eksekutor mandiri.</p>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1">Diawasi Oleh PM
                        <span class="text-gray-400 font-normal"> (Opsional)</span></label>
                    <select name="pm_id" id="create-acc-pm"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                        <option value="">-- Tanpa Supervisor --</option>
                        @foreach($pms as $pm)
                            <option value="{{ $pm->id }}">{{ $pm->name }} (PM)</option>
                        @endforeach
                    </select>
                    <p id="create-pm-hint" class="text-[11px] text-gray-400 mt-1">PM yang berwenang meninjau & approve bukti
                        postingan Staff.</p>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1">Wewenang Verifikasi Asisten </label>
                    <select name="assistant_id" id="create-acc-ast"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                        <option value="">-- Tanpa Asisten --</option>
                        @foreach($assistants as $ast)
                            <option value="{{ $ast->id }}">{{ $ast->name }} (Asisten)</option>
                        @endforeach
                    </select>
                    <p class="text-[11px] text-gray-400 mt-1">Asisten HR yang berwenang approve tugas sebagai backup PM.</p>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1">Staff Pengawas <span
                            class="text-gray-400 font-normal">(Opsional)</span></label>
                    <select name="supervisor_staff_id" id="create-acc-sup"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                        <option value="">-- Tanpa Staff Pengawas --</option>
                        @foreach($supervisors as $sup)
                            <option value="{{ $sup->id }}">{{ $sup->name }} (HR Staff)</option>
                        @endforeach
                    </select>
                    <p class="text-[11px] text-gray-400 mt-1">Staff HR yang berwenang memverifikasi tugas jika PM/Asisten
                        tidak ada.</p>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-1.5">Catatan / Briefing</label>
                    <textarea name="notes" rows="2" placeholder="Catatan seputar akun..."
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none"></textarea>
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="button" onclick="document.getElementById('modal-create-account').classList.add('hidden')"
                        class="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700">Batal</button>
                    <button type="submit"
                        class="flex-1 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg text-sm font-semibold">Simpan
                        Akun</button>
                </div>
            </form>
        </div>
    </div>

    {{-- ── MODAL EDIT DELEGASI AKUN (ADMIN) ─────────────────────────── --}}
    <div id="modal-edit-account" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4"
        x-data="editAccountDropdown({{ json_encode($availableAccounts) }}, {{ $executorsJson }})"
        @open-edit-account.window="initAccount($event.detail)">
        <div class="absolute inset-0 bg-black/50 backdrop-blur-sm" onclick="closeEditAccountModal()"></div>
        <div
            class="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg z-10 max-h-[90vh] flex flex-col overflow-visible">
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200">
                <div>
                    <h3 class="text-base font-bold text-gray-800">Atur Pengelola & Penugasan Akun</h3>
                    <p class="text-xs text-gray-400 mt-0.5">Perbarui akun yang dikelola, eksekutor, supervisor, dan arahan
                    </p>
                </div>
                <button type="button" onclick="closeEditAccountModal()"
                    class="text-gray-400 hover:text-gray-600 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
            <form id="form-edit-account" method="POST" action="" class="p-6 pt-1 space-y-4 overflow-y-auto">
                @csrf
                @method('PATCH')
                <input type="hidden" name="old_staff_id" id="edit-acc-old-staff-id" :value="oldStaffId">

                {{-- Akun yang Dikelola (Readonly / Disabled) --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Akun yang Dikelola <span class="text-xs text-gray-400 font-normal">(Tidak dapat diubah)</span>
                    </label>
                    <input type="hidden" name="sosmed_account_id" :value="selectedId">
                    <input type="text" readonly :value="selectedLabel"
                        class="w-full bg-gray-100/80 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-600 cursor-not-allowed select-all focus:outline-none">
                </div>

                {{-- Link Akun (Readonly & Auto-filled) --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Link Akun <span class="text-xs text-gray-400 font-normal">(Otomatis terisi & tidak dapat
                            diubah)</span>
                    </label>
                    <div
                        class="relative flex items-center w-full bg-gray-100/80 border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-primary-500">
                        <input type="text" readonly :value="selectedLink || '-'"
                            class="w-full bg-transparent border-none px-3 py-2 text-sm text-gray-600 cursor-not-allowed select-all focus:outline-none focus:ring-0">
                        <template x-if="selectedLink && selectedLink !== '-'">
                            <a :href="selectedLink" target="_blank" rel="noopener noreferrer"
                                class="shrink-0 mr-2.5 p-1 text-primary-600 hover:text-primary-800"
                                title="Buka Link di Tab Baru">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                </svg>
                            </a>
                        </template>
                    </div>
                </div>

                {{-- Eksekutor Akun --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Eksekutor Akun (Dikelola Oleh)
                    </label>

                    {{-- Pengelola lain di akun ini jika multi-manager --}}
                    <template x-if="otherManagers && otherManagers.length > 0">
                        <div class="mb-2.5 p-2.5 bg-gray-50 rounded-lg border border-gray-200">
                            <p class="text-[11px] text-gray-500 font-medium mb-1">Pengelola lain di akun ini:</p>
                            <div class="flex flex-wrap gap-1">
                                <template x-for="u in otherManagers" :key="u.id">
                                    <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] bg-white text-gray-700 border border-gray-200">
                                        <span x-text="u.name"></span>
                                        <span class="text-[10px] text-gray-400 font-semibold" x-text="`(${u.role_label})`"></span>
                                    </span>
                                </template>
                            </div>
                        </div>
                    </template>

                    <select name="staff_id" id="edit-acc-staff"
                        x-model="selectedStaffId"
                        onchange="syncSupervisorState(this, 'edit-acc-pm', 'edit-pm-hint', 'edit-acc-ast')"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                        <option value="" data-role="">-- Belum Ditugaskan / Kosongkan --</option>
                        <template x-for="ex in availableExecutors" :key="ex.id">
                            <option :value="ex.id" :data-role="ex.role" x-text="`${ex.name} (${ex.role_label})`"></option>
                        </template>
                    </select>
                    <p id="edit-staff-note" class="text-[11px] text-gray-400 mt-1">Mengubah eksekutor penanggung jawab pada baris ini.</p>
                </div>

                {{-- Supervisor PM --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Supervisor PM <span class="text-gray-400 font-normal">(Opsional)</span>
                    </label>
                    <select name="pm_id" id="edit-acc-pm"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                        <option value="">-- Tanpa Supervisor / Langsung ke Admin --</option>
                        @foreach($pms as $pm)
                            <option value="{{ $pm->id }}">{{ $pm->name }} (PM)</option>
                        @endforeach
                    </select>
                    <p id="edit-pm-hint" class="text-[11px] text-gray-400 mt-1">PM yang berwenang meninjau & approve bukti
                        postingan Staff.</p>
                </div>

                {{-- Asisten Pengawas --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Asisten Pengawas <span class="text-gray-400 font-normal">(Opsional)</span>
                    </label>
                    <select name="assistant_id" id="edit-acc-ast"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                        <option value="">-- Tanpa Asisten / Belum Diberi Wewenang --</option>
                        @foreach($assistants as $ast)
                            <option value="{{ $ast->id }}">{{ $ast->name }} (Asisten)</option>
                        @endforeach
                    </select>
                    <p id="edit-ast-note" class="text-[11px] text-gray-400 mt-1">Asisten HR yang berwenang meninjau &
                        approve tugas akun ini sebagai backup PM.</p>
                </div>

                {{-- Staff Pengawas --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">
                        Staff Pengawas <span class="text-gray-400 font-normal">(Opsional)</span>
                    </label>
                    <select name="supervisor_staff_id" id="edit-acc-sup"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none">
                        <option value="">-- Tanpa Staff Pengawas --</option>
                        @foreach($supervisors as $sup)
                            <option value="{{ $sup->id }}">{{ $sup->name }} (HR Staff)</option>
                        @endforeach
                    </select>
                    <p id="edit-sup-note" class="text-[11px] text-gray-400 mt-1">Staff HR yang berwenang memverifikasi tugas
                        jika PM/Asisten tidak ada.</p>
                </div>

                {{-- Catatan / Arahan Penugasan --}}
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">Catatan / Arahan Penugasan</label>
                    <textarea name="notes" id="edit-acc-notes" rows="2" placeholder="Catatan seputar akun..."
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 focus:outline-none"></textarea>
                </div>

                <div class="flex gap-3 pt-2">
                    <button type="button" onclick="closeEditAccountModal()"
                        class="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition">Batal</button>
                    <button type="submit"
                        class="flex-1 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg text-sm font-semibold shadow-sm transition">Simpan
                        Perubahan</button>
                </div>
            </form>
        </div>
    </div>



    {{-- ── MODAL: DETAIL LINKS POPUP ────────────────────────────────── --}}
    <div id="modal-links" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onclick="document.getElementById('modal-links').classList.add('hidden')"></div>
        <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-md z-10">
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200">
                <div>
                    <h3 class="text-base font-bold text-gray-800">Detail Bukti Konten</h3>
                    <p id="links-popup-title" class="text-xs text-gray-500 mt-0.5"></p>
                </div>
                <button onclick="document.getElementById('modal-links').classList.add('hidden')"
                    class="text-gray-400 hover:text-gray-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
            <div id="links-popup-body" class="p-6 space-y-2 max-h-80 overflow-y-auto"></div>
        </div>
    </div>

    {{-- ── MODAL: DETAIL TUGAS (Monitoring) ─────────────────────────── --}}
    <div id="modal-task-detail" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onclick="document.getElementById('modal-task-detail').classList.add('hidden')"></div>
        <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg z-10 max-h-[85vh] flex flex-col">
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 shrink-0">
                <h3 class="text-base font-bold text-gray-800">Detail Tugas</h3>
                <button onclick="document.getElementById('modal-task-detail').classList.add('hidden')"
                    class="text-gray-400 hover:text-gray-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
            <div class="p-6 space-y-4 overflow-y-auto">
                <div>
                    <p id="td-title" class="text-sm font-bold text-gray-800 break-words"></p>
                    <p id="td-desc" class="text-xs text-gray-500 mt-1 break-words"></p>
                    <div class="flex items-center gap-2 mt-2">
                        <span id="td-badge" class="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium"></span>
                        <span id="td-type" class="px-1.5 py-0.5 text-[10px] rounded font-medium bg-gray-100 text-gray-600"></span>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4 text-xs" id="td-grid"></div>
                <div id="td-links-wrap" class="hidden">
                    <p class="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Link Bukti Konten</p>
                    <div id="td-links" class="space-y-1.5 max-h-40 overflow-y-auto"></div>
                </div>
            </div>
        </div>
    </div>

    {{-- ── MODAL VERIFIKASI TUGAS STAFF (ADMIN LANGSUNG) ────────────── --}}
    <div id="modal-verify" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4"
        x-data="{ action: 'verify' }" @open-verify.window="action = 'verify'">
        <div class="absolute inset-0 bg-black/50 backdrop-blur-sm" onclick="closeVerifyModal()"></div>
        <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-md z-10 overflow-hidden">
            <div class="px-6 py-4 flex items-center justify-between transition-colors"
                :class="action === 'verify' ? 'bg-purple-50 border-b border-purple-100' : 'bg-rose-50 border-b border-rose-100'">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
                        :class="action === 'verify' ? 'bg-purple-100 text-purple-600' : 'bg-rose-100 text-rose-600'">
                        <template x-if="action === 'verify'">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                        </template>
                        <template x-if="action === 'reject'">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </template>
                    </div>
                    <div>
                        <h3 class="text-sm font-bold text-gray-800"
                            x-text="action === 'verify' ? 'Verifikasi Tugas Staff (Admin)' : 'Tolak & Kembalikan Tugas Staff'">
                        </h3>
                        <p class="text-[11px] text-gray-400">Verifikasi langsung hasil pengerjaan sosmed oleh HR Staff</p>
                    </div>
                </div>
                <button type="button" onclick="closeVerifyModal()" class="text-gray-400 hover:text-gray-600 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

            <form id="form-verify" method="POST" action="" class="p-6 pt-1 space-y-4">
                @csrf @method('PATCH')
                <input type="hidden" name="action" :value="action">

                <div class="bg-gray-50 rounded-xl p-3.5 border border-gray-200/80">
                    <p class="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Tugas yang Ditinjau</p>
                    <p id="verify-task-title" class="text-sm font-bold text-gray-800 break-words"></p>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-2">Keputusan Administrator</label>
                    <div class="grid grid-cols-2 gap-2 p-1 bg-gray-100 rounded-xl">
                        <button type="button" @click="action = 'verify'"
                            :class="action === 'verify' ? 'bg-white text-purple-700 shadow-sm font-bold' : 'text-gray-500 font-medium hover:text-gray-700'"
                            class="py-2 text-xs rounded-lg transition-all flex items-center justify-center gap-1.5">
                            <svg class="w-3.5 h-3.5 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            Setujui
                        </button>
                        <button type="button" @click="action = 'reject'"
                            :class="action === 'reject' ? 'bg-white text-rose-700 shadow-sm font-bold' : 'text-gray-500 font-medium hover:text-gray-700'"
                            class="py-2 text-xs rounded-lg transition-all flex items-center justify-center gap-1.5">
                            <svg class="w-3.5 h-3.5 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M6 18L18 6M6 6l12 12" />
                            </svg>
                            Tolak (Revisi)
                        </button>
                    </div>
                </div>

                <div x-show="action === 'reject'" x-transition>
                    <label class="block text-xs font-semibold text-gray-700 mb-1">
                        Catatan Revisi <span class="text-rose-500">*</span>
                    </label>
                    <textarea name="rejection_note" rows="3" placeholder="Tuliskan instruksi perbaikan untuk HR Staff..."
                        class="w-full text-xs sm:text-sm border border-rose-200 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-rose-400 bg-rose-50/20"></textarea>
                </div>

                <div class="flex items-center gap-2 pt-2">
                    <button type="button" onclick="closeVerifyModal()"
                        class="flex-1 py-2 text-xs font-semibold text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-xl transition">
                        Batal
                    </button>
                    <button type="submit"
                        :class="action === 'verify' ? 'bg-purple-600 hover:bg-purple-700 text-white' : 'bg-rose-600 hover:bg-rose-700 text-white'"
                        class="flex-1 py-2 text-xs font-semibold rounded-xl transition shadow-sm">
                        <span x-text="action === 'verify' ? 'Konfirmasi Setujui' : 'Kirim Penolakan'"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>

@endsection

@push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Auto-upgrade select elements to have an integrated search dropdown
            const selectsToUpgrade = document.querySelectorAll(
                'select[id="create-acc-staff"], select[id="create-acc-pm"], select[id="create-acc-ast"], ' +
                'select[id="edit-acc-staff"], select[id="edit-acc-pm"], select[id="edit-acc-ast"], ' +
                'select[id="assign-task-staff"], select[id="assign-task-pm"], select[id="assign-task-ast"]'
            );

            selectsToUpgrade.forEach(select => {
                if (select.dataset.customDropdownInit) return;
                select.dataset.customDropdownInit = "true";

                // Remove the old separate search input block if it exists right before the select
                const prev = select.previousElementSibling;
                if (prev && prev.classList.contains('relative') && prev.querySelector('input')) {
                    prev.remove();
                }

                const wrapper = document.createElement('div');
                wrapper.className = 'relative custom-select-wrapper';
                wrapper.style.zIndex = '10';

                const button = document.createElement('button');
                button.type = 'button';
                button.className = 'w-full border border-gray-300 rounded-lg px-3 py-2 text-sm text-left flex justify-between items-center transition ' +
                    (select.disabled ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-white text-gray-800 focus:ring-2 focus:ring-primary-500 focus:outline-none');

                const label = document.createElement('span');
                label.className = 'truncate block';
                label.textContent = select.options[select.selectedIndex]?.text || '';

                button.innerHTML = `<svg class="w-4 h-4 text-gray-500 shrink-0 ml-2 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>`;
                button.prepend(label);

                const dropdown = document.createElement('div');
                dropdown.className = 'absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-xl flex flex-col hidden';

                const searchBox = document.createElement('div');
                searchBox.className = 'p-2 border-b border-gray-100 sticky top-0 bg-white rounded-t-lg';
                searchBox.innerHTML = `
                                                                                                                                                        <div class="relative">
                                                                                                                                                            <input type="text" placeholder="Cari..." class="w-full pl-8 pr-2 py-1.5 text-xs border border-gray-200 rounded-md focus:outline-none focus:ring-1 focus:ring-primary-500 bg-gray-50 transition">
                                                                                                                                                            <svg class="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                                                                                                                                                        </div>
                                                                                                                                                    `;
                const searchInput = searchBox.querySelector('input');

                const list = document.createElement('ul');
                list.className = 'max-h-48 overflow-y-auto p-1';

                const renderOptions = (filter = '') => {
                    list.innerHTML = '';
                    let hasMatch = false;
                    Array.from(select.options).forEach(opt => {
                        const text = opt.text;
                        if (filter && !text.toLowerCase().includes(filter.toLowerCase())) return;
                        hasMatch = true;

                        const li = document.createElement('li');
                        li.className = 'px-3 py-1.5 text-sm cursor-pointer rounded-md mb-0.5 transition-colors ' +
                            (select.value === opt.value ? 'bg-primary-50 text-primary-700 font-medium' : 'hover:bg-gray-100 text-gray-700');
                        li.textContent = text;
                        li.addEventListener('click', (e) => {
                            e.stopPropagation();
                            select.value = opt.value;
                            label.textContent = text;
                            dropdown.classList.add('hidden');
                            select.dispatchEvent(new Event('change', { bubbles: true }));
                        });
                        list.appendChild(li);
                    });
                    if (!hasMatch) {
                        list.innerHTML = '<li class="px-3 py-2 text-xs text-gray-400 text-center pointer-events-none">Tidak ditemukan</li>';
                    }
                };

                searchInput.addEventListener('input', (e) => renderOptions(e.target.value));

                dropdown.appendChild(searchBox);
                dropdown.appendChild(list);

                wrapper.appendChild(button);
                wrapper.appendChild(dropdown);

                select.parentNode.insertBefore(wrapper, select);
                wrapper.appendChild(select);
                select.style.display = 'none';

                button.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (select.disabled) return;

                    const isHidden = dropdown.classList.contains('hidden');
                    document.querySelectorAll('.custom-select-wrapper .absolute').forEach(d => d.classList.add('hidden'));
                    document.querySelectorAll('.custom-select-wrapper').forEach(w => {
                        w.style.zIndex = '10';
                        if (w.parentElement) w.parentElement.style.zIndex = '';
                        if (w.parentElement) w.parentElement.style.position = '';
                    });

                    if (isHidden) {
                        wrapper.style.zIndex = '9999';
                        if (wrapper.parentElement) {
                            wrapper.parentElement.style.position = 'relative';
                            wrapper.parentElement.style.zIndex = '9999';
                        }
                        dropdown.classList.remove('hidden');
                        searchInput.value = '';
                        renderOptions();
                        setTimeout(() => searchInput.focus(), 50);
                    }
                });

                document.addEventListener('click', (e) => {
                    if (!wrapper.contains(e.target)) {
                        dropdown.classList.add('hidden');
                        wrapper.style.zIndex = '10';
                        if (wrapper.parentElement) {
                            wrapper.parentElement.style.zIndex = '';
                            wrapper.parentElement.style.position = '';
                        }
                    }
                });

                select.addEventListener('change', () => {
                    label.textContent = select.options[select.selectedIndex]?.text || '';
                });

                const observer = new MutationObserver(() => {
                    if (select.disabled) {
                        button.className = 'w-full border border-gray-300 rounded-lg px-3 py-2 text-sm text-left flex justify-between items-center transition bg-gray-100 text-gray-400 cursor-not-allowed';
                    } else {
                        button.className = 'w-full border border-gray-300 rounded-lg px-3 py-2 text-sm text-left flex justify-between items-center transition bg-white text-gray-800 focus:ring-2 focus:ring-primary-500 focus:outline-none';
                    }
                });
                observer.observe(select, { attributes: true, attributeFilter: ['disabled'] });
            });
        });

        function toggleLogsPurgeDropdown() {
            const menu = document.getElementById('logsPurgeMenu');
            const chevron = document.getElementById('logsPurgeChevron');
            const isOpen = !menu.classList.contains('invisible');

            if (isOpen) {
                closeLogsPurgeDropdown();
            } else {
                menu.classList.remove('opacity-0', 'invisible', 'translate-y-1');
                chevron.classList.add('rotate-180');
            }
        }

        function closeLogsPurgeDropdown() {
            const menu = document.getElementById('logsPurgeMenu');
            const chevron = document.getElementById('logsPurgeChevron');
            menu.classList.add('opacity-0', 'invisible', 'translate-y-1');
            chevron.classList.remove('rotate-180');
        }

        document.addEventListener('click', function (event) {
            const dropdown = document.getElementById('logsPurgeDropdown');
            if (dropdown && !dropdown.contains(event.target)) {
                closeLogsPurgeDropdown();
            }
        });

        function togglePurgeDropdown() {
            const menu = document.getElementById('purgeMenu');
            const chevron = document.getElementById('purgeChevron');
            const isOpen = !menu.classList.contains('invisible');

            if (isOpen) {
                closePurgeDropdown();
            } else {
                menu.classList.remove('opacity-0', 'invisible', 'translate-y-1');
                chevron.classList.add('rotate-180');
            }
        }

        function closePurgeDropdown() {
            const menu = document.getElementById('purgeMenu');
            const chevron = document.getElementById('purgeChevron');
            menu.classList.add('opacity-0', 'invisible', 'translate-y-1');
            chevron.classList.remove('rotate-180');
        }

        // Tutup dropdown kalau klik di luar area dropdown
        document.addEventListener('click', function (event) {
            const dropdown = document.getElementById('purgeDropdown');
            if (dropdown && !dropdown.contains(event.target)) {
                closePurgeDropdown();
            }
        });

        // The old functions are now deprecated but kept empty to avoid breaking legacy onclick handlers
        function filterSelectOptions(query, selectId) { }
        function resetSearchFilter(inputId, selectId) { }

        const MANAGED_MAP = @js($managedMap ?? []);
        const MANAGER_URL = '{{ route('admin.sosmed.user-accounts', ['user' => '__ID__']) }}';

        function renderManagedInfo(sel) {
            const box = document.getElementById(sel.id + '-managed');
            if (!box) return;
            box.textContent = '';
            const list = (sel.value && MANAGED_MAP[sel.value]) ? MANAGED_MAP[sel.value] : [];
            box.classList.toggle('hidden', list.length === 0);
            if (!list.length) return;

            const wrap = document.createElement('div');
            wrap.className = 'p-2.5 bg-gray-50 rounded-lg border border-gray-200';

            const label = document.createElement('p');
            label.className = 'text-[11px] text-gray-500 font-medium mb-1';
            label.textContent = 'Sedang mengelola: ';
            const link = document.createElement('a');
            link.href = MANAGER_URL.replace('__ID__', sel.value);
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
            link.className = 'ml-1 text-primary-600 hover:underline font-semibold';
            link.textContent = 'Lihat Detail';
            label.appendChild(link);
            wrap.appendChild(label);

            const chips = document.createElement('div');
            chips.className = 'flex flex-wrap gap-1';
            list.slice(0, 2).forEach(a => {
                const chip = document.createElement('span');
                chip.className = 'inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] bg-white text-gray-700 border border-gray-200';
                const nm = document.createElement('span');
                nm.textContent = a.name;
                const pt = document.createElement('span');
                pt.className = 'text-[10px] text-gray-400 font-semibold';
                pt.textContent = '(' + a.platform + ')';
                chip.appendChild(nm);
                chip.appendChild(pt);
                chips.appendChild(chip);
            });
            if (list.length > 2) {
                const more = document.createElement('span');
                more.className = 'inline-flex items-center px-2 py-0.5 rounded text-[11px] bg-white text-gray-500 border border-gray-200';
                more.textContent = '+' + (list.length - 2) + ' lagi';
                chips.appendChild(more);
            }
            wrap.appendChild(chips);
            box.appendChild(wrap);
        }

        function syncSupervisorState(staffSelect, pmSelectId, hintId, astSelectId) {
            if (!staffSelect) return;
            const pmSelect = document.getElementById(pmSelectId);
            const astSelect = astSelectId ? document.getElementById(astSelectId) : document.getElementById(staffSelect.id.replace('staff', 'ast'));
            const hint = document.getElementById(hintId);
            if (!pmSelect) return;

            // Jika berada dalam form yang belum memilih akun, tetap disable supervisor
            const accountInput = staffSelect.form ? staffSelect.form.querySelector('input[name="sosmed_account_id"]') : null;
            if (accountInput && !accountInput.value) {
                pmSelect.value = '';
                pmSelect.disabled = true;
                pmSelect.classList.add('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');
                if (astSelect) {
                    astSelect.value = '';
                    astSelect.disabled = true;
                    astSelect.classList.add('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');
                }
                if (hint) {
                    hint.innerHTML = 'Pilih akun terlebih dahulu untuk mengatur supervisor.';
                }
                return;
            }

            const selectedOption = staffSelect.options[staffSelect.selectedIndex];
            const role = selectedOption ? selectedOption.getAttribute('data-role') : null;

            if (role === 'pm') {
                // Ketika PM langsung, disable PM dan Asisten dropdown
                pmSelect.value = '';
                pmSelect.disabled = true;
                pmSelect.classList.add('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');

                if (astSelect) {
                    astSelect.value = '';
                    astSelect.disabled = true;
                    astSelect.classList.add('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');
                }

                if (hint) {
                    hint.innerHTML = '<span class="text-indigo-700 font-semibold">🔒 PM Mandiri:</span> Akun dikelola langsung oleh PM. Hasil pengerjaan diverifikasi oleh HR Staff.';
                }
            } else if (role === 'hr_staff') {
                // Ketika HR Staff langsung, tugas diverifikasi langsung oleh Admin
                pmSelect.value = '';
                pmSelect.disabled = true;
                pmSelect.classList.add('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');

                if (astSelect) {
                    astSelect.value = '';
                    astSelect.disabled = true;
                    astSelect.classList.add('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');
                }

                if (hint) {
                    hint.innerHTML = '<span class="text-purple-700 font-semibold">🔒 HR Staff:</span> Akun dikelola langsung oleh HR Staff. Tugas diverifikasi langsung oleh Admin.';
                }
            } else if (role === 'hr_assistant') {
                // Ketika HR Assistant langsung, tugas diverifikasi oleh HR Staff
                pmSelect.value = '';
                pmSelect.disabled = true;
                pmSelect.classList.add('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');

                if (astSelect) {
                    astSelect.value = '';
                    astSelect.disabled = true;
                    astSelect.classList.add('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');
                }

                if (hint) {
                    hint.innerHTML = '<span class="text-blue-700 font-semibold">🔒 HR Assistant:</span> Akun dikelola langsung oleh Asisten. Tugas diverifikasi oleh HR Staff.';
                }
            } else {
                // Ketika Staff Sosmed, enable PM dan Asisten dropdown
                pmSelect.disabled = false;
                pmSelect.classList.remove('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');

                if (astSelect) {
                    astSelect.disabled = false;
                    astSelect.classList.remove('bg-gray-100', 'text-gray-400', 'cursor-not-allowed');
                }

                if (hint) {
                    hint.innerHTML = 'PM yang berwenang meninjau & approve bukti postingan Staff.';
                }
            }
        }

        function openCreateAccountModal() {
            const staffSel = document.getElementById('create-acc-staff');
            if (staffSel) {
                staffSel.value = '';
                syncSupervisorState(staffSel, 'create-acc-pm', 'create-pm-hint', 'create-acc-ast');
                staffSel.dispatchEvent(new Event('change', { bubbles: true }));
            }
            const pmSel = document.getElementById('create-acc-pm');
            if (pmSel) {
                pmSel.value = '';
                pmSel.dispatchEvent(new Event('change', { bubbles: true }));
            }
            const astSel = document.getElementById('create-acc-ast');
            if (astSel) {
                astSel.value = '';
                astSel.dispatchEvent(new Event('change', { bubbles: true }));
            }
            const supSel = document.getElementById('create-acc-sup');
            if (supSel) {
                supSel.value = '';
                supSel.dispatchEvent(new Event('change', { bubbles: true }));
            }
            document.getElementById('modal-create-account').classList.remove('hidden');
        }

        function openEditAccountModal(accId, accName, platform, link, currentPmId, currentStaffId, notes, currentAssistantId, currentSupervisorStaffId) {
            let accData = {};
            if (typeof accId === 'object' && accId !== null) {
                accData = accId;
            } else {
                accData = {
                    id: accId,
                    name: accName,
                    platform: platform,
                    link: link,
                    pm_id: currentPmId,
                    staff_id: currentStaffId,
                    current_staff_id: currentStaffId,
                    notes: notes,
                    assistant_id: currentAssistantId,
                    supervisor_staff_id: currentSupervisorStaffId,
                    staff_users: [],
                    managers_count: 0,
                    assigned_user_ids: []
                };
            }

            document.getElementById('form-edit-account').action = `/admin/sosmed/accounts/${accData.id}/assign`;

            window.dispatchEvent(new CustomEvent('open-edit-account', { detail: accData }));

            const staffSel = document.getElementById('edit-acc-staff');
            const pmSel = document.getElementById('edit-acc-pm');
            const astSel = document.getElementById('edit-acc-ast');
            const supSel = document.getElementById('edit-acc-sup');
            const notesEl = document.getElementById('edit-acc-notes');

            if (staffSel) staffSel.value = accData.current_staff_id ? String(accData.current_staff_id) : '';
            if (pmSel) pmSel.value = accData.pm_id ?? '';
            if (astSel) astSel.value = accData.assistant_id ?? '';
            if (supSel) supSel.value = accData.supervisor_staff_id ?? '';
            if (notesEl) notesEl.value = accData.notes ?? '';

            if (staffSel) syncSupervisorState(staffSel, 'edit-acc-pm', 'edit-pm-hint', 'edit-acc-ast');

            // Dispatch change event to update custom dropdown labels
            setTimeout(() => {
                if (staffSel) {
                    staffSel.value = accData.current_staff_id ? String(accData.current_staff_id) : '';
                    syncSupervisorState(staffSel, 'edit-acc-pm', 'edit-pm-hint', 'edit-acc-ast');
                    staffSel.dispatchEvent(new Event('change', { bubbles: true }));
                }
                if (pmSel) pmSel.dispatchEvent(new Event('change', { bubbles: true }));
                if (astSel) astSel.dispatchEvent(new Event('change', { bubbles: true }));
                if (supSel) supSel.dispatchEvent(new Event('change', { bubbles: true }));
            }, 50);

            document.getElementById('modal-edit-account').classList.remove('hidden');
        }

        function closeEditAccountModal() {
            document.getElementById('modal-edit-account').classList.add('hidden');
        }

        // Enable any disabled select before submitting forms so payload isn't dropped
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function () {
                this.querySelectorAll('select:disabled').forEach(sel => {
                    sel.disabled = false;
                });
            });
        });

        function openLinksPopup(links, title) {
            document.getElementById('links-popup-title').textContent = title;
            const body = document.getElementById('links-popup-body');
            body.innerHTML = '';
            if (!links || links.length === 0) {
                body.innerHTML = '<p class="text-sm text-gray-400 text-center">Tidak ada link bukti.</p>';
            } else {
                links.forEach((url, i) => {
                    const item = document.createElement('a');
                    item.href = url;
                    item.target = '_blank';
                    item.rel = 'noopener noreferrer';
                    item.className = 'flex items-start gap-2.5 p-3 rounded-lg border border-gray-100 hover:border-primary-300 hover:bg-primary-50/50 transition group';
                    item.innerHTML = `
                                                                                                                                                                    <span class="flex-shrink-0 w-5 h-5 rounded-full bg-primary-100 text-primary-700 text-[10px] font-bold flex items-center justify-center mt-0.5">${i + 1}</span>
                                                                                                                                                                    <span class="text-xs text-primary-700 group-hover:underline break-all leading-relaxed">${url}</span>
                                                                                                                                                                    <svg class="w-3.5 h-3.5 flex-shrink-0 text-gray-400 group-hover:text-primary-600 mt-0.5 ml-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                                                                                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                                                                                                                                                                    </svg>`;
                    body.appendChild(item);
                });
            }
            document.getElementById('modal-links').classList.remove('hidden');
        }

        function openTaskDetail(d) {
            const esc = (v) => (v === null || v === undefined || v === '') ? '—' : v;
            document.getElementById('td-title').textContent = d.title || '';
            const desc = document.getElementById('td-desc');
            desc.textContent = d.desc || '';
            desc.classList.toggle('hidden', !d.desc);
            const badge = document.getElementById('td-badge');
            badge.textContent = d.status || '';
            badge.className = 'inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ' + (d.badgeClass || 'bg-gray-100 text-gray-600');
            document.getElementById('td-type').textContent = d.type || '';

            const grid = document.getElementById('td-grid');
            grid.innerHTML = '';
            const rows = [
                ['Tanggal', d.date],
                ['Akun', d.account ? d.account + (d.platform ? ' (' + d.platform + ')' : '') : null],
                ['PJ PM', d.pmPic],
                ['Pelaksana', d.executor],
                ['Verifikasi PM', d.pmVerified ? d.pmVerified + (d.pmAt ? ' • ' + d.pmAt : '') : null],
                ['Final HR', d.hrVerified ? d.hrVerified + (d.hrAt ? ' • ' + d.hrAt : '') : null],
            ];
            rows.forEach(([label, val]) => {
                const cell = document.createElement('div');
                cell.className = 'min-w-0';
                const l = document.createElement('p');
                l.className = 'text-[10px] font-semibold text-gray-400 uppercase tracking-wider';
                l.textContent = label;
                const v = document.createElement('p');
                v.className = 'text-xs text-gray-700 font-medium break-words';
                v.textContent = esc(val);
                cell.appendChild(l);
                cell.appendChild(v);
                grid.appendChild(cell);
            });

            const wrap = document.getElementById('td-links-wrap');
            const box = document.getElementById('td-links');
            box.innerHTML = '';
            const links = Array.isArray(d.links) ? d.links : [];
            wrap.classList.toggle('hidden', links.length === 0);
            links.forEach((url, i) => {
                const a = document.createElement('a');
                a.href = url;
                a.target = '_blank';
                a.rel = 'noopener noreferrer';
                a.className = 'flex items-center gap-2 p-2.5 rounded-lg border border-gray-100 hover:border-primary-300 hover:bg-primary-50/50 transition';
                const n = document.createElement('span');
                n.className = 'flex-shrink-0 w-5 h-5 rounded-full bg-primary-100 text-primary-700 text-[10px] font-bold flex items-center justify-center';
                n.textContent = i + 1;
                const s = document.createElement('span');
                s.className = 'text-xs text-primary-700 break-all leading-relaxed';
                s.textContent = url;
                a.appendChild(n);
                a.appendChild(s);
                box.appendChild(a);
            });

            document.getElementById('modal-task-detail').classList.remove('hidden');
        }

        function openVerifyModal(taskId, title) {
            document.getElementById('verify-task-title').textContent = title;
            document.getElementById('form-verify').action = `/admin/sosmed/tasks/${taskId}/verify`;
            const ta = document.querySelector('#form-verify textarea[name="rejection_note"]');
            if (ta) ta.value = '';
            window.dispatchEvent(new CustomEvent('open-verify'));
            document.getElementById('modal-verify').classList.remove('hidden');
        }

        function closeVerifyModal() {
            document.getElementById('modal-verify').classList.add('hidden');
        }

        function openAssignTaskModal() {
            window.dispatchEvent(new CustomEvent('reset-assign-task'));
            const staffSel = document.getElementById('assign-task-staff');
            if (staffSel) staffSel.value = '';
            const pmSel = document.getElementById('assign-task-pm');
            if (pmSel) pmSel.value = '';
            const astSel = document.getElementById('assign-task-ast');
            if (astSel) astSel.value = '';
            const supSel = document.getElementById('assign-task-sup');
            if (supSel) supSel.value = '';
            const hint = document.getElementById('assign-task-pm-hint');
            if (hint) hint.textContent = 'PM yang berwenang meninjau & approve tugas.';
            ['assign-task-staff', 'assign-task-pm', 'assign-task-ast', 'assign-task-sup'].forEach(id => {
                const box = document.getElementById(id + '-managed');
                if (box) { box.textContent = ''; box.classList.add('hidden'); }
            });
            document.getElementById('modal-assign-task').classList.remove('hidden');
        }

        function assignTaskDropdown(accountsList, executorsList) {
            return {
                accounts: accountsList || [],
                executors: executorsList || [],
                selectedId: '',
                selectedName: '',
                selectedPlatform: '',
                selectedLink: '',
                selectedAccount: null,
                selectedStaffId: '',
                search: '',
                open: false,
                resetState() {
                    this.selectedId = '';
                    this.selectedName = '';
                    this.selectedPlatform = '';
                    this.selectedLink = '';
                    this.selectedAccount = null;
                    this.selectedStaffId = '';
                    this.search = '';
                    this.open = false;
                },
                get selectedLabel() {
                    if (!this.selectedId) return '';
                    return this.selectedName + ' (' + this.selectedPlatform + ')';
                },
                get selectedManagersCount() {
                    return this.selectedAccount ? (this.selectedAccount.managers_count || 0) : 0;
                },
                get filteredAccounts() {
                    if (!this.search || !this.search.trim()) {
                        return this.accounts;
                    }
                    const q = this.search.toLowerCase();
                    return this.accounts.filter(acc => {
                        const target = (acc.name + ' ' + acc.platform).toLowerCase();
                        return target.includes(q);
                    });
                },
                get availableExecutors() {
                    if (!this.selectedAccount || !this.selectedAccount.assigned_user_ids) {
                        return this.executors;
                    }
                    const assigned = this.selectedAccount.assigned_user_ids.map(Number);
                    return this.executors.filter(u => !assigned.includes(Number(u.id)));
                },
                selectAccount(acc) {
                    this.selectedId = acc.id;
                    this.selectedName = acc.name;
                    this.selectedPlatform = acc.platform;
                    this.selectedLink = acc.link || '';
                    this.selectedAccount = acc;
                    this.open = false;

                    // If currently selected staff is already assigned to this account, reset it
                    if (this.selectedStaffId && acc.assigned_user_ids && acc.assigned_user_ids.map(Number).includes(Number(this.selectedStaffId))) {
                        this.selectedStaffId = '';
                    }

                    this.$nextTick(() => {
                        const sel = document.getElementById('assign-task-staff');
                        if (sel) {
                            syncSupervisorState(sel, 'assign-task-pm', 'assign-task-pm-hint', 'assign-task-ast');
                            renderManagedInfo(sel);
                        }
                    });
                }
            };
        }

        function editAccountDropdown(availableList, executorsList) {
            return {
                availableAccounts: availableList || [],
                executors: executorsList || [],
                accountsList: [],
                selectedId: '',
                selectedName: '',
                selectedPlatform: '',
                selectedLink: '',
                currentStaffUsers: [],
                selectedStaffId: '',
                oldStaffId: '',
                search: '',
                open: false,
                get selectedLabel() {
                    if (!this.selectedId) return '';
                    return this.selectedName + ' (' + this.selectedPlatform + ')';
                },
                get otherManagers() {
                    if (!this.currentStaffUsers) return [];
                    return this.currentStaffUsers.filter(u => Number(u.id) !== Number(this.oldStaffId));
                },
                get availableExecutors() {
                    const otherIds = this.otherManagers.map(u => Number(u.id));
                    return this.executors.filter(u => !otherIds.includes(Number(u.id)));
                },
                selectAccount(acc) {
                    this.selectedId = acc.id;
                    this.selectedName = acc.name;
                    this.selectedPlatform = acc.platform;
                    this.selectedLink = acc.link || '';
                    this.open = false;
                },
                initAccount(accData) {
                    this.selectedId = accData.id;
                    this.selectedName = accData.name;
                    this.selectedPlatform = accData.platform;
                    this.selectedLink = accData.link || '';
                    this.currentStaffUsers = accData.staff_users || [];
                    this.oldStaffId = accData.current_staff_id ? String(accData.current_staff_id) : '';
                    this.selectedStaffId = this.oldStaffId;
                    this.search = '';
                    this.open = false;

                    const list = [{
                        id: accData.id,
                        name: accData.name,
                        platform: accData.platform,
                        link: accData.link || '',
                        managers_count: accData.managers_count || 0,
                        assigned_user_ids: accData.assigned_user_ids || []
                    }];
                    this.availableAccounts.forEach(a => {
                        if (String(a.id) !== String(accData.id)) {
                            list.push(a);
                        }
                    });
                    this.accountsList = list;
                }
            };
        }
    </script>
@endpush