@extends('layouts.app')

@section('title', 'Pantau ' . $role->label)
@section('page-title', 'Pantau ' . $role->label)
@section('page-subtitle', 'Pantau seluruh tugas yang masuk ke ' . $role->label . ' hari ini')

@section('sidebar')
    @include('components.sidebar-admin')
@endsection

@section('content')

@php
    $sosmedRoles = ['hr_staff', 'hr_assistant', 'pm', 'sosmed', 'digital_marketing'];
    $hasSosmedMonitoring = in_array($role->name, $sosmedRoles);
    $activeTab = $hasSosmedMonitoring ? $tab : 'tasks';
    $tabUrl = fn ($t) => route('admin.tasks.by-role', array_filter([
        'role' => $role->name,
        'date' => $date,
        'search' => request('search'),
        'tab' => $t,
    ]));
@endphp

<div class="flex flex-wrap items-center justify-between gap-3 mb-6">
    <p class="text-sm text-gray-500">
        Total: <span class="font-semibold text-gray-700">{{ $activeTab === 'sosmed' ? $sosmedPending->count() : $tasks->total() }}</span>
        {{ $activeTab === 'sosmed' ? 'monitoring sosmed' : 'tugas' }}
        @if($date === now()->toDateString())
            <span class="text-xs text-primary-600 font-medium ml-1">(hari ini)</span>
        @else
            <span class="text-xs text-amber-600 font-medium ml-1">— {{ \Carbon\Carbon::parse($date)->translatedFormat('d M Y') }}</span>
        @endif
    </p>
    <div class="flex items-center gap-2 flex-wrap">
        {{-- Search per tab --}}
        <form method="GET" action="" class="flex items-center gap-1.5">
            <input type="hidden" name="date" value="{{ $date }}">
            <input type="hidden" name="tab" value="{{ $activeTab }}">
            <div class="relative">
                <span class="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none text-gray-400">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </span>
                <input type="search" name="search" value="{{ request('search') }}"
                    placeholder="{{ $activeTab === 'sosmed' ? 'Cari akun, pelaksana, status...' : 'Cari judul, deskripsi, penerima...' }}"
                    class="w-48 lg:w-60 pl-8 pr-2.5 py-1.5 text-xs bg-white border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 text-gray-700 transition">
            </div>
            <button type="submit"
                class="px-3 py-1.5 text-xs font-semibold bg-primary-600 hover:bg-primary-700 text-white rounded-lg transition">
                Cari
            </button>
            @if(request('search'))
                <a href="{{ route('admin.tasks.by-role', array_filter(['role' => $role->name, 'date' => $date, 'tab' => $activeTab])) }}"
                    class="text-xs text-gray-500 hover:text-red-600 font-medium whitespace-nowrap">Reset</a>
            @endif
        </form>
        <form method="GET" action="" class="flex items-center gap-2">
            <input type="hidden" name="tab" value="{{ $activeTab }}">
            <input type="hidden" name="search" value="{{ e(request('search')) }}">
            <label class="text-xs text-gray-500">Filter tanggal:</label>
            <input type="date" name="date" value="{{ $date }}"
                   class="h-8 px-3 text-xs bg-white border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 text-gray-700 transition"
                   onchange="this.form.submit()">
        </form>
        @if($date !== now()->toDateString())
            <a href="{{ route('admin.tasks.by-role', array_filter(['role' => $role->name, 'date' => now()->toDateString(), 'search' => request('search'), 'tab' => $activeTab])) }}"
               class="text-xs text-primary-600 hover:underline whitespace-nowrap">Hari ini</a>
        @endif
    </div>
</div>

@if($hasSosmedMonitoring)
    {{-- ── Tab Bar: Tugas Harian / Monitoring Sosmed ───────────── --}}
    <div class="flex items-center gap-1 sm:gap-2 border-b border-gray-200 mb-5 overflow-x-auto overflow-y-hidden -mx-1 px-1">
        <a href="{{ $tabUrl('tasks') }}"
            class="inline-flex items-center gap-2 px-3 sm:px-4 py-2.5 text-xs sm:text-sm font-semibold whitespace-nowrap border-b-2 -mb-px transition
                {{ $activeTab === 'tasks'
                    ? 'border-primary-600 text-primary-700'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }}">
            <span class="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0"></span>
            Tugas Harian
            <span
                class="px-1.5 py-0.5 rounded-full text-[10px] font-bold {{ $activeTab === 'tasks' ? 'bg-primary-100 text-primary-700' : 'bg-gray-100 text-gray-500' }}">
                {{ $tasks->total() }}
            </span>
        </a>
        <a href="{{ $tabUrl('sosmed') }}"
            class="inline-flex items-center gap-2 px-3 sm:px-4 py-2.5 text-xs sm:text-sm font-semibold whitespace-nowrap border-b-2 -mb-px transition
                {{ $activeTab === 'sosmed'
                    ? 'border-primary-600 text-primary-700'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }}">
            <span class="w-2 h-2 rounded-full bg-amber-500 flex-shrink-0"></span>
            Monitoring Sosmed
            <span
                class="px-1.5 py-0.5 rounded-full text-[10px] font-bold {{ $activeTab === 'sosmed' ? 'bg-primary-100 text-primary-700' : 'bg-gray-100 text-gray-500' }}">
                {{ $sosmedPending->count() }}
            </span>
        </a>
    </div>
@endif

@if($activeTab === 'tasks')
<div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
    <div class="overflow-x-auto">
    <table class="w-full text-xs sm:text-sm min-w-[800px]">
        <thead>
            <tr class="bg-gray-50 border-b border-gray-200">
                <th class="text-left px-3 sm:px-6 py-2.5 sm:py-3.5 font-semibold text-gray-600 w-24 sm:w-48">Judul</th>
                <th class="text-left px-3 sm:px-6 py-2.5 sm:py-3.5 font-semibold text-gray-600 hidden sm:table-cell">Deskripsi</th>
                <th class="text-left px-3 sm:px-6 py-2.5 sm:py-3.5 font-semibold text-gray-600 w-24 sm:w-32">Kantor</th>
                <th class="text-left px-3 sm:px-6 py-2.5 sm:py-3.5 font-semibold text-gray-600 w-24 sm:w-32">Dibuat Oleh</th>
                <th class="text-left px-3 sm:px-6 py-2.5 sm:py-3.5 font-semibold text-gray-600 w-24 sm:w-28">Tipe</th>
                <th class="text-left px-3 sm:px-6 py-2.5 sm:py-3.5 font-semibold text-gray-600 w-32 sm:w-48">Penerima</th>
                <th class="text-right px-3 sm:px-6 py-2.5 sm:py-3.5 font-semibold text-gray-600 w-16 sm:w-20">Aksi</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
        @forelse($tasks as $task)
            @php
                $hasCompleted = $task->assignments->where('is_completed', 'completed')->count() > 0;
                $hasNotDone   = $task->assignments->where('is_completed', 'not_done')->count() > 0;
            @endphp
            <tr class="hover:bg-gray-50 transition">
                <td class="px-3 sm:px-6 py-3 sm:py-4 w-24 sm:w-48">
                    <div class="truncate max-w-[80px] sm:max-w-[160px] font-medium text-gray-800 text-xs sm:text-sm"
                         title="{{ $task->title }}">
                        {{ $task->title }}
                    </div>
                </td>
                <td class="px-3 sm:px-6 py-3 sm:py-4 hidden sm:table-cell">
                    <div class="truncate max-w-[100px] sm:max-w-[180px] text-gray-500 text-xs"
                         title="{{ $task->description ?? '-' }}">
                        @if($task->description)
                            {!! linkify(e($task->description)) !!}
                        @else
                            -
                        @endif
                    </div>
                </td>
                <td class="px-3 sm:px-6 py-3 sm:py-4 w-24 sm:w-32">
                    @if($task->kantor)
                        <span class="inline-flex px-1.5 sm:px-2 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-700">
                            {{ $task->kantor }}
                        </span>
                    @else
                        <span class="text-xs text-gray-400">-</span>
                    @endif
                </td>
                <td class="px-3 sm:px-6 py-3 sm:py-4 w-24 sm:w-32">
                    <div class="truncate max-w-[80px] sm:max-w-[110px] text-gray-600 text-xs font-medium">
                        {{ $task->creator?->name ?? '-' }}
                    </div>
                </td>
                <td class="px-3 sm:px-6 py-3 sm:py-4 w-24 sm:w-28">
                    @if($task->type === 'self')
                        <span class="inline-flex px-1.5 sm:px-2.5 py-0.5 sm:py-1 rounded-full text-xs font-medium
                                     bg-gray-100 text-gray-600">Mandiri</span>
                    @elseif($task->type === 'default')
                        <span class="inline-flex px-1.5 sm:px-2.5 py-0.5 sm:py-1 rounded-full text-xs font-medium
                                     bg-purple-50 text-purple-700">Rutin</span>
                    @else
                        <span class="inline-flex px-1.5 sm:px-2.5 py-0.5 sm:py-1 rounded-full text-xs font-medium
                                     bg-blue-50 text-blue-700">Ditugaskan</span>
                    @endif
                </td>
        
                {{-- Penerima --}}
                <td class="px-3 sm:px-6 py-3 sm:py-4 w-32 sm:w-48">
                    <div class="flex flex-wrap gap-0.5 sm:gap-1">
                        @forelse($task->assignedUsers as $assignee)
                            @php
                                $assignment = $task->assignments->firstWhere('user_id', $assignee->id);
                                $done       = $assignment?->is_completed === 'completed';
                                $notDone    = $assignment?->is_completed === 'not_done';
                            @endphp
                            <span class="inline-flex items-center gap-0.5 sm:gap-1 px-1 sm:px-2 py-0.5 rounded-full
                                         text-xs font-medium
                                         {{ $done ? 'bg-green-50 text-green-700' : ($notDone ? 'bg-red-50 text-red-700' : 'bg-gray-100 text-gray-600') }}">
                                @if($done)
                                    <svg class="w-2.5 h-2.5 sm:w-3 sm:h-3" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd"
                                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                              clip-rule="evenodd"/>
                                    </svg>
                                @elseif($notDone)
                                    <svg class="w-2.5 h-2.5 sm:w-3 sm:h-3" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd"
                                              d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                              clip-rule="evenodd"/>
                                    </svg>
                                @endif
                                <span class="hidden sm:inline">{{ $assignee->name }}</span>
                            </span>
                        @empty
                            <span class="text-xs text-gray-400">
                                {{ $task->creator?->name ?? '-' }}
                            </span>
                        @endforelse
                    </div>
                </td>
        
                {{-- Aksi --}}
                <td class="px-3 sm:px-6 py-3 sm:py-4 w-16 sm:w-20">
                    <div class="flex items-center justify-end whitespace-nowrap gap-0.5 sm:gap-1">
                        {{-- Tombol Detail: Selalu Ada --}}
                        <button
                            type="button"
                            onclick="openDetailModal(JSON.parse(this.dataset.detail))"
                            data-detail="{{ json_encode([
                                'title'       => $task->title,
                                'description' => $task->description ?? '',
                                'kantor'      => $task->kantor,
                                'type'        => $task->type,
                                'date'        => $task->task_date->translatedFormat('d M Y'),
                                'source'      => $task->creator?->name ?? 'Sistem',
                                'status'            => 'multiple',
                                'note'              => null,
                                'proof_requirement' => $task->proof_requirement ?? 'none',
                                'assignees'         => $task->assignedUsers->map(function($u) use ($task) {
                                    $a = $task->assignments->firstWhere('user_id', $u->id);
                                    return [
                                        'name'       => $u->name,
                                        'role'       => $u->role_label,
                                        'status'     => $a?->is_completed ?? 'pending',
                                        'note'       => $a?->note ?? '',
                                        'attachment' => $a?->attachment ? asset('storage/' . $a->attachment) : null,
                                    ];
                                }),
                            ]) }}"
                            class="p-1 sm:p-1.5 text-gray-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition"
                            title="Lihat Detail">
                            <svg class="w-3.5 h-3.5 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                        </button>

                        {{-- Tombol Edit: Selalu ada untuk admin --}}
                        <button
                            onclick="openForceEditModal(
                                {{ $task->id }},
                                '{{ addslashes($task->title) }}',
                                '{{ addslashes($task->description ?? '') }}',
                                '{{ $task->kantor ?? '' }}'
                            )"
                            class="p-1 sm:p-1.5 text-gray-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition"
                            title="Edit">
                            <svg class="w-3.5 h-3.5 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                            </svg>
                        </button>

                        {{-- Tombol Hapus: Hanya jika belum dikerjakan --}}
                        @if(!$hasCompleted && !$hasNotDone)
                            <button
                                type="button"
                                onclick="openDeleteModal(this)"
                                data-id="{{ $task->id }}"
                                data-title="{{ $task->title }}"
                                class="p-1 sm:p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                                title="Hapus">
                                <svg class="w-3.5 h-3.5 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                </svg>
                            </button>
                        @endif
                    </div>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="7" class="px-3 sm:px-6 py-12 text-center text-gray-400 text-sm">
                    Tidak ada tugas untuk {{ $role->label }}
                    {{ $date === now()->toDateString() ? 'hari ini' : 'pada ' . \Carbon\Carbon::parse($date)->translatedFormat('d M Y') }}.
                </td>
            </tr>
        @endforelse
        </tbody>
    </table>
    </div>
</div>

{{-- Pagination --}}
@if($tasks->hasPages())
    <div class="mt-4 flex justify-between items-center">
        <p class="text-xs text-gray-500">
            Menampilkan {{ $tasks->firstItem() }}&ndash;{{ $tasks->lastItem() }} dari {{ $tasks->total() }} tugas
        </p>
        <div>{{ $tasks->appends(request()->query())->links() }}</div>
    </div>
@endif
@endif

{{-- ── TAB: MONITORING TUGAS SOSMED ───────────────────────────────── --}}
@if($hasSosmedMonitoring && $activeTab === 'sosmed')
<div>
    <div class="flex items-center gap-3 mb-3">
        <h3 class="text-sm font-semibold text-gray-800">Monitoring Tugas Sosmed</h3>
        @if(isset($sosmedPending) && $sosmedPending->isNotEmpty())
            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-700">
                {{ $sosmedPending->count() }} belum selesai
            </span>
        @else
            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700">
                Semua beres
            </span>
        @endif
        <span class="text-xs text-gray-400">&mdash;
            @if($role->name === 'hr_staff') Tugas sebagai eksekutor &amp; yang menunggu final approval
            @elseif($role->name === 'hr_assistant') Akun sosmed yang diawasi asisten
            @elseif($role->name === 'pm') Tugas mandiri PM &amp; akun yang menunggu verifikasi PM
            @else Tugas eksekutor yang belum selesai
            @endif
        </span>
    </div>

    <div class="bg-white rounded-xl border {{ isset($sosmedPending) && $sosmedPending->isNotEmpty() ? 'border-amber-200' : 'border-gray-200' }} overflow-hidden">
        <div class="overflow-x-auto">
        <table class="w-full text-xs sm:text-sm min-w-[700px]">
            <thead>
                <tr class="{{ isset($sosmedPending) && $sosmedPending->isNotEmpty() ? 'bg-amber-50 border-b border-amber-100' : 'bg-gray-50 border-b border-gray-200' }}">
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Akun Sosmed</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Platform</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Pelaksana</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Tanggal</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600">Status</th>
                    <th class="text-left px-4 py-3 font-semibold text-gray-600 hidden sm:table-cell">Catatan Penolakan</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                @forelse(isset($sosmedPending) ? $sosmedPending : collect() as $row)
                    @php
                        $isDone = $row->status === 'approved_hr';
                    @endphp
                    <tr class="{{ $isDone ? 'opacity-50' : 'hover:bg-amber-50/40' }} transition align-middle">
                        <td class="px-4 py-3">
                            <p class="font-semibold text-gray-800 truncate">{{ $row->account?->name ?? '—' }}</p>
                            @if(!empty($row->is_verif_row))
                                <p class="text-[10px] text-blue-500 mt-0.5">butuh verifikasi</p>
                            @endif
                        </td>
                        <td class="px-4 py-3">
                            @if($row->account)
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium border {{ $row->account->platform_color ?? 'bg-gray-100 text-gray-600 border-gray-200' }}">
                                    {{ $row->account->platform_icon ?? '' }} {{ $row->account->platform }}
                                </span>
                            @else
                                <span class="text-gray-300">—</span>
                            @endif
                        </td>
                        <td class="px-4 py-3 text-xs">
                            @if($row->executor_name && $row->executor_name !== '—')
                                <p class="font-medium text-gray-800">{{ $row->executor_name }}</p>
                                @if($row->executor_role)
                                    <p class="text-gray-400 text-[11px]">{{ $row->executor_role }}</p>
                                @endif
                            @else
                                <span class="text-gray-300">—</span>
                            @endif
                        </td>
                        <td class="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">
                            {{ \Carbon\Carbon::parse($row->task_date)->translatedFormat('d M Y') }}
                        </td>
                        <td class="px-4 py-3">
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium {{ $row->status_class }}">
                                {{ $row->status_label }}
                            </span>
                        </td>
                        <td class="px-4 py-3 text-xs text-rose-600 hidden sm:table-cell">
                            {{ $row->rejection_note ?? '—' }}
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-4 py-8 text-center text-sm text-gray-400">
                            Tidak ada tugas sosmed yang belum selesai
                            {{ $date === now()->toDateString() ? 'hari ini' : 'pada ' . \Carbon\Carbon::parse($date)->translatedFormat('d M Y') }}.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
        </div>
    </div>
</div>
@endif

@include('admin.tasks._force_edit_modal')

{{-- Modal Hapus --}}
<div id="modal-delete" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-sm mx-4">
        <div class="px-6 py-5 text-center">
            <div class="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
                <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                </svg>
            </div>
            <h3 class="text-base font-semibold text-gray-800 mb-1">Hapus Tugas</h3>
            <p class="text-sm text-gray-500 mb-6">
                Yakin ingin menghapus
                <span id="delete-task-title" class="font-semibold text-gray-700"></span>?
            </p>
            <form id="form-delete" action="" method="POST">
                @csrf
                @method('DELETE')
                <div class="flex justify-center gap-3">
                    <button type="button"
                            onclick="document.getElementById('modal-delete').classList.add('hidden')"
                            class="px-5 py-2 text-sm text-gray-600 font-medium border border-gray-300 rounded-lg">
                        Batal
                    </button>
                    <button type="submit"
                            class="px-5 py-2 bg-red-600 hover:bg-red-700 text-white
                                   text-sm font-medium rounded-lg transition">
                        Ya, Hapus
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function openDeleteModal(button) {
        const id = button.dataset ? button.dataset.id : button;
        const title = button.dataset ? button.dataset.title : '';
        document.getElementById('delete-task-title').textContent = title;
        document.getElementById('form-delete').action = `/admin/tasks/${id}/force`;
        document.getElementById('modal-delete').classList.remove('hidden');
    }
</script>

@endsection
