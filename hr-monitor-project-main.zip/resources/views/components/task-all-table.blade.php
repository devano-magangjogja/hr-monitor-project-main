@props(['tasks', 'role' => 'staff'])

@php
    $total = $tasks->count();
    $completed = 0;
    $pending = 0;
    $notDone = 0;
    foreach ($tasks as $task) {
        $s = $task->assignments->first()?->is_completed ?? 'pending';
        if (in_array($s, ['completed', 'approved_hr'])) {
            $completed++;
        } elseif ($s === 'not_done') {
            $notDone++;
        } else {
            $pending++;
        }
    }
@endphp

{{-- Stat ringkas --}}
<div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
    <div
        class="bg-white rounded-xl border border-gray-200 px-4 py-3 flex items-center gap-3 h-full hover:shadow-md transition-shadow duration-200">
        <div class="w-8 h-8 rounded-lg bg-primary-50 flex items-center justify-center flex-shrink-0">
            <svg class="w-4 h-4 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
        </div>
        <div class="min-w-0">
            <p class="text-xs text-gray-400 truncate">Total Tugas</p>
            <p class="text-lg font-bold text-gray-800">{{ $total }}</p>
        </div>
    </div>
    <div
        class="bg-white rounded-xl border border-gray-200 px-4 py-3 flex items-center gap-3 h-full hover:shadow-md transition-shadow duration-200">
        <div class="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center flex-shrink-0">
            <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
            </svg>
        </div>
        <div class="min-w-0">
            <p class="text-xs text-gray-400 truncate">Selesai</p>
            <p class="text-lg font-bold text-emerald-600">{{ $completed }}</p>
        </div>
    </div>
    <div
        class="bg-white rounded-xl border border-gray-200 px-4 py-3 flex items-center gap-3 h-full hover:shadow-md transition-shadow duration-200">
        <div class="w-8 h-8 rounded-lg bg-yellow-50 flex items-center justify-center flex-shrink-0">
            <svg class="w-4 h-4 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        </div>
        <div class="min-w-0">
            <p class="text-xs text-gray-400 truncate">Pending / Berjalan</p>
            <p class="text-lg font-bold text-yellow-600">{{ $pending }}</p>
        </div>
    </div>
    <div
        class="bg-white rounded-xl border border-gray-200 px-4 py-3 flex items-center gap-3 h-full hover:shadow-md transition-shadow duration-200">
        <div class="w-8 h-8 rounded-lg bg-red-50 flex items-center justify-center flex-shrink-0">
            <svg class="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </div>
        <div class="min-w-0">
            <p class="text-xs text-gray-400 truncate">Tidak Dikerjakan</p>
            <p class="text-lg font-bold text-red-600">{{ $notDone }}</p>
        </div>
    </div>
</div>

{{-- Tabel Semua Tugas --}}
<div class="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
    <div class="overflow-x-auto">
        <table class="w-full text-sm text-left border-collapse min-w-[700px]">
            <thead>
                <tr
                    class="bg-gray-50/80 border-b border-gray-200 text-xs font-semibold uppercase tracking-wider text-gray-500">
                    <th scope="col" class="px-5 py-3.5 w-[30%] min-w-[150px] text-left">Judul</th>
                    <th scope="col" class="px-5 py-3.5 w-[10%] min-w-[80px] text-left">Kantor</th>
                    <th scope="col" class="px-5 py-3.5 text-left">Deskripsi</th>
                    <th scope="col" class="px-5 py-3.5 w-[14%] min-w-[90px] text-left">Sumber</th>
                    <th scope="col" class="px-5 py-3.5 w-[16%] min-w-[110px] text-left">Status</th>
                    <th scope="col" class="px-5 py-3.5 w-[10%] min-w-[70px] text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 bg-white">
                @forelse($tasks as $task)
                    @php
                        $assignment = $task->assignments->first();
                        $status = $assignment?->is_completed ?? 'pending';
                        $isSosmed = !empty($task->is_sosmed);
                        $isPastUnapproved = !empty($task->is_past_unapproved);
                    @endphp
                    <tr class="hover:bg-gray-50/80 transition-colors duration-150 {{ $isPastUnapproved ? 'bg-amber-50/30' : '' }}"
                        data-task="{{ json_encode([
                            'title' => $task->title,
                            'kantor' => $task->kantor,
                            'description' => $task->description ?? '',
                            'type' => $task->type,
                            'date' => $task->task_date->translatedFormat('d M Y'),
                            'source' => $isSosmed
                                ? 'Sosmed'
                                : ($task->type === 'self'
                                    ? 'Mandiri'
                                    : ($task->type === 'default'
                                        ? 'Rutin'
                                        : $task->creator?->name ?? 'Admin')),
                            'status' => $status,
                            'proof_requirement' => $task->proof_requirement ?? 'none',
                            'attachment' => $assignment?->attachment ? asset('storage/' . $assignment->attachment) : null,
                            'note' => $assignment?->note ?? '',
                            'links' => $task->links ?? [],
                            'rejection_note' => $task->rejection_note ?? null,
                            'assignees' => [],
                        ]) }}">

                        {{-- Judul --}}
                        <td class="px-5 py-3.5">
                            <div class="font-medium text-gray-900 truncate max-w-[220px]" title="{{ $task->title }}">
                                {{ $task->title }}
                            </div>
                            <div class="flex items-center gap-1.5 flex-wrap mt-0.5">
                                @if (!empty($task->platform))
                                    <span
                                        class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium border {{ $task->platform_color ?? 'bg-gray-100 text-gray-700 border-gray-200' }}">
                                        {{ $task->platform }}
                                    </span>
                                @endif
                                @if ($isPastUnapproved)
                                    <span
                                        class="inline-flex items-center gap-1 text-[10px] text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded font-normal">
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                        {{ $task->task_date->translatedFormat('d M') }} (Belum Final)
                                    </span>
                                @endif
                            </div>
                        </td>

                        {{-- Kantor --}}
                        <td class="px-5 py-3.5 whitespace-nowrap">
                            @if ($task->kantor)
                                <span
                                    class="inline-block text-xs text-gray-700 bg-gray-100 px-2 py-0.5 rounded font-medium whitespace-nowrap">
                                    {{ $task->kantor }}
                                </span>
                            @else
                                <span class="text-xs text-gray-400">-</span>
                            @endif
                        </td>

                        {{-- Deskripsi --}}
                        <td class="px-5 py-3.5">
                            <div class="truncate max-w-[280px] text-gray-500 text-xs"
                                title="{{ strip_tags($task->description ?? '-') }}">
                                @if ($task->description)
                                    {!! linkify(e($task->description)) !!}
                                @else
                                    -
                                @endif
                            </div>
                        </td>

                        {{-- Sumber --}}
                        <td class="px-5 py-3.5 whitespace-nowrap">
                            @if ($isSosmed)
                                <span
                                    class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-pink-50 text-pink-700 border border-pink-200">
                                    Sosmed
                                </span>
                            @elseif($task->type === 'self')
                                <span
                                    class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                                    Mandiri
                                </span>
                            @elseif($task->type === 'default')
                                @if (str_contains(strtolower($task->title), 'presensi'))
                                    <span
                                        class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-teal-50 text-teal-700 border border-teal-200">
                                        Presensi
                                    </span>
                                @else
                                    <span
                                        class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-purple-50 text-purple-700 border border-purple-200">
                                        Rutin
                                    </span>
                                @endif
                            @else
                                <span
                                    class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200"
                                    title="{{ $task->creator?->name ?? 'Admin' }}">
                                    {{ Str::limit($task->creator?->name ?? 'Admin', 10) }}
                                </span>
                            @endif
                        </td>

                        {{-- Status --}}
                        <td class="px-5 py-3.5 whitespace-nowrap">
                            <x-task-status-badge :status="$status" :completedAt="$assignment?->completed_at" />
                        </td>

                        {{-- Aksi --}}
                        <td class="px-5 py-3.5 whitespace-nowrap text-center">
                            <div class="inline-flex items-center justify-center gap-1">
                                {{-- Tombol Detail --}}
                                <button onclick="openDetailModal(JSON.parse(this.closest('tr').dataset.task))"
                                    class="p-1.5 text-gray-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition"
                                    title="Lihat Detail">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                    </svg>
                                </button>

                                {{-- Aksi Sosmed --}}
                                @if ($isSosmed)
                                    @if (in_array($status, ['pending', 'rejected']))
                                        <a href="{{ $task->action_url ?? '#' }}"
                                            class="inline-flex items-center gap-1 px-2.5 py-1 bg-primary-600 hover:bg-primary-700 text-white text-xs font-medium rounded-lg transition shadow-sm"
                                            title="Submit Bukti Konten">
                                            <span>Submit</span>
                                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                            </svg>
                                        </a>
                                    @else
                                        <a href="{{ $task->action_url ?? '#' }}"
                                            class="inline-flex items-center gap-1 px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-medium rounded-lg transition"
                                            title="Lihat Progres Sosmed">
                                            <span>Lihat</span>
                                        </a>
                                    @endif

                                    {{-- Aksi Regular / Default Task --}}
                                @else
                                    @if (str_contains(strtolower($task->title), 'presensi'))
                                        @if (in_array($role, ['staff', 'assistant']))
                                            <a href="{{ route($role . '.presensi.index') }}"
                                                class="p-1.5 text-teal-600 hover:bg-teal-50 rounded-lg transition"
                                                title="Buka Halaman Presensi">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2"
                                                        d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                                                </svg>
                                            </a>
                                        @endif
                                    @endif

                                    @if ($status === 'pending')
                                        <button
                                            onclick="openCompleteModal({{ $task->id }}, '{{ addslashes($task->title) }}', '{{ $task->proof_requirement ?? 'none' }}')"
                                            class="p-1.5 text-gray-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                                            title="Tandai Selesai">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                    stroke-width="1.8" d="M5 13l4 4L19 7" />
                                            </svg>
                                        </button>
                                    @endif
                                @endif
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-6 py-12 text-center text-gray-400 text-sm">
                            Tidak ada tugas hari ini.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

{{-- Modal Checklist Selesai --}}
<div id="modal-complete" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-md mx-4">
        <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200">
            <div>
                <h3 class="text-base font-semibold text-gray-800">Tandai Selesai</h3>
                <p id="complete-task-title" class="text-xs text-gray-500 mt-0.5 truncate max-w-xs"></p>
            </div>
            <button onclick="document.getElementById('modal-complete').classList.add('hidden')"
                class="text-gray-400 hover:text-gray-600">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        <form id="form-complete" action="" method="POST" enctype="multipart/form-data"
            class="px-6 pt-1 py-5 space-y-4">
            @csrf
            @method('PATCH')
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    Catatan Penyelesaian
                    <span class="text-gray-400 font-normal">(opsional)</span>
                </label>
                <textarea name="note" rows="3" placeholder="Tuliskan laporan singkat atau catatan penyelesaian tugas ini..."
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm
                                 focus:outline-none focus:ring-2 focus:ring-green-500 resize-none"></textarea>
            </div>

            {{-- Input Foto Bukti --}}
            <div id="complete-attachment-wrapper">
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    Foto Bukti
                    <span id="complete-attachment-badge" class="font-normal text-xs ml-1"></span>
                </label>
                <input type="file" name="attachment" id="complete-attachment-input" accept="image/*"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-green-500 bg-white file:mr-3 file:py-1 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-primary-50 file:text-primary-700 hover:file:bg-primary-100 cursor-pointer">
                <p id="complete-attachment-hint" class="mt-1 text-xs text-gray-400"></p>
            </div>

            <div class="flex justify-end gap-3 pt-2">
                <button type="button" onclick="document.getElementById('modal-complete').classList.add('hidden')"
                    class="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 font-medium">
                    Batal
                </button>
                <button type="submit"
                    class="flex items-center gap-2 px-5 py-2 bg-green-600 hover:bg-green-700
                               text-white text-sm font-medium rounded-lg transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Selesai
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function openCompleteModal(id, title, proofRequirement = 'none') {
        document.getElementById('complete-task-title').textContent = title;
        document.getElementById('form-complete').action = `/{{ $role }}/tasks/all/${id}/complete`;

        const attachWrapper = document.getElementById('complete-attachment-wrapper');
        const attachBadge = document.getElementById('complete-attachment-badge');
        const attachInput = document.getElementById('complete-attachment-input');
        const attachHint = document.getElementById('complete-attachment-hint');

        if (attachInput) attachInput.value = '';

        if (proofRequirement === 'required') {
            attachWrapper.classList.remove('hidden');
            attachBadge.innerHTML = '<span class="text-rose-600 font-semibold">(Wajib)</span>';
            attachInput.required = true;
            attachHint.textContent = 'Tugas ini mewajibkan lampiran foto bukti penyelesaian (Maks. 5MB).';
        } else if (proofRequirement === 'optional') {
            attachWrapper.classList.remove('hidden');
            attachBadge.innerHTML = '<span class="text-gray-400 font-normal">(Opsional)</span>';
            attachInput.required = false;
            attachHint.textContent = 'Anda dapat melampirkan foto bukti jika ada (Maks. 5MB).';
        } else {
            attachWrapper.classList.add('hidden');
            attachInput.required = false;
            attachHint.textContent = '';
        }

        document.getElementById('modal-complete').classList.remove('hidden');
    }
</script>
